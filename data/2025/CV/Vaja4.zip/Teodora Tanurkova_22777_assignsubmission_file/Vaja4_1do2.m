%% Naloga 1

Img=imread('hotel.jpg');

figure;
imshow('hotel.jpg')
title('hotel');

sivaSLika = rgb2gray(Img);

%Sobel

Sx=[1 0 -1;
    2 0 -2;
    1 0 -1];

Sy = [1 2 1;
    0 0 0;
    -1 -2 -1];

Gx = conv2(sivaSLika, Sx, 'vali');
Gy = conv2(sivaSLika, Sy, 'valid');
G=sqrt(Gx.^2+Gy.^2);
T = 0.35 * max(G(:));
robSobel = G>T;

figure;
imshow(robSobel);
title('Magnituda gradienta po Sobelu');

%Canny
robCanny=edge(sivaSLika,'canny');

figure;
subplot(1,2,1); imshow(robCanny); title('Canny');
subplot(1,2,2); imshow(robSobel); title('Sobel');

% Naloga 2

n_interval = -200:1:200;
k_interval = -2:0.01:2;
N = length(n_interval);
K = length(k_interval);

for j=1:2
    if j == 1
       rob = robSobel;
       metoda = 'Sobel';
    else 
       rob = robCanny;
       metoda = 'Canny';
    end

    [y,x,~] = size(rob);
    HoughT = zeros(K, N);

    for yy = 1:y
        for xx = 1:x
            if rob(yy,xx)
            for ik=1:K %indekse ik
                k = k_interval(ik); %vrednosti k
                n = yy-k*xx; %vrednosti n
                if n >= -200 && n <= 200
                   in = round(n-(-200))+1; %za celostevilske indekse in
                   HoughT(ik,in) = HoughT(ik, in)+1; 
                end
            end
            end
        end
    end

    figure;
    imagesc(n_interval, k_interval, HoughT);
    colormap(gray);
    xlabel('n');
    ylabel('k'); 
    title('Houghov prostor', metoda);
    colorbar;

    [maxvStolpec, indexN] = max(HoughT, [], 2); 

    NPremic = 5;
    [~, indexVrstic] = maxk(maxvStolpec, NPremic);

    k_maximalni = k_interval(indexVrstic);            % izbrani nakloni
    n_maximalni = n_interval(indexN(indexVrstic));      % pripadajoči preseki

    figure; 
    imshow(Img);
    hold on;
    xpremica=1:size(Img,2);

    for i = 1:NPremic
        ypremica=k_maximalni(i)*xpremica + n_maximalni(i);
        plot(xpremica,ypremica ,'LineWidth', 1);
    end

    title(['Najbolj izrazite premice - ' metoda]);

 end






























