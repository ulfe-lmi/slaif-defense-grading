% Naloga 4

clear all; close all; clc;


video = VideoReader('squash.avi');

% background iz 3.
load('background.mat');   % -> background spremenljivka

background = uint8(background);

% Video writer
out = VideoWriter('squash_tracking.mp4','MPEG-4');
out.FrameRate = video.FrameRate;
open(out);

%treš
threshold = 40;
minArea = 150;
se = strel('disk',4);

figure;  % ena figura za vse frame, zaradi hitrosti

% Frame-by-frame obdelava
while hasFrame(video)

    frame = readFrame(video);

    % Razlika med sliko in ozadjem
    D = double(frame) - double(background);
    diff = sqrt(sum(D.^2, 3));

    % Threshold
    bw = diff > threshold;

    % Morfologija
    bw = imopen(bw, se);
    bw = imclose(bw, se);
    bw = bwareaopen(bw, minArea);

    % Komponente
    CC = bwlabel(bw);
    stats = regionprops(CC, 'Area','BoundingBox','Centroid');

    % Pripravi prikaz
    imshow(frame);
    hold on;

    if ~isempty(stats)
        % Izberi največja 2 objekta
        [~, idx] = sort([stats.Area], 'descend');
        idx = idx(1:min(2, length(idx)));

        % Nariši
        for k = 1:length(idx)
            bb = stats(idx(k)).BoundingBox;
            c  = stats(idx(k)).Centroid;

            rectangle('Position', bb, 'EdgeColor', 'r', 'LineWidth', 2);
            plot(c(1), c(2), 'yo', 'MarkerSize', 10, 'LineWidth', 2);
        end
    end

    hold off;

    % Zajemi frame iz figure
    F = getframe(gcf);
    writeVideo(out, F.cdata);

end

close(out);

