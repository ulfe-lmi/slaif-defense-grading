%% labvaja4_2_withDraw.m
% funkcija drawLines na koncu

clear all; close all; clc;

%% tle se nalozi slika in robovi iz naloge 1
img = imread('hotel.jpg');
gray = rgb2gray(img);

edges_sobel = edge(gray, 'Sobel');
edges_canny = edge(gray, 'Canny');

% izberi eno
edges = edges_canny;

%% Priprava parametrov k in n
k_min = -2;   k_max = 2;
n_min = -200; n_max = 200;
num_k = 401;  num_n = 401;
k_values = linspace(k_min, k_max, num_k);
n_values = linspace(n_min, n_max, num_n);
A = zeros(num_k, num_n);   % akumulator

%% Hough glasovanje
[H, W] = size(edges);
for y = 1:H
    for x = 1:W
        if edges(y,x)
            for ki = 1:num_k
                k = k_values(ki);
                n = y - k*x;
                if n >= n_min && n <= n_max
                    nj = round((n - n_min) / (n_max - n_min) * (num_n - 1)) + 1;
                    A(ki, nj) = A(ki, nj) + 1;
                end
            end
        end
    end
end

%% Najdi N največjih premic
N = 5;
A_flat = A(:);
[~, idx] = maxk(A_flat, N);
[k_idx, n_idx] = ind2sub(size(A), idx);
k_list = k_values(k_idx);
n_list = n_values(n_idx);

%% Pokliči lokalno funkcijo, ki je definirana spodaj
drawLines(img, k_list, n_list);

% ------------------------------
% Funkcija drawLines (lokalna)
% ------------------------------
function drawLines(imageRGB, k_list, n_list)
    [H, W, ~] = size(imageRGB);
    figure; imshow(imageRGB); hold on;
    x_vals = 1:W;
    colors = lines(max(1,length(k_list))); % lep nabor barv
    for i = 1:length(k_list)
        k = k_list(i);
        n = n_list(i);
        y_vals = k * x_vals + n;
        valid = y_vals >= 1 & y_vals <= H;
        plot(x_vals(valid), y_vals(valid), 'LineWidth', 2, 'Color', colors(mod(i-1,size(colors,1))+1,:));
        % napiši labelo ob sredini premice
        midx = round(W/2);
        midy = k*midx + n;
        if midy >= 1 && midy <= H
            text(midx, midy, sprintf('%d', i), 'Color', 'y', 'FontSize', 12, 'FontWeight', 'bold');
        end
    end
    title(['Najdenih premic: ', num2str(length(k_list))]);
    hold off;
end