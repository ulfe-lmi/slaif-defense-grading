clear all; close all; clc;

%% 1) pretvormo prvo v sivinsko
img = imread('hotel.jpg');
gray = rgb2gray(img);

%% 2) Sobelova operatorja Sx in Sy
Sx = [ 1 0 -1;
       2 0 -2;
       1 0 -1 ];

Sy = [ 1  2  1;
       0  0  0;
      -1 -2 -1 ];

%% 3) Konvoluciji gx gy slike s filtrom
Gx = imfilter(double(gray), Sx, 'replicate');
Gy = imfilter(double(gray), Sy, 'replicate');

%% 4) Magnituda gradienta
G = sqrt(Gx.^2 + Gy.^2);

% normalizacija 
Gnorm = uint8(255 * mat2gray(G));



% Če je na sliki preveč robov → prag gor
% Če jih je premau → prag dol
threshold = 50;

edges_sobel = G > threshold;

%% 6) Cannyjev detektor robov
edges_canny = edge(gray, 'Canny');

%% 7) Prikaz rezultatov
figure;
subplot(1,3,1); imshow(gray); title('Sivinska slika');
subplot(1,3,2); imshow(edges_sobel); title(['Sobel (threshold = ', num2str(threshold), ')']);
subplot(1,3,3); imshow(edges_canny); title('Canny');
