hotel=imread('hotel.jpg');
hotel_siv=rgb2gray(hotel);
Sx = [1 0 -1; 2 0 -2; 1 0 -1];
Sy = [1 2 1; 0 0 0; -1 -2 -1];   
Gx=conv2(hotel_siv,Sx, 'same');
Gy=conv2(hotel_siv,Sy, 'same'); %same za enake velikosti
G=sqrt(Gx.^2+Gy.^2);

G_max=max(G(:));
G_norm=G/G_max;
prag = graythresh(G_norm);   % Otsu metoda

G_kon = G_norm > prag;

Canny=edge(hotel_siv,'canny');
figure;
subplot(2,1,1);
imshow(G_kon);
title('Sobel');
Canny=edge(hotel_siv,'canny');
subplot(2,1,2);
imshow(Canny);
title('Canny');