function akum=hough_trans(binarna_slika)
    k=-2:0.01:2;
    n=-200:1:200;
    akum=zeros(401,401);
    velikost_slike=size(binarna_slika);
    for y=1:velikost_slike(1)
        for x=1:velikost_slike(2)
            if binarna_slika(y,x)==1
                for x_hou=1:401
                    for y_hou=1:401
                        if n(y_hou)==round(y-x*k(x_hou))
                            akum(x_hou,y_hou)=akum(x_hou,y_hou)+1;
                        end
                    end
                end
            end
        end
    end
end