function [] = drawLines(image, HoughSpace, N, Operator)
    k = -2:0.01:2;
    n = -200:1:200;

    maximum = zeros(N,2);
    [rows, cols, ~] = size(image);

    for p = 1:N % find top N lines
        [max1, index] = max(HoughSpace);      % max of each column
        [max2, columnId] = max(max1);         % global max
        rowId = index(columnId);              % corresponding row
        maximum(p,1) = k(rowId);
        maximum(p,2) = n(columnId);
        HoughSpace(rowId,columnId) = 0;      % remove this peak

        % Draw the line
        x_vals = 1:cols;
        y_vals = round(k(rowId)*x_vals + n(columnId));

        % Keep points inside image
        valid = y_vals >= 1 & y_vals <= rows;

        % Set line color (red)
        for i = 1:length(x_vals)
            if valid(i)
                image(y_vals(i), x_vals(i), 1) = 255;
                image(y_vals(i), x_vals(i), 2) = 0;
                image(y_vals(i), x_vals(i), 3) = 0;
            end
        end
    end

    figure('Name', Operator);
    imshow(image);
end
