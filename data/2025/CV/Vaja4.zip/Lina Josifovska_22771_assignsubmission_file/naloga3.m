video=VideoReader('squash.avi');
frames=read(video,[1 Inf]);
velikost_videa=size(frames);

a=1;
for t=1:20:velikost_videa(4)
    za_ozadje(:,:,:,a)=frames(:,:,:,t);
    a=a+1;
end

povprecje=mode(za_ozadje,4);
imshow(povprecje(:,:,:))