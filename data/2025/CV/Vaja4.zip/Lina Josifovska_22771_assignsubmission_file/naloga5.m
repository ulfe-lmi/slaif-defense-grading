video=VideoReader('squash.avi');
frames=read(video,[1 Inf]);
velikost_videa=size(frames);

a=1;
for b=1:20:velikost_videa(4)
    za_ozadje(:,:,:,a)=frames(:,:,:,b);
    a=a+1;
end

povprecje=mode(za_ozadje,4);

%t=20;
for t=1:velikost_videa(4)
    razlika=frames(:,:,:,t)-povprecje;
    koncni_frame=frames(:,:,:,t);
    imshow(razlika(:,:,1));
    imagesc(razlika);
    imshow(frames(:,:,:,t))
    for i=1:velikost_videa(1)
        for j=1:velikost_videa(2)
            if razlika(i,j,1)<30
                upragovljeno(i,j)=0;
            else
                upragovljeno(i,j)=1;
            end
        end
    end
    imshow(upragovljeno);
    SE1=strel('rectangle',[3 3]);
    morfoloske1=imopen(upragovljeno,SE1);
    SE2=strel('rectangle',[5 5]);
    morfoloske2=imdilate(morfoloske1,SE2);
    imshow(morfoloske1);
    imshow(morfoloske2);
    
    razdeljen=bwlabel(morfoloske2,4);
    stevilo_podrocji=max(max(razdeljen));
    
    for pod=1:stevilo_podrocji
        stevilo_clenov(pod)=sum(sum(razdeljen==pod));
    end
    index_najvecjega=find(stevilo_clenov==(max(stevilo_clenov)));
    stevilo_clenov2=stevilo_clenov(stevilo_clenov~=(max(stevilo_clenov)));
    index_drugega=find(stevilo_clenov==(max(stevilo_clenov2)));
    
    [x1,y1]=find(razdeljen==index_najvecjega(1));
    [x2,y2]=find(razdeljen==index_drugega(1));
    x1_sredisce=floor(min(x1)+(max(x1)-min(x1))/2);
    y1_sredisce=floor(min(y1)+(max(y1)-min(y1))/2);
    x2_sredisce=floor(min(x2)+(max(x2)-min(x2))/2);
    y2_sredisce=floor(min(y2)+(max(y2)-min(y2))/2);
    
    vzorec1=frames(x1_sredisce-2:x1_sredisce+2,y1_sredisce-2:y1_sredisce+2,:,t);
    vzorec2=frames(x2_sredisce-2:x2_sredisce+2,y2_sredisce-2:y2_sredisce+2,:,t);
    
    povprecje_vzorec1=mean(vzorec1,[1 2]);
    povprecje_vzorec2=mean(vzorec2,[1 2]);
    
    koncni_frame(x1_sredisce:x1_sredisce+1,y1_sredisce-2:y1_sredisce+2,1)=0;
    koncni_frame(x1_sredisce:x1_sredisce+1,y1_sredisce-2:y1_sredisce+2,2)=255;
    koncni_frame(x1_sredisce:x1_sredisce+1,y1_sredisce-2:y1_sredisce+2,3)=0;
    koncni_frame(x1_sredisce-2:x1_sredisce+2,y1_sredisce:y1_sredisce+1,1)=0;
    koncni_frame(x1_sredisce-2:x1_sredisce+2,y1_sredisce:y1_sredisce+1,2)=255;
    koncni_frame(x1_sredisce-2:x1_sredisce+2,y1_sredisce:y1_sredisce+1,3)=0;
    koncni_frame(x2_sredisce:x2_sredisce+1,y2_sredisce-2:y2_sredisce+2,1)=0;
    koncni_frame(x2_sredisce:x2_sredisce+1,y2_sredisce-2:y2_sredisce+2,2)=255;
    koncni_frame(x2_sredisce:x2_sredisce+1,y2_sredisce-2:y2_sredisce+2,3)=0;
    koncni_frame(x2_sredisce-2:x2_sredisce+2,y2_sredisce:y2_sredisce+1,1)=0;
    koncni_frame(x2_sredisce-2:x2_sredisce+2,y2_sredisce:y2_sredisce+1,2)=255;
    koncni_frame(x2_sredisce-2:x2_sredisce+2,y2_sredisce:y2_sredisce+1,3)=0;
    
    if (povprecje_vzorec1(1)<160 && povprecje_vzorec2(1)>160)
        koncni_frame_1=insertText(koncni_frame,[y1_sredisce x1_sredisce],['A']);
        koncni_frame_crka=insertText(koncni_frame_1,[y2_sredisce x2_sredisce],['B']);
    else
        koncni_frame_1=insertText(koncni_frame,[y1_sredisce x1_sredisce],['B']);
        koncni_frame_crka=insertText(koncni_frame_1,[y2_sredisce x2_sredisce],['A']);
    end
    
    koncni_video(:,:,:,t)=koncni_frame_crka;
    %imshow(koncni_frame_crka);
    
end

writerObj=VideoWriter('5_naloga.avi');
writerObj.FrameRate=25;
open(writerObj);
writeVideo(writerObj,cast(koncni_video,'uint8'));
close(writerObj);