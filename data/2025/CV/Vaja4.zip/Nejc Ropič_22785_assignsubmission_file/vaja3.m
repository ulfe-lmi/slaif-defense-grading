video = VideoReader('squash.avi');
frames = read(video,[1, Inf]); 
[height, width, c, num_frames] = size(frames);

step = 40;
frames_len = floor(num_frames / step);
frames4D = zeros(height,width,c, frames_len);

frame_counter = 0;
for f = 1:step:num_frames
    
    frame_counter = frame_counter + 1;
    frame = frames(:,:,:,f);
    frames4D(:,:,:,frame_counter) = frame;

end

% mediana, ker je nelinearen robusten filter, ki odstrani objekte, ki 
% ne zavzemajo istega piksla več kot polovico časa. Za vsak piksle pogledaš
% njegovo vrednost na vseh frameih
frames4D = frames4D(:,:,:,1:frame_counter);
mode_double = mode(frames4D,4);
modus = uint8(mode_double);

% 5. Prikaz slike ozadja
imshow(modus);
title('Ocenjeno ozadje (mediana po času)');