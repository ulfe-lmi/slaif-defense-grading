% Branje sivinske slike
img = imread('hotel.jpg');
img = rgb2gray(img);

Sx = [1 0 -1; 2 0 -2; 1 0 -1];
Sy = [1 2 1; 0 0 0; -1 -2 -1];

img_d = double(img);

% Sobel gradienti
Gx = conv2(img_d, Sx, 'same');
Gy = conv2(img_d, Sy, 'same');
G = sqrt(Gx.^2 + Gy.^2);
Gnorm = mat2gray(G); % normalizacija

% prag
T = 0.25;
edges_sobel = Gnorm > T;

% canny
edges_canny = edge(img, 'canny');   

% prikaz
figure;

subplot(1,2,1);
imshow(edges_sobel);
title('Sobelov detektor (prag = 0.25)');

subplot(1,2,2);
imshow(edges_canny);
title('Cannyjev detektor (MATLAB edge)');

