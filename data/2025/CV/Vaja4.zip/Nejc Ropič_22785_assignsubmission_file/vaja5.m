%% ozadje iz 3. naloge
video = VideoReader('squash.avi');
frames = read(video,[1, Inf]); 
[height, width, c, num_frames] = size(frames);

step = 40;
frames_len = floor(num_frames / step);
frames4D = zeros(height,width,c, frames_len);

frame_counter = 0;
for f = 1:step:num_frames
    
    frame_counter = frame_counter + 1;
    frame = frames(:,:,:,f);
    frames4D(:,:,:,frame_counter) = frame;
end

frames4D = frames4D(:,:,:,1:frame_counter);
mode_double = mode(frames4D,4);
modus = uint8(mode_double);

%% meje
P1_R_min = 110; P1_R_max = 170; 
P1_G_min = 50; P1_G_max = 70; 
P1_B_min = 60; P1_B_max = 110; 

P2_R_min = 100; P2_R_max = 180; 
P2_G_min = 170; P2_G_max = 190; 
P2_B_min = 170; P2_B_max = 210; 
%%
video = VideoReader('squash.avi');
frames = read(video,[1 Inf]);
[H,W,~,num_frames] = size(frames);

step = 40;
cnt = 0;
for f = 1:step:num_frames
    cnt = cnt + 1;
    frames4D(:,:,:,cnt) = frames(:,:,:,f);
end
modus = uint8(mode(frames4D,4));
%%
writer = VideoWriter('squash_vaja5_kombinirano.avi');
open(writer);

prag = 70;

for f = 1:num_frames
    frame = frames(:,:,:,f);

    % slika razlike
    razlika = double(frame) - double(modus);
    slika_razlike = sqrt(razlika(:,:,1).^2 + ...
                         razlika(:,:,2).^2 + ...
                         razlika(:,:,3).^2);

    binary = slika_razlike > prag;
    binary = bwmorph(binary,'clean');
    binary = bwmorph(binary,'close');
    binary = bwmorph(binary,'majority');

    [labeled, ~] = bwlabel(binary);
    props = regionprops(labeled,'Area','Centroid','BoundingBox');

    if numel(props) < 2
        continue
    end

    [~, idx] = maxk([props.Area],2);
    p1 = props(idx(1));
    p2 = props(idx(2));
    % doloci igralca
    [type1, col1] = doloci_igralca(frame, p1.BoundingBox);
    [type2, col2] = doloci_igralca(frame, p2.BoundingBox);

    % izris
    figure(1); clf; imshow(frame); hold on;

    rectangle('Position',p1.BoundingBox,'EdgeColor',col1,'LineWidth',2);
    plot(p1.Centroid(1),p1.Centroid(2),[col1 '+'],'LineWidth',2);
    text(p1.Centroid(1),p1.Centroid(2)-20,type1,'Color',col1,...
        'FontSize',12,'FontWeight','bold');

    rectangle('Position',p2.BoundingBox,'EdgeColor',col2,'LineWidth',2);
    plot(p2.Centroid(1),p2.Centroid(2),[col2 '+'],'LineWidth',2);
    text(p2.Centroid(1),p2.Centroid(2)-20,type2,'Color',col2,...
        'FontSize',12,'FontWeight','bold');

    hold off;

    F = getframe(gca);
    writeVideo(writer,F);
end

close(writer);

function [label, color] = doloci_igralca(frame, bb)

    % pragovi
    P1_R_min = 110; P1_R_max = 170;
    P1_G_min = 50;  P1_G_max = 70;
    P1_B_min = 60;  P1_B_max = 110;

    bb = round(bb);

    roi = frame(bb(2):bb(2)+bb(4)-1, ...
                bb(1):bb(1)+bb(3)-1, :);

    R = roi(:,:,1);
    G = roi(:,:,2);
    B = roi(:,:,3);

    % maska rdečega znotraj ROI
    red_mask = (R >= P1_R_min & R <= P1_R_max & ...
                G >= P1_G_min & G <= P1_G_max & ...
                B >= P1_B_min & B <= P1_B_max);

    % delež rdečih pikslov
    red_ratio = sum(red_mask(:)) / numel(red_mask);

    % prag – dovolj že majhen delež
    if red_ratio > 0.03
        label = 'Rdeci igralec';
        color = 'r';
    else
        label = 'Beli igralec';
        color = 'b';
    end
end

function [cent1, cent2, bb1, bb2] = najdi_igralca(binary_image)

    [labeled, ~] = bwlabel(binary_image);
    props = regionprops(labeled, 'Area', 'Centroid', 'BoundingBox');

    % indeks dveh največjih komponent
    [~, idx] = maxk([props.Area], 2);

    p1 = props(idx(1));
    p2 = props(idx(2));

    % vrni težišča
    cent1 = p1.Centroid;
    cent2 = p2.Centroid;

    % vrni bounding box-a
    bb1 = p1.BoundingBox;
    bb2 = p2.BoundingBox;
end
