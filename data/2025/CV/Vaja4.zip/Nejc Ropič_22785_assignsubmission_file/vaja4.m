%% ozadje iz 3. naloge
video = VideoReader('squash.avi');
frames = read(video,[1, Inf]); 
[height, width, c, num_frames] = size(frames);

step = 40;
frames_len = floor(num_frames / step);
frames4D = zeros(height,width,c, frames_len);

frame_counter = 0;
for f = 1:step:num_frames
    
    frame_counter = frame_counter + 1;
    frame = frames(:,:,:,f);
    frames4D(:,:,:,frame_counter) = frame;
end

frames4D = frames4D(:,:,:,1:frame_counter);
mode_double = mode(frames4D,4);
modus = uint8(mode_double);
%%
vse_slike_razlike = zeros(height,width,num_frames);
for f = 1:num_frames
    frame = frames(:,:,:,f);
    razlika = double(frame) - double(modus);
    slika_razlike = sqrt( razlika(:,:,1).^2 + ...
                          razlika(:,:,2).^2 + ...
                          razlika(:,:,3).^2 );

    vse_slike_razlike(:,:,f) = slika_razlike;
    
end
imagesc(vse_slike_razlike(:,:,1));
colormap gray;
colorbar;
title('Razlika med sliko in ozadjem');
%% dolocanje praga s histogramom
%figure;
%histogram(slika_razlike(:), 200);
frame = frames(:,:,:,1);
    razlika = double(frame) - double(modus);
    slika_razlike = sqrt( razlika(:,:,1).^2 + ...
                          razlika(:,:,2).^2 + ...
                          razlika(:,:,3).^2 );

    vse_slike_razlike(:,:,1) = slika_razlike;
    prag = 30;
    
    binary = slika_razlike > prag;
    binary = bwmorph(binary, 'clean');      % odstrani samotne piksele
    binary = bwmorph(binary, 'close');      % zapolni luknje
    binary = bwmorph(binary, 'majority');   % popravlja male artefakte



figure;
imagesc(binary);
colormap gray;
colorbar;
title("Binarna slika (threshold)");
%%
writer = VideoWriter('oznaceni_igralci.avi');
open(writer);
for f = 1:num_frames
    frame = frames(:,:,:,f);     % izvirni frame
    
    % izračun slike razlike
    razlika = double(frame) - double(modus);
    slika_razlike = sqrt( razlika(:,:,1).^2 + ...
                          razlika(:,:,2).^2 + ...
                          razlika(:,:,3).^2 );

    prag = 30;
    binary = slika_razlike > prag;

    % morfološke operacije
    binary = bwmorph(binary, 'clean');
    binary = bwmorph(binary, 'close');
    binary = bwmorph(binary, 'majority');

    % najdi igralca (centroid + bounding box)
    [c1, c2, bb1, bb2] = najdi_igralca(binary);

    % izris
    figure(1); clf;
    imshow(frame);
    hold on;

    % težišča
    plot(c1(1), c1(2), 'r+', 'LineWidth', 2, 'MarkerSize', 12);
    plot(c2(1), c2(2), 'r+', 'LineWidth', 2, 'MarkerSize', 12);

    % pravokotnika
    rectangle('Position', bb1, 'EdgeColor', 'g', 'LineWidth', 2);
    rectangle('Position', bb2, 'EdgeColor', 'g', 'LineWidth', 2);

    hold off;
    drawnow;

    % zapis v video
    F = getframe(gca);         % zajame sliko iz figure
    writeVideo(writer, F);

end

close(writer);



function [cent1, cent2, bb1, bb2] = najdi_igralca(binary_image)

    [labeled, ~] = bwlabel(binary_image);
    props = regionprops(labeled, 'Area', 'Centroid', 'BoundingBox');

    % indeks dveh največjih komponent
    [~, idx] = maxk([props.Area], 2);

    p1 = props(idx(1));
    p2 = props(idx(2));

    % vrni težišča
    cent1 = p1.Centroid;
    cent2 = p2.Centroid;

    % vrni bounding box-a
    bb1 = p1.BoundingBox;
    bb2 = p2.BoundingBox;
end
