img = imread('hotel.jpg');
gray = rgb2gray(img);

%------------------ SOBEL ---------------------%
Sx = [1 0 -1; 2 0 -2; 1 0 -1];
Sy = [1 2 1; 0 0 0; -1 -2 -1];


img_d = double(gray);
Gx = conv2(img_d, Sx, 'same');
Gy = conv2(img_d, Sy, 'same');
G = sqrt(Gx.^2 + Gy.^2);
Gnorm = mat2gray(G);

T = 0.25; % threshold / prag
edges_sobel = Gnorm > T; % robovi glede na threshold
% odstranim robove 
edges_sobel(1,:) = 0;
edges_sobel(end,:) = 0;
edges_sobel(:,1) = 0;
edges_sobel(:,end) = 0;


% canny
edges_canny = edge(gray, 'canny');

% houghova transformacija
H_sobel = HoughTransform(edges_sobel);
H_canny = HoughTransform(edges_canny);

% izris k in n parametrov
A_normirana = mat2gray(H_sobel);
figure;
imshow(A_normirana, []);
colormap('gray');
colorbar;
xlabel('n');
ylabel('k');
%%
%------------------ DRAW LINES ----------------%
N = 5;

drawLines(img, H_sobel, N, 'Sobel');
drawLines(img, H_canny, N, 'Canny');


function A = HoughTransform(edges)

    [H, W] = size(edges);

    % diskretizacija k in n parametrov
    k_vals = -2:0.01:2;       
    n_vals = -200:1:200;      % 401 values

    num_k = length(k_vals);
    num_n = length(n_vals);

    %  priprava Houghovega prostora
    A = zeros(num_k, num_n);
    
    [y_idxs, x_idxs] = find(edges);

    % zanka čez vse robove
    for idx = 1:length(x_idxs)
        x = x_idxs(idx);
        y = y_idxs(idx);

        for ik = 1:num_k
            k = k_vals(ik);

            n = y - k*x;

            if n < -200 || n > 200
                continue;
            end

            % index for n = round((n - n_min) / step) + 1
            in = round(n - (-200)) + 1;    % step = 1 → easy

            A(ik, in) = A(ik, in) + 1;
        end
    end
end
