% Naloga 3 – Izračun slike ozadja iz videa 
% Mihaela Temelkova & Jakob Suhadolc
 
v = VideoReader('squash.avi');
frames = read(v, [1 Inf]);
video_size=size(frames);
stack = frames(:,:,:,1:20:end); %grem po cel posnetek oz frame za 20 korak

% Izračun slike ozadja z mode
bg_double = mode(stack, 4);  

% Pretvori v uint8 in prikaži
bg = uint8(bg_double);
figure;
imshow(bg);
title('Ozadje');
imwrite(bg, 'background_squash.png');
