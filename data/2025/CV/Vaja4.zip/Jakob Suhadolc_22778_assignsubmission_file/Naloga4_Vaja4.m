% Naloga 4 Detekcija podrocij in morfoloske operacije
% Mihaela Temelkova & Jakob Suhadolc


% preberemo sliko ozadja in video
bg = imread('background_squash.png');
v  = VideoReader('squash.avi');

% vzamemo prvi frame in izračunamo razliko z ozadjem - prikaz
frame = readFrame(v);
diff  = double(frame) - double(bg);      % razlika po RGB kanalih            
diff  = sqrt(sum(diff.^2, 3));           % evklidska razdalja v RGB

figure;
imagesc(diff);
colormap gray;
colorbar;
title('Prikaz razlike');

% testiranje morfoloske operacije
threshold = 60;
bw = diff > threshold;
bw = bwmorph(bw, 'open',2);
bw = bwmorph(bw, 'close',2);
bw = bwmorph(bw, 'clean');
bw = bwmorph(bw, 'majority');
figure
imagesc(bw)
colormap gray;
colorbar;

%%
% vrnemo se na začetek in preberemo vse frame-e v 4D matriko
v.CurrentTime = 0;
frames = read(v, [1 Inf]);              
video_size = size(frames);

% pripravimo nov video za rezultat
new_video = zeros(video_size, 'uint8');

% prag med igralcem in ozadjem
threshold = 60;

% območje igrišča (brez publike)
row_min = 50; row_max = 250;
col_min = 50; col_max = 320;

for f = 1:video_size(4)

    % vzamemo f-ti frame
    frame = frames(:,:,:,f);

    % izračunamo sliko razlike
    diff  = double(frame) - double(bg);
    diff  = sqrt(sum(diff.^2, 3));

    % 1 = dovolj drugačno od ozadja → kandidat za igralca
    bw = diff > threshold;

    % zadržimo samo pixle v območju igrišča, ostalo = 0
    bw_filtered = false(size(bw));
    bw_filtered(row_min:row_max, col_min:col_max) = ...
        bw(row_min:row_max, col_min:col_max);
    bw = bw_filtered;

    % morfološko čiščenje binarne slike
    bw = bwmorph(bw, 'open',2);
    bw = bwmorph(bw, 'close',2);
    bw = bwmorph(bw, 'clean');
    bw = bwmorph(bw, 'majority');

    % označimo povezane komponente
    [labels, num] = bwlabel(bw);
    stats = regionprops(labels, 'Area', 'BoundingBox');

    boxes   = [];   % seznam pravokotnikov ali krogov
    centers = [];   % težišča igralcev

    if num >= 1
        areas = [stats.Area];
        [~, order] = sort(areas, 'descend');
        k = min(2, num);     % največ 2 igralca

        for i = 1:k
            s = stats(order(i));

            boxes   = [boxes;   s.BoundingBox];
          
        end
    end

    % narišemo označbe direktno v sliko (brez figure, brez ax)
    if ~isempty(boxes)
        % pravokotniki okoli igralcev
        frame = insertShape(frame, 'Rectangle', boxes, ...
                            'Color', 'red', 'LineWidth', 2);
    end

    % shranimo obdelan frame v novi video
    new_video(:,:,:,f) = frame;
end

% zapišemo novi video na disk
writer_object = VideoWriter('squash_tracking.avi');
open(writer_object);
writeVideo(writer_object, new_video);
close(writer_object);
