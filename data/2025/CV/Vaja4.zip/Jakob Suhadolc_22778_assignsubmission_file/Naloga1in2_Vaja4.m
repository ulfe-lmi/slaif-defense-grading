% Naloga 1 Izlocanje robov 
% Mihaela Temelkova & Jakob Suhadolc

img = imread('hotel.jpg');
Igray = rgb2gray(img);


Sx = [1 0 -1; 2 0 -2; 1 0 -1];
Sy = [1 2 1; 0 0 0; -1 -2 -1];

Gx = conv2(Igray, Sx);
Gy = conv2(Igray, Sy);

G=uint8(sqrt(Gx.^2+Gy.^2));
edges_sobel=G>200;

edges_sobel(1:2, :)       = 0;          
edges_sobel(end-1:end, :) = 0;          
edges_sobel(:, 1:2)       = 0;          
edges_sobel(:, end-1:end) = 0;   

edges_canny = edge(Igray, 'canny');

figure;
subplot(2,2,1); imshow(Igray); title('Sivinska slika');
subplot(2,2,3); imshow(edges_sobel); title('Sobel');
subplot(2,2,4); imshow(edges_canny); title('Canny');

%% Naloga 2 Detekcija podrocij in morfoloske operacije

%Uporabimo na sliko iz sobela in cannyja HoughTransform
H_sobel = HoughTransform(edges_sobel);
H_canny = HoughTransform(edges_canny);

k = -2:0.01:2;
n = -200:1:200;

figure;
imagesc(n, k, H_sobel); colormap('gray'); colorbar; xlabel('n'); ylabel('k'); title('Hough – Sobel');
figure;
imagesc(n, k, H_canny); colormap('gray'); colorbar; xlabel('n'); ylabel('k'); title('Hough – Canny');

% Uporabimo gotovo funkcijo za risanje 5 premic
N = 5;
drawLines(img, H_sobel, N, 'Sobel');
drawLines(img, H_canny, N, 'Canny');


% Houghov algoritam
function HoughSpace = HoughTransform(image)

%definiramo intervali in houhgov prostor
k = -2:0.01:2;
n = -200:1:200;
HoughSpace = zeros(length(k), length(n));

%Najdemo vse piksle ki so svetli, rob
[ys, xs] = find(image);

% za vsak piksel gre cez vsake k in poracuna n, preveri ce je ta n v
% intervalu in steje glas, ki ga posamezen piksel za kombinacijo ki,ni da 
for idx = 1:numel(xs)
    x = xs(idx);
    y = ys(idx);
    for ki = 1:length(k)
        kval = k(ki);
        nval = y - kval * x;
        if nval >= -200 && nval <= 200
            ni = round(nval + 200) + 1;
            HoughSpace(ki, ni) = HoughSpace(ki, ni) + 1;
        end
    end
end
end
