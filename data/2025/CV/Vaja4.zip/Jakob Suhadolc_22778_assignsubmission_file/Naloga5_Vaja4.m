% NALOGA 5 – sledenje igralcev in razpoznavanje po barvi majice
% % Mihaela Temelkova & Jakob Suhadolc

% preberemo sliko ozadja in video
bg = imread('background_squash.png');
v  = VideoReader('squash.avi');

v.CurrentTime = 0;
frames     = read(v, [1 Inf]);      % vsi frame-i videa
video_size = size(frames);

% pripravimo nov video za rezultat
new_video = zeros(video_size, 'uint8');

threshold = 60;              % prag za sliko razlike

% območje igrišča (brez publike)
row_min = 50; row_max = 250;
col_min = 50; col_max = 320;

for f = 1:video_size(4)

    % vzamemo f-ti frame
    frame = frames(:,:,:,f);

    % evklidska razdalja v RGB
    diff  = double(frame) - double(bg);
    diff  = sqrt(sum(diff.^2, 3));

    % binarna slika: 1 = dovolj drugačno od ozadja
    bw = diff > threshold;

    % maska igrišča, da publika odpade
    bw_filtered = false(size(bw));
    bw_filtered(row_min:row_max, col_min:col_max) = ...
        bw(row_min:row_max,  col_min:col_max);
    bw = bw_filtered;

    % morfološko čiščenje
    bw = bwmorph(bw, 'open', 3);
    bw = bwmorph(bw, 'close', 3);
    bw = bwmorph(bw, 'clean');
    bw = bwmorph(bw, 'majority');

    % povezana področja
    [labels, num] = bwlabel(bw);
    stats = regionprops(labels, 'Area', 'Centroid', ...
                                 'BoundingBox', 'PixelIdxList');

    boxes       = [];   % pravokotniki okoli igralcev
    centers     = [];   % težišča igralcev
    labels_text = {};   % oznake igralcev (A\B)

    if num >= 1
        % sortiramo regije po velikosti in vzamemo največ 2
        areas = [stats.Area];
        [~, order] = sort(areas, 'descend');
        k = min(2, num);          % največ 2 igralca

        % RGB kanali trenutnega frame-a za razpoznavanje barve
        R = double(frame(:,:,1));
        G = double(frame(:,:,2));
        B = double(frame(:,:,3));

        red_dom_vec = zeros(k,1);   % rdečost vsake regije

        for i = 1:k
            s = stats(order(i));

            % geometrija (detekcija)
            boxes   = [boxes;   s.BoundingBox];
            centers = [centers; s.Centroid];

            % barva (razpoznavanje)
            pix   = s.PixelIdxList;
            meanR = mean(R(pix));
            meanG = mean(G(pix));
            meanB = mean(B(pix));

            % rdečost: koliko je R večji od G in B
            red_dom_vec(i) = meanR - max(meanG, meanB);
        end

        % klasifikacija: B - bolj rdeč, A - manj rdeč
        labels_text = cell(k,1);
        if k == 2
            [~, idxRed]  = max(red_dom_vec);
            idxWhite     = 3 - idxRed;   % ker sta samo 1 in 2

            labels_text{idxRed}   = 'B';   % rdeč igralec
            labels_text{idxWhite} = 'A';   % bel igralec
            
        elseif k == 1
            if red_dom_vec(1) > 0
                labels_text{1} = 'B';
            else
                labels_text{1} = 'A';
            end
        end
    end

   if ~isempty(boxes) && ~isempty(centers)
    for i = 1:size(boxes,1)

        if strcmp(labels_text{i}, 'B')      % rdeč igralec
            rectColor = 'red';
            textColor = 'red';             % tudi črka rdeča
        else                                % bel igralec (A)
            rectColor = 'white';
            textColor = 'white';           % črka bela
        end

        % pravokotnik samo za tega igralca
        frame = insertShape(frame, 'Rectangle', boxes(i,:), ...
                            'Color', rectColor, 'LineWidth', 2);

        % črka samo za tega igralca
        frame = insertText(frame, centers(i,:), labels_text{i}, ...
                           'BoxOpacity', 0, ...
                           'TextColor', textColor, ...
                           'FontSize', 16, 'AnchorPoint', 'Center');
    end
end

    % shranimo obdelan frame v novi video
    new_video(:,:,:,f) = frame;
end

% zapišemo novi video na disk
writer_object = VideoWriter('squash_tracking_color.avi');
open(writer_object);
writeVideo(writer_object, new_video);
close(writer_object);
