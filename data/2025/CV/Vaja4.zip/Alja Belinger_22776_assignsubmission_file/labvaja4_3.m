%% labvaja4_3

clear all; close all; clc;

video = VideoReader('squash.avi');

% vzem vsak 10. frame
step = 10;

frames = {};   % za shranjevanje posameznih frameov
count = 1;

%% 2) Preberemo izbrane frame iz videja
while hasFrame(video)
    frame = readFrame(video);

    if mod(count, step) == 0
        frames{end+1} = frame;   % shran sliko
    end

    count = count + 1;
end

numFrames = length(frames);
disp(['Uporabljenih frameov: ', num2str(numFrames)]);

%% 3) Zloži frame v 4D matriko: H × W × 3 × N
H = size(frames{1},1);
W = size(frames{1},2);

stack = zeros(H, W, 3, numFrames, 'uint8');

for i = 1:numFrames
    stack(:,:,:,i) = frames{i};
end

%% 4)  MEDIANA
background = median(stack, 4);   % median po 4. dimenziji

background = uint8(background);

%% 5) Prikaž rezultat
figure;
imshow(background);
title('Izračunano ozadje squash igrišča');

save('background.mat','background');
