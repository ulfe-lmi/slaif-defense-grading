%% labvaja4_5
clear all; close all; clc;

% BRANJE VZORCEV

% beli vzorec
whiteSample = imread('belavzorec1.jpg');
whiteHSV = rgb2hsv(im2double(whiteSample));
whiteHist = imhist(whiteHSV(:,:,2)); % histogram saturacije
whiteHist = whiteHist / sum(whiteHist);

% rdeč vzorec
% redSample = uint8(zeros(50,50,3));
% redSample(:,:,1) = 180;  % R
% redSample(:,:,2) = 20;   % G
% redSample(:,:,3) = 20;   % B
redSample = imread('rdecavzorec.jpg');
redHSV = rgb2hsv(im2double(redSample));
redHist = imhist(redHSV(:,:,2));
redHist = redHist / sum(redHist);

% Video in ozadje
video = VideoReader('squash.avi');
load background.mat;
background = uint8(background);

out = VideoWriter('squash_colorID.mp4','MPEG-4');
out.FrameRate = video.FrameRate;
open(out);

% Parametri segmentacije
th = 25;
minArea = 250;
se = strel('disk',3);

figure;


% prevIsRed = [];  

while hasFrame(video)

    frame = readFrame(video);

    
    D = double(frame) - double(background);
    diff = sqrt(sum(D.^2,3));
    bw = diff > th;

    bw = imopen(bw,se);
    bw = imclose(bw,se);
    bw = bwareaopen(bw,minArea);
    bw = imfill(bw,'holes');

    L = bwlabel(bw);
    stats = regionprops(L,'Area','Centroid','BoundingBox');

    imshow(frame); hold on;

if ~isempty(stats)
    [~,idx] = sort([stats.Area],'descend');
    idx = idx(1:min(2, numel(idx)));

    M = numel(idx);
    redScoreList = zeros(1,M);
    BBlist = zeros(M,4);
    Clist = zeros(M,2);

    % redscore
    for i = 1:M
        p = stats(idx(i));
        BBlist(i,:) = p.BoundingBox;
        Clist(i,:) = p.Centroid;

        BB = p.BoundingBox;
        x1 = max(1, floor(BB(1)));
        y1 = max(1, floor(BB(2)));
        x2 = min(size(frame,2), ceil(BB(1)+BB(3)-1));
        y2 = min(size(frame,1), ceil(BB(2)+BB(4)-1));
        sub = frame(y1:y2, x1:x2, :);

        Hs = size(sub,1);
        Ws = size(sub,2);
        
        % višina torza 
        yA = round(Hs*0.15);
        yB = round(Hs*0.40);
        
        % dinamična širina
        aspect = Ws / Hs;
        
        if aspect < 0.55
            xA = round(Ws*0.40);
            xB = round(Ws*0.60);
        else
            xA = round(Ws*0.30);
            xB = round(Ws*0.70);
        end
        
        shirt = sub(yA:yB, xA:xB, :);


        Hsv = rgb2hsv(im2double(shirt));
        H = Hsv(:,:,1);
        S = Hsv(:,:,2);

        % maska
        mask = S > 0.15;

        if nnz(mask) < 50
            redScoreList(i) = 0;
        else
            d = min(abs(H-0), abs(H-1));      % razdalja do rdece
            redScoreList(i) = mean(d(mask) < 0.14);
        end
    end

    % Dodeli identiteto: bolj rdec = A, drugi = B
    if M == 2
        [~, ridx] = max(redScoreList);
        widx = 3 - ridx;

        labels = strings(1,2);
        cols = strings(1,2);
        labels(ridx) = "A (rdeci)"; cols(ridx) = "red";
        labels(widx) = "B (beli)";  cols(widx) = "white";

    end

    % Narisi
    for i = 1:M
        rectangle('Position', BBlist(i,:), 'EdgeColor','g','LineWidth',2);
        plot(Clist(i,1), Clist(i,2), 'go','MarkerSize',8,'LineWidth',2);
        text(Clist(i,1), Clist(i,2)-20, labels(i), 'Color', cols(i), ...
             'FontSize',14,'FontWeight','bold');
    end
end


    F = getframe(gcf);
    writeVideo(out, F.cdata);
    hold off;

end

close(out);