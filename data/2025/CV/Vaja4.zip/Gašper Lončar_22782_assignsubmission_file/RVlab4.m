%% 4. vaja 1. naloga
hotel = imread("hotel.jpg");
hotel_siv = rgb2gray(hotel);
hotel_siv = im2double(hotel_siv);

sobelX = [1 0 -1; 2 0 -2; 1 0 -1];
sobelY = [1 2 1; 0 0 0; -1 -2 -1];

gradX = conv2(hotel_siv, sobelX,'same');
gradY = conv2(hotel_siv, sobelY, 'same');

grad = sqrt(gradX.^2 + gradY.^2);
binarn = graythresh(grad);  % prag od 0 do 1
sobel = grad >= binarn;

canny = edge(hotel_siv,"canny", [0.05 0.15], 1.2);  % sigma na koncu

figure; 
subplot(1,2,1); imshow(sobel);
subplot(1,2,2); imshow(canny);

%% hough transform
hotel2d_canny = canny;
hotel2d_sobel = sobel;

k = -2:0.01:2;
n = -200:1:200;
Nk = length(k);
Nn = length(n);

H_prostor = zeros(Nk,Nn);
[visina, sirina] = size(hotel2d_canny);

[x, y] = meshgrid(1:sirina, 1:visina);
stolpci = x(hotel2d_canny);
vrstice = y(hotel2d_canny);

robovi = 0.5:1:(Nn+0.5);
for i = 1:Nk
    stevecN = vrstice - k(i).*stolpci;      % n = y 'kx
    indexN = round(stevecN - n(1) + 1);     % od 1 do Nn
    maska = (indexN >= 1) & (indexN <= Nn);
    stevec = histcounts(indexN(maska), robovi);
    H_prostor(i, :) = H_prostor(i, :) + stevec;
end

figure; imagesc(n, k, H_prostor); axis xy; xlabel('n'); ylabel('k'); colorbar;


N = 5; % number of lines we want to draw
%H_prostor = HoughTransform(hotel);
drawLines(hotel,H_prostor,N,'Canny');