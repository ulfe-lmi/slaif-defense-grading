%% RV4_video
C=VideoReader('squash.avi');
orig_okvirji=read(C,[1 Inf]);
video_size=size(orig_okvirji);
st_frameov=video_size(4);
korak = 10;
index = 1:korak:st_frameov;
N = numel(index);


% prazna tabelca velikosti videa za število frameov
okvirji = orig_okvirji(:,:,:, index); 
ozadje = zeros(video_size(1), video_size(2), 3, 'uint8');

for i =1:3
    M = reshape(okvirji(:,:,i,:), video_size(1)*video_size(2),N);
    m = mode(M, 2);     % najbolj pogosti
    ozadje(:,:,i) = reshape(uint8(m), video_size(1), video_size(2));
end

imshow(ozadje); imwrite(ozadje,'ozadje.png');

%% 4. naloga

[visina, sirina, ~, st_frameov] = size(orig_okvirji);

% slika razlike od ozadja
prvi_frame = orig_okvirji(:,:,:,1);
evklidska_razlika = sqrt(sum((double(prvi_frame) - double(ozadje)).^2, 3));
prag = max(30, 0.35 * max(evklidska_razlika(:)));

figure; imshow(prvi_frame); impixelinfo;

figure; imagesc(evklidska_razlika); colormap gray; axis image; colorbar;

% video z označenima igralcema (kvadratki)
vid_id = VideoWriter('squash_identiteta.avi');
vid_id.FrameRate = C.FrameRate;
open(vid_id);

r = 5;  % polmer kvadrata

% ignoriramo območje na levi strani igrišča z navijači
rob = round(0.1*sirina);
roiMaska = true(visina, sirina);
roiMaska(:,1:rob) = false;

% identiteta
ident = false;
rdec = [255 0 0];
bel = [255 255 255];

for i = 1:st_frameov
    okvir = orig_okvirji(:,:,:,i);                          % RGB uint8 okvir

    % slika evklidske razlike 
    evd_raz = sqrt(sum((double(okvir) - double(ozadje)).^2, 3));

    % morfologije
    BW = evd_raz > prag;
    BW = bwmorph(BW, 'clean');        % odstrani osamljene piksle (sol)
    BW = bwmorph(BW, 'majority');     % večinsko glasovanje (gladi šum)
    BW = bwmorph(BW, 'close');        % morfološko zapiranje (zapre reže)
    BW = bwmorph(BW, 'fill');         % zapolni luknje znotraj objektov
    BW = bwmorph(BW, 'spur', 2);      % odstrani kratke "resice" (2 iteraciji)

    BW = BW & roiMaska;

    % 2 največji razliki za detekcijo
    [L, num] = bwlabel(BW, 8);
    Fout = okvir;

    if num > 0
        S = regionprops(L, 'Area', 'Centroid', 'PixelIdxList');

        % vzemi največji 2 področji
        [~, idx] = maxk([S.Area], min(2,num));

        R_delta = 85;   % R mora biti toliko večji od G in B za rdeče
        R_min = 140;    % minimalna R 
        B_min = 120;    % minimalna svetlost za belo
        B_max = 30;

        R = double(okvir(:,:,1));
        G = double(okvir(:,:,2));
        B = double(okvir(:,:,3));

        for k = 1:numel(idx)
            c = round(S(idx(k)).Centroid);  % [x y]
            cx = max(1, min(sirina, c(1)));
            cy = max(1, min(visina, c(2)));

            % majhen kvadratek v težišču
            x1 = max(1, cx - r); x2 = min(sirina, cx + r);
            y1 = max(1, cy - r); y2 = min(visina, cy + r);

            piksel = S(idx(k)).PixelIdxList;
            Rm = mean(R(piksel));
            Gm = mean(G(piksel));
            Bm = mean(B(piksel));
            I = (Rm+Gm+Bm)/3;
            razl = max([Rm,Gm,Bm]) - min([Rm,Gm,Bm]);

            jeRdec = (Rm > Gm + R_delta) && (Rm > Bm + R_delta) && (Rm > R_min);
            jeBel = (I > B_min) && (razl < B_max);

            if isRed
                barva = rdec;   
            elseif isWhite
                barva = bel; 
            else
                % po večjem R ali po svetlosti
                if (Rm - max(Gm,Bm)) > 15
                    barva = rdec;
                else
                barva = bel;
                end
            end

            Fout(y1:y2, x1:x2, 1) = barva(1);          
            Fout(y1:y2, x1:x2, 2) = barva(2);
            Fout(y1:y2, x1:x2, 3) = barva(3);
        end
    end
    
    writeVideo(vid_id, Fout);

end

close(vid_id);
