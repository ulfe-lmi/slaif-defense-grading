clc;
clear;
close all;

videoFile = 'squash.avi';
vidObj = VideoReader(videoFile);

frameStep = 10;
framesToUse = floor(vidObj.NumFrames / frameStep);

%4D matrica
sampleFrames = zeros(vidObj.Height, vidObj.Width, 3, framesToUse, 'uint8');
count = 1;

for i = 1:frameStep:vidObj.NumFrames
    frame = read(vidObj, i); %i-ti frame iz videa
    sampleFrames(:,:,:,count) = frame;
    count = count + 1;
end

bgImage = median(sampleFrames, 4);
bgImage = uint8(bgImage);

vidObj.CurrentTime = 0;
testFrame = readFrame(vidObj);

diffTest = sqrt(sum((double(testFrame) - double(bgImage)).^2, 3)); %Euklidska udaljenost

figure;
imagesc(diffTest);
colormap gray;
colorbar;
title('Slika razlike (evklidska RGB razdalja)');

outputFile = 'squash_tracked.avi';
vidWriter = VideoWriter(outputFile);
open(vidWriter);

thresholdDiff = 50; %sve iznad ovoga se smatra pokretnim objektom
markerSize = 5;

vidObj.CurrentTime = 0;

while hasFrame(vidObj)
    frame = readFrame(vidObj);

    diffImage = sqrt(sum((double(frame) - double(bgImage)).^2, 3));

    bw = diffImage > thresholdDiff;

    bw = bwmorph(bw,'close');
    bw = bwmorph(bw,'open');

    [labeled, num] = bwlabel(bw);
    stats = regionprops(labeled,'Centroid','Area');

    if num > 0  %sortiranje komp po povrsini (najvece prvo)
        areas = [stats.Area];
        [~, idx] = sort(areas, 'descend');
        idx = idx(1:min(2,length(idx)));

        for k = idx
            cx = round(stats(k).Centroid(1)); %centroid odabrane komponente
            cy = round(stats(k).Centroid(2));

            xRange = max(cx-markerSize,1):min(cx+markerSize,size(frame,2)); %kvadratic oko centroida
            yRange = max(cy-markerSize,1):min(cy+markerSize,size(frame,1));

            frame(yRange,xRange,1) = 255; %bojanje kvadratica
            frame(yRange,xRange,2) = 0;
            frame(yRange,xRange,3) = 0;
        end
    end

    writeVideo(vidWriter, frame);
end

close(vidWriter);

disp(['Video saved as: ', outputFile]);
