clc;
clear;
close all;

load('edges_hotel.mat');

k_min = -2;
k_max =  2;
n_min = -200;
n_max =  200;

num_bins = 400;

k_vals = linspace(k_min, k_max, num_bins+1);
n_vals = linspace(n_min, n_max, num_bins+1);

edges_all = {edges_sobel, edges_canny};
titles = {'Hough – Sobel robovi', 'Hough – Canny robovi'};

N = 5;

for t = 1:2

    edges = logical(edges_all{t});
    [rows, cols] = size(edges);

    accumulator = zeros(length(k_vals), length(n_vals));

    for y = 1:rows
        for x = 1:cols
            if edges(y,x)
                for ki = 1:length(k_vals)
                    k = k_vals(ki);
                    n = y - k * x;

                    if n >= n_min && n <= n_max
                        ni = round((n - n_min) / (n_max - n_min) * num_bins) + 1;
                        accumulator(ki, ni) = accumulator(ki, ni) + 1;
                    end
                end
            end
        end
    end

    acc = accumulator;
    lines = zeros(N,2);

    for i = 1:N
        [~, idx] = max(acc(:));
        [ki, ni] = ind2sub(size(acc), idx);

        lines(i,1) = k_vals(ki);
        lines(i,2) = n_vals(ni);

        acc(ki, ni) = 0;
    end

    figure;
    imshow(img);
    hold on;

    x_vals = 1:cols;

    for i = 1:N
        k = lines(i,1);
        n = lines(i,2);
        y_vals = k * x_vals + n;
        plot(x_vals, y_vals, 'r', 'LineWidth', 2);
    end

    title(titles{t});
    hold off;
end
