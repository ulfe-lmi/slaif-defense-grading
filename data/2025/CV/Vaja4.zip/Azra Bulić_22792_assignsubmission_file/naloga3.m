clc;
clear;
close all;

% Branje videa
videoFile = 'squash.avi';
vidObj = VideoReader(videoFile);

% Parametri
frameStep = 10;  % vsaka 10. slika
framesToUse = floor(vidObj.NumFrames / frameStep);

% Preberi izbrane slike in jih shrani v 4D matriko
sampleFrames = zeros(vidObj.Height, vidObj.Width, 3, framesToUse, 'uint8');

count = 1;
for i = 1:frameStep:vidObj.NumFrames
    frame = read(vidObj, i);
    sampleFrames(:,:,:,count) = frame;
    count = count + 1;
end


% Median je najbolj primerna statistična funkcija za ozadje
bgImage = median(sampleFrames, 4);   % median po 4. dimenziji (frame)
bgImage = uint8(bgImage);            % pretvorba v 8-bit

figure;
imshow(bgImage);
title('Izračunano ozadje posnetka (median)');

