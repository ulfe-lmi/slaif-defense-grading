clc;
clear;
close all;

img = imread('hotel.jpg');

if size(img,3) == 3
    img_gray = rgb2gray(img);
else
    img_gray = img;
end

img_gray = double(img_gray);

Sx = [ 1  0 -1;
       2  0 -2;
       1  0 -1 ];

Sy = [ 1  2  1;
       0  0  0;
      -1 -2 -1 ];

Gx = imfilter(img_gray, Sx, 'replicate');
Gy = imfilter(img_gray, Sy, 'replicate');

G = sqrt(Gx.^2 + Gy.^2);
G = G / max(G(:));

threshold = 0.25;
edges_sobel = G > threshold;

edges_canny = edge(uint8(img_gray), 'canny');

save('edges_hotel.mat', 'edges_sobel', 'edges_canny', 'img');

imwrite(edges_sobel, 'edges_sobel.png');
imwrite(edges_canny, 'edges_canny.png');

figure;

subplot(2,2,1);
imshow(uint8(img_gray));

subplot(2,2,2);
imshow(G, []);

subplot(2,2,3);
imshow(edges_sobel);

subplot(2,2,4);
imshow(edges_canny);
