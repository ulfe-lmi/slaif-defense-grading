clc; clear; close all;

%% Load video
squash = VideoReader('squash.avi');
H = squash.Height;
W = squash.Width;
numFrames = squash.NumFrames;

%% Compute background using median of sampled frames
frameStep = 10;
sampleCount = floor(numFrames/frameStep);
sampleFrames = zeros(H,W,3,sampleCount,'uint8');

for f = 1:sampleCount
    sampleFrames(:,:,:,f) = read(squash,f*frameStep);
end

frameNew = zeros(H,W,3,'uint8');
for c = 1:3
    frameNew(:,:,c) = mode(sampleFrames(:,:,c,:),4);
end

%% Prepare video writer
vidWriter = VideoWriter('squash_tracked_colors.avi');
vidWriter.FrameRate = squash.FrameRate;
open(vidWriter);

%% Process video frame by frame
for k = 1:numFrames
    frame = read(squash,k);
    
    % Euclidean distance from background
    diffImage = sqrt(sum((double(frame)-double(frameNew)).^2,3));
    
    % Threshold & morphology
    bw = diffImage > 50;
    bw = bwmorph(bw,'close');
    bw = bwmorph(bw,'open');
    
    % Label and select two largest blobs
    [L,n] = bwlabel(bw);
    stats = regionprops(L,'Area','Centroid','PixelIdxList');
    areas = [stats.Area];
    if length(areas) < 2
        writeVideo(vidWriter, frame);
        continue
    end
    [~,idxSort] = sort(areas,'descend');
    players = stats(idxSort(1:2));
    centroid = reshape([players.Centroid],2,[])';
    
    % Shirt color detection
    red = 0; white = 0;
    for i = round(centroid(1,2))-10 : round(centroid(1,2))+10
        for j = round(centroid(1,1))-10 : round(centroid(1,1))+10
            if i>0 && i<=H && j>0 && j<=W
                if frame(i,j,1)>100 && frame(i,j,2)<130 && frame(i,j,3)<130
                    red = red +1;
                elseif frame(i,j,1)>100 && frame(i,j,2)>150 && frame(i,j,3)>150
                    white = white +1;
                end
            end
        end
    end
    
    % Draw colored circles
    RGB = frame;
    if red > white
        color1 = [255 0 0]; % Player 1 red
        color2 = [0 0 255]; % Player 2 blue
    else
        color1 = [0 0 255]; % Player 1 blue
        color2 = [255 0 0]; % Player 2 red
    end
    RGB = insertShape(RGB,'circle',[centroid(1,1) centroid(1,2) 20],'Color',color1,'LineWidth',3);
    RGB = insertShape(RGB,'circle',[centroid(2,1) centroid(2,2) 20],'Color',color2,'LineWidth',3);
    
    writeVideo(vidWriter, RGB);
end

close(vidWriter);
disp('Video saved: squash_tracked_colors.avi');
