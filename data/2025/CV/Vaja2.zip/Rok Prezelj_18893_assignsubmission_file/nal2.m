function rectify_chessboard(image_path)
% RECTIFY_CHESSBOARD  Projektivna korekcija šahovnice
% Uporaba:
%   rectify_chessboard('Image_rect1.tif')

    % ---- 1) Branje slike ----
    img = imread(image_path);
    img = double(img); % enoten tip

    % ---- 2) Uporabnik izbere kote ----
    figure('Name','Klikni 4 kote (TL, TR, BR, BL)');
    imshow(img, []); title('Klikni 4 kote: ZG-L, ZG-D, SP-D, SP-L');
    [x, y] = ginput(4);
    moving = [x y];
    plot(moving(:,1), moving(:,2), 'r+', 'MarkerSize', 10, 'LineWidth', 2);

    % ---- 3) Vnos parametrov šahovnice ----
    answ = inputdlg({'Širina (kvadrati):','Višina (kvadrati):','Velikost kvadrata [px]:'}, ...
                    'Parametri', 1, {'12','11','80'});
    if isempty(answ), return; end
    cols = str2double(answ{1}); rows = str2double(answ{2}); sq = str2double(answ{3});
    width = cols*sq;
    height = rows*sq;

    % ---- 4) Projektivna korekcija ----
    fixed = [1 1; width 1; width height; 1 height];
    tform = maketform('projective', moving, fixed);
    corrected = imtransform(img, tform, 'XData',[1 width],'YData',[1 height], ...
                            'FillValues', median(img(:)));

    figure('Name','Korigirana slika'); imshow(corrected, []); title('Projektivno popravljena šahovnica');

    % ---- 5) Izris mreže na originalno sliko ----
    [X, Y] = meshgrid(1:sq:width+1, 1:sq:height+1);
    X(X>width)=width; Y(Y>height)=height;
    tform_inv = maketform('projective', fixed, moving);
    [u, v] = tformfwd(tform_inv, X, Y);

    figure('Name','Original z oglišči');
    imshow(img, []); hold on;
    plot(u, v, 'g.', 'MarkerSize', 10);
    for r=1:size(u,1), plot(u(r,:), v(r,:), 'g-'); end
    for c=1:size(u,2), plot(u(:,c), v(:,c), 'g-'); end
    title('Vsa oglišča kvadratov');
end

% Klic:
rectify_chessboard('Image_rect1.tif');
