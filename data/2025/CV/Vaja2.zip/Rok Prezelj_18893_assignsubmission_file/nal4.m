function radialna_distorzija(image_path)
% RADIALNA_DISTORZIJA – rešitev 3. naloge (z iskanjem optimalnega f preko fminsearch)
%
% Uporaba:
%   radialna_distorzija('Image15.tif')
%
% Postopek:
%   1) Prikaže sliko in te z ginput pozove, da klikneš točke dveh VERTIKALNIH kolon vogalov:
%        – najprej kolona pri ROBU
%        – nato kolona blizu SREDINE
%      (Vsako zaključiš s tipko Enter)
%   2) Izvede korekcijo po danem modelu in s pomočjo fminsearch poišče optimalni f,
%      ki minimizira vsoto kvadratov razdalj do najboljše premice (SSE).
%   3) Prikaže rezultat in izpiše optimalni f.

    if nargin < 1 || isempty(image_path)
        image_path = 'Image15.tif';  % privzeto ime slike
    end

    % --- Branje slike ---
    I = imread(image_path);
    if size(I,3) > 1, I = rgb2gray(I); end
    I = im2double(I);

    % --- Označevanje točk ---
    figure; imshow(I,[]); title('Klikni točke 1. (robne) vertikalne kolone, nato Enter');
    [x1, y1] = ginput; pts1 = [x1 y1];

    title('Zdaj klikni točke 2. (sredinske) vertikalne kolone, nato Enter');
    [x2, y2] = ginput; pts2 = [x2 y2];

    if size(pts1,1) < 2 || size(pts2,1) < 2
        error('Za vsako kolono označi vsaj dve točki.');
    end

    % --- Središče slike ---
    [h, w] = size(I);
    C = [w/2, h/2];

    % ============================================
    % Iskanje najboljšega f z optimizacijo
    % ============================================
    sse_fun = @(f) total_sse(f, pts1, pts2, C);

    f0 = 600;  % začetna ocena
    fprintf('Iščem optimalni f ...\n');
    f_opt = fminsearch(sse_fun, f0, optimset('Display','iter'));
    SSEmin = sse_fun(f_opt);

    fprintf('\nOptimalni f = %.3f (SSE = %.6g)\n', f_opt, SSEmin);
end

% ================================================================
% POMOŽNE FUNKCIJE
% ================================================================

function und = undistort_points_radial(pts, C, f)
% Inverzni model iz navodil naloge:
% r' -> r'_l po:
%   r'_l = -f^2 * (exp(-2r'/f) - 1) / exp(-r'/f)
% Numerično stabilna oblika:
%   r'_l = 2f^2 * sinh(r'/f)
% Nato točko prestavimo vzdolž radialne smeri.

    v = pts - C;                      
    r_prime = hypot(v(:,1), v(:,2));  
    t = r_prime / f;

    r_l_prime = 2 * (f^2) * sinh(t);  
    scale = r_l_prime ./ max(r_prime, eps);
    und = C + [scale scale] .* v;
end

function sse = orth_line_sse(pts)
% Ortogonalna regresija (najmanjši kvadrati)
    mu = mean(pts,1);
    X = pts - mu;
    if size(X,1) < 2
        sse = 0; return
    end
    C = (X.'*X) / size(X,1);
    [V,D] = eig(C);
    [~,iMax] = max(diag(D));
    u = V(:,iMax);
    Pperp = eye(2) - (u*u.');
    residuals = (Pperp * X.').';
    sse = sum(sum(residuals.^2,2));
end

function sse_total = total_sse(f, pts1, pts2, C)
% Skupna napaka za dano vrednost f
    if f <= 0
        sse_total = inf; return
    end
    und1 = undistort_points_radial(pts1, C, f);
    und2 = undistort_points_radial(pts2, C, f);
    sse_total = orth_line_sse(und1) + orth_line_sse(und2);
end
