function radialna_distorzija(image_path)
% RADIALNA_DISTORZIJA – rešitev 3. naloge
% Uporaba:
%   radialna_distorzija('Image15.tif')   % ali pokličeš brez argumenta
%
% Postopek:
%  1) Prikaže sliko in te z ginput pozove, da klikneš točke dveh VERTIKALNIH kolon
%     vogalov: najprej kolona pri ROBU, potem kolona blizu SREDINE (Enter zaključi vsako kolono).
%  2) Za f = 400:20:800 izvede “odpopačenje” točk po danem inverznem modelu in
%     za vsako vrednost f izračuna vsoto kvadratov razdalj do najboljše premice (za obe koloni).
%  3) Nariše graf SSE(f) in izpiše optimalni f.
%
% Zahteve naloge in uporabljeni model so iz navodil vaje (glej PDF). 

    if nargin < 1 || isempty(image_path)
        image_path = 'Image15.tif';  % po navodilih
    end

    % --- Branje slike (v sivine) ---
    I = imread(image_path);
    if size(I,3) > 1, I = rgb2gray(I); end
    I = im2double(I);

    % --- Prikaz in zajem točk ---
    figure; imshow(I,[]); title('Klikni točke 1. (robne) VERTIKALNE kolone, nato Enter');
    [x1, y1] = ginput;  % prva kolona (pri robu)
    pts1 = [x1 y1];

    title('Zdaj klikni točke 2. (sredinske) VERTIKALNE kolone, nato Enter');
    [x2, y2] = ginput;  % druga kolona (blizu centra)
    pts2 = [x2 y2];

    if size(pts1,1) < 2 || size(pts2,1) < 2
        error('Za vsako kolono označi vsaj dve točki.');
    end

    % --- Središče slike (privzamemo približno v središču) ---
    [h, w] = size(I);
    C = [w/2, h/2];  % (cx, cy); če poznaš boljši principal point, ga vnesi tu

    % --- Interval f-jev po navodilih ---
    fs = 400:20:800;
    SSE = zeros(size(fs));

    use_fitline = exist('fitline','file') == 2;  % če imaš kovesi/fitline.m na poti

    % Glavna zanka po f
    for k = 1:numel(fs)
        f = fs(k);

        % Odpopači obe koloni točk
        und1 = undistort_points_radial(pts1, C, f);
        und2 = undistort_points_radial(pts2, C, f);

        % Oceni “linearno” naravnanost (vsota kvadratov razdalj do najboljše premice)
        if use_fitline
            [~, sse1] = fitline(und1); %#ok<ASGLU>  % vrne tudi koeficiente, a tu rabimo sse
            [~, sse2] = fitline(und2);
        else
            % Fallback: ortogonalna regresija (PCA) na točkah – vrne SSE
            sse1 = orth_line_sse(und1);
            sse2 = orth_line_sse(und2);
        end

        SSE(k) = sse1 + sse2;
    end

    % --- Najboljši f ---
    [SSEmin, idx] = min(SSE);
    f_opt = fs(idx);

    % --- Graf ---
    figure;
    plot(fs, SSE, 'o-','LineWidth',1.5); hold on;
    plot(f_opt, SSEmin, 'p', 'MarkerSize',12, 'MarkerFaceColor','auto');
    grid on; xlabel('f'); ylabel('Vsota kvadratov razdalj (SSE)');
    title(sprintf('Radialna distorzija – najboljše f = %d (SSE = %.4g)', f_opt, SSEmin));

    % --- Izhodna informacija ---
    fprintf('Optimalni f = %d (SSE = %.6g)\n', f_opt, SSEmin);
end

% ================= POMOŽNE FUNKCIJE =================

function und = undistort_points_radial(pts, C, f)
% Inverzni model iz navodil naloge:
% r' -> r'_l po:
%   r'_l = -f^2 * (exp(-2 r'/f) - 1) / exp(-r'/f)
% Kar je numerično stabilno izračunati kot:
%   r'_l = 2 f^2 sinh(r'/f)
%
% Nato točko prestavimo vzdolž radialne smeri:
%   und = C + (r'_l / r') * (pts - C)

    v = pts - C;                          % radialni vektorji
    r_prime = hypot(v(:,1), v(:,2));      % popačen radij r'
    t = r_prime / f;

    % Inverzna preslikava (po enačbi iz navodil; stabilno preko sinh)
    r_l_prime = 2 * (f^2) * sinh(t);      % r'_l

    % Izogni se deljenju z 0 v centru (r' == 0)
    scale = r_l_prime ./ max(r_prime, eps);

    und = C + [scale scale] .* v;
end

function sse = orth_line_sse(pts)
% Ortogonalna regresija: najboljša premica v smislu min. kvadratov
% SSE = vsota kvadratov ort. razdalj točk do premice
    mu = mean(pts,1);
    X = pts - mu;
    if size(X,1) < 2
        sse = 0;
        return
    end
    [U,~,~] = svd(X, 'econ');   %#ok<NASGU>
    dir = U(:,1);               % smer glavne komponente v prostoru točk (2D)
    % Aha, U je NxN; za 2D je bolje uporabiti eigenvektor kovariančne matrike:
    C = (X.'*X) / size(X,1);
    [V, D] = eig(C);            %#ok<ASGLU>
    [~, iMax] = max(diag(D));
    u = V(:, iMax);             % smer enotskega vektorja premice

    % Ortogonalna razdalja = norma (I - u u^T)(x - mu)
    Pperp = eye(2) - (u*u.');
    residuals = (Pperp * X.').';
    sse = sum(sum(residuals.^2, 2));
end
