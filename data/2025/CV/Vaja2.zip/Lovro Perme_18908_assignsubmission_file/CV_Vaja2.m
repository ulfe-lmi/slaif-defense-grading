%% Naloga 2 - projektivna transformacija
close all;
clear all;
clc;

checkerboard = imread('Image_rect18.tif');
f1 = figure;
image(repmat(checkerboard,[1,1,3]));
axis image;
uiwait(msgbox('Označi 4 vogale v smeri urinega kazalca, začni zgoraj levo', 'Navodila', 'modal'));
hold on;            %da lahko čez sliko narišemo še scatter za točke
[x,y] = ginput(4);
scatter(x,y,500,'red','x');           %500 je velikost križcev, x je za obliko
hold off;

in_corners = [x,y];

img_size = 480;         %velikost izhodne slike
out_corners = [0 0; img_size-1 0; img_size-1 img_size-1; 0 img_size-1];

T = maketform("projective",in_corners,out_corners);

projected_checkerboard = imtransform(checkerboard, T,'Xdata',[0 img_size-1],'Ydata',[0 img_size-1]);
f2 = figure;
image(repmat(projected_checkerboard,[1,1,3]));
axis image;

% CORNER DETECTION:
% Naredimo gradient sivinske slike. nato izberemo gradient po x in naredimo še enkrat gradient, da dobimo drugi odvod, sedaj gledamo gradient po y
% naredimo binarno sliko, kjer porečemo vse vrhove in tako dobimo območja vrhov. S pomočjo regionprops dobimo središča teh območij, nato samo dodamo točke na slike
% nato še inverzni transform in inverzno transformacijo točk, ki jih overlayamo čez začetno sliko

[gradient_x, gradient_y] = imgradientxy(projected_checkerboard, "prewitt");
f3 = figure;
surf(gradient_x);
[gradient2_x, gradient2_y] = imgradientxy(gradient_x, "prewitt");
f4 = figure;
surf(gradient2_y);
binary_peaks = gradient2_y > 80 | gradient2_y < -80;
f5 = figure;
image(repmat(binary_peaks,[1,1,3]));
axis image;
peak_stats = regionprops(binary_peaks,'Centroid');
peak_centers = cat(1, peak_stats.Centroid);
hold on;
scatter(peak_centers(:,1),peak_centers(:,2),'filled','r');
hold off;
figure(f2);
hold on;
scatter(peak_centers(:,1),peak_centers(:,2),'filled','r');
hold off;
%inverzna tranformacija in transform vogalov na prvotne koordinate
T_inv = fliptform(T);
peaks_original = tformfwd(T_inv,peak_centers);
figure(f1);
hold on;
scatter(peaks_original(:,1),peaks_original(:,2),'filled','r');
hold off;

uiwait(msgbox('Potrdi za nadaljevanje na nalogo 3 in 4', 'Potrditev'));

%% Naloga 3 - Radialna distorzija

close all;
clear all;
clc;

checkerboard = imread('Image15.tif');
f1 = figure;
image(repmat(checkerboard,[1,1,3]));
axis image;
hold on;
%fetch optičnega središča in prikaz na sliki
calib = load("Calib_Results.mat", "cc");    %središčno točko slike naložimo iz kalibracijskih rezultatov prve naloge
scatter(calib.cc(1), calib.cc(2), 'filled');
legend('optical center');

num_points = 12;
uiwait(msgbox('Označi eno vertikalno linijo oglišč na robu šahovnice (12 oglišč)', 'Navodila', 'modal'));
[xe,ye] = ginput(num_points);
scatter(xe,ye,500,'red','x');           %500 je velikost križcev, x je za obliko
legend('optical center', 'uncorrected edge points');

uiwait(msgbox('Označi vertikalno linijo oglišč najbližje sredini slike (12 oglišč)', 'Navodila', 'modal'));
[xc,yc] = ginput(num_points);
scatter(xc,yc,500,'green','x');           %500 je velikost križcev, x je za obliko
legend('optical center', 'uncorrected edge points', 'uncorrected center points');
hold off;

%naredimo fit premice na točke samo za prikaz na sliki
edge_line = fitline([xe.';ye.']);      % transponirane matrike, da so prave oblike za fitline funkcijo
center_line = fitline([xc.';yc.']);
hold on;

%prikaz premic na sliki
fplot(@(x) -edge_line(1)/edge_line(2)*x - edge_line(3)/edge_line(2), [0, size(checkerboard,2)]);
ylim([0, size(checkerboard,1)]);
fplot(@(x) -center_line(1)/center_line(2)*x - center_line(3)/center_line(2), [0, size(checkerboard,2)]);
ylim([0, size(checkerboard,1)]);
legend('optical center', 'uncorrected edge points', 'uncorrected center points'); %še enkrat, drugače začen zraven dodajat še legendo za premice

% IZRAČUN IN KOREKCIJA RADIJEV:
% zapis s koordinatnim središčem v optičnem središču slike
xe_c = xe - calib.cc(1);
ye_c = ye - calib.cc(2);
xc_c = xc - calib.cc(1);
yc_c = yc - calib.cc(2);

% f ki jih bomo sprobali za korekcijo radijev
f = 400:20:800;

% osnovne premice, tokrat s središčnim koordinatnim sistemom, da izračunamo osnovno napako brez korekcij
[edge_line, edge_dist] = fitline([xe_c.';ye_c.']);      % transponirane matrike, da so prave oblike za fitline funkcijo
[center_line, center_dist] = fitline([xc_c.';yc_c.']);
err = zeros(size(f,2) + 1, 3);  %za eno daljši od vektorja f, ker zapišem v 0 originalno napako, druga dimenzija 3 za robne, centralne in seštevek točk
err(1,1) = sqrt(sum(edge_dist.^2));         % v prvo vrstico arraya err zapišemo nekorigirane napake
err(1,2) = sqrt(sum(center_dist.^2));
err(1,3) = err(1,1) + err(1,2);

% preddefiniranje arrayev za hitrejše delovanje
r_e = zeros(num_points, 1);
r_e_cor = zeros(size(f,2), num_points);
theta_e = zeros(num_points, 1);
r_c = zeros(num_points, 1);
r_c_cor = zeros(size(f,2), num_points);
theta_c = zeros(num_points, 1);

% pretvorba v polarni koordinatni sistem s središčem v optičnem središču slike
for i = 1 : num_points
    r_e(i) = sqrt(xe_c(i).^2 + ye_c(i).^2);
    theta_e(i) = atan2(ye_c(i), xe_c(i));
    
    r_c(i) = sqrt(xc_c(i).^2 + yc_c(i).^2);
    theta_c(i) = atan2(yc_c(i), xc_c(i));
end

% Izračun korigiranih radijev vseh točk in napake za vsak definiran f
for j = 1 : size(f,2)
    for i = 1 : num_points
        r_e_cor(j, i) = -f(j)/2 * (exp(-2*r_e(i)/f(j))-1)/(exp(-r_e(i)/f(j)));
        r_c_cor(j, i) = -f(j)/2 * (exp(-2*r_c(i)/f(j))-1)/(exp(-r_c(i)/f(j)));
    end
    
    %fitanje premice in izračun napake za robne točke
    [x_temp,y_temp]=pol2cart(theta_e,r_e_cor(j,:).');
    [edge_line, edge_dist] = fitline([x_temp.';y_temp.']);
    err(j+1,1) = sqrt(sum(edge_dist.^2));
    
    %fitanje premice in izračun napake za središčne točke
    [x_temp,y_temp]=pol2cart(theta_c,r_c_cor(j,:).');
    [edge_line, edge_dist] = fitline([x_temp.';y_temp.']); 
    err(j+1,2) = sqrt(sum(edge_dist.^2));
    
    %seštevek obeh napak, da gledamo najboljši popravek na celi sliki
    err(j+1,3) = err(j+1,1) + err(j+1,2);
end

% prikaz izračunane napake glede na f
f2 = figure;
plot(f, err(2:end,1), f, err(2:end,2), f, err(2:end,3));     % od drugega elementa naprej, saj je v prvem shranjena nekorigirana napaka
xlabel('f')
ylabel('error')
legend('error - edge','error - center', 'error - sum')

% prikaz robnih točk pri različnih f
f3 = figure;
polarscatter(theta_e,r_e);
hold on;
polarscatter(theta_e,r_e_cor(:,:));
legend(['original',string(f)]);
hold off;

% iskanje najmanjše napake in f pri te napaki
[minimum, min_index] = min(err(2:end,3));
fprintf('Najboljši f pri 3. nalogi je: %.0f \n', f(min_index));

% prikaz najbolje korigiranih točk na prvotni sliki
figure(f1);
hold on;
[x_temp,y_temp] = pol2cart(theta_e, r_e_cor(min_index, :).');
x_temp = x_temp + calib.cc(1);
y_temp = y_temp + calib.cc(2);
scatter(x_temp,y_temp,500,'yellow','x');

[x_temp,y_temp] = pol2cart(theta_c, r_c_cor(min_index, :).');
x_temp = x_temp + calib.cc(1);
y_temp = y_temp + calib.cc(2);
scatter(x_temp,y_temp,500,'blue','x');
legend('optical center', 'uncorrected edge points', 'uncorrected center points', '', '', 'corrected edge points (naloga 3)', 'corrected center points (naloga 3)');
hold off;


%% Naloga 4 - nelinearna optimizacija radialne distorzije
%najprej je treba pognat nalogo 3
[best4f, min4error] = fminsearch(@(f) min_finder(xe, ye, calib.cc(1), calib.cc(2), f), 500);
fprintf('Najboljši f pri 4. nalogi je: %f \n', best4f);


function error = min_finder(x_array, y_array, center_x, center_y,f)
    x_array = x_array - center_x;
    y_array = y_array - center_y;

    r = zeros(length(x_array), 1);
    r_cor = zeros(length(x_array), 1);
    theta = zeros(length(x_array), 1);
    
    for i = 1 : length(x_array)
        r(i) = sqrt(x_array(i)^2 + y_array(i)^2);
        theta(i) = atan2(y_array(i), x_array(i));
        r_cor(i) = -f/2 * (exp(-2*r(i)/f)-1)/(exp(-r(i)/f));
    end
    
    [x_temp,y_temp]=pol2cart(theta,r_cor);
    [edge_line, edge_dist] = fitline([x_temp.';y_temp.']); 
    error = sqrt(sum(edge_dist.^2));  
end