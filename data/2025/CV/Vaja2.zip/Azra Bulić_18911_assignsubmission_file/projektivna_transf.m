
img_name = 'Image_rect15.tif';
    % Ucitaj sliku, prebaci u sivu i double
    I = imread(img_name);
    if size(I,3) == 3
        I = rgb2gray(I);
    end
    I = im2double(I);

    % Izaberi 4 vanjska ugla sahovnice
    figure; imshow(I,[]); axis image; hold on;
    title('Izberite 4 zunanje vogale');
    [x,y] = ginput(4);
    k = [x y];

    % Definiraj idealnu geometriju ploce
    %12 kvadrata po sirini, 11 po visini, mreza uglova je (13 x 12)
    s  = 30;
    nx = 12;
    ny = 11;

    % 4 ugla idealne (ispravljene) ploce
    ip = [0 0; s*nx 0; s*nx s*ny; 0 s*ny];

    T = maketform('projective', k, ip);

    %Ispravljena slika
    I_rect = imtransform(I, T, 'XData',[0 s*nx],'YData',[0 s*ny]);
    figure; imshow(I_rect,[]); axis image;
    title('Projektivno ispravljena sahovnica');

    %Svi uglovi mreze u idealnom prostoru
    [U,V] = meshgrid(0:nx, 0:ny);
    ideal_pts = [U(:)*s, V(:)*s];

    %Inverzna transformacija: idealno -> original
    T_inv = maketform('projective', ip, k);
    [xo, yo] = tformfwd(T_inv, ideal_pts(:,1), ideal_pts(:,2));

    % Nacrtaj sve uglove na originalnoj slici
    figure; imshow(I,[]); axis image; hold on;
    plot(xo, yo, 'r+', 'MarkerSize',5, 'LineWidth',1);
    title('Originalna slika');
