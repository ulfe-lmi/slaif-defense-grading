img = imread('Image15.tif');

if size(img, 3) == 3
    img = rgb2gray(img);
end
img = im2double(img);

 
disp('Označite 6 tacaka na rubu slike.');
figure();
imshow(img);
[x1,y1] = ginput(6);
close();

disp('Označi 6 tacaka blizu centra.');
figure();
imshow(img);
[x2,y2] = ginput(6);
close();

%Centar slike
[height, width] = size(img);  % Za sivu sliku, visina i širina
x = width / 2; 
y = height / 2;

% Koordinate tačaka sa ivice
xy1 = zeros(2, 6);
for i = 1:6
    xy1(1,i) = x1(i) - x;  % Premesti X-koordinate
    xy1(2,i) = y1(i) - y;  % Premesti Y-koordinate
end

% Koordinate tačaka sa centra
xy2 = zeros(2, 6);
for i = 1:6
    xy2(1,i) = x2(i) - x;  % Premesti X-koordinate
    xy2(2,i) = y2(i) - y;  % Premesti Y-koordinate
end

    
[c1,d1] = fitline(xy1);
[c2,d2] = fitline(xy2);

D_1 = sum(d1 .^ 2);
D_2 = sum(d2 .^ 2);

%Polarne koordinate
r_rub = zeros(1,6);
r_centar = zeros(1,6);
ugao_rob = zeros(1,6);
ugao_centar = zeros(1,6);

[ugao_rob, r_rub] = cart2pol(xy1(1,:), xy1(2,:));
[ugao_centar, r_centar]= cart2pol(xy2(1,:), xy2(2,:));

f_vals = 400:20:800;
disp(length(f_vals));

rn_rob = zeros(1,6);
xy1_n = zeros(2,6);
r_n_centar = zeros(1,6);
xy2_n = zeros(2,6);

%i=1; %brojac
%Greske
D1 = zeros(1, length(f_vals));
D2 = zeros(1, length(f_vals));

for i = 1:length(f_vals)
    f=f_vals(i);
    rn_rob = (- f / 2) .* (exp(-2 * r_rub ./ f) - 1) ./ exp(-r_rub / f);
    r_n_centar = (- f / 2) .* (exp(-2 * r_centar ./ f) - 1) ./ exp(-r_centar / f);

    [xy1_n(1,:),xy1_n(2,:)] = pol2cart(ugao_rob,rn_rob);
    [xy2_n(1,:),xy2_n(2,:)] = pol2cart(ugao_centar,r_n_centar); 

    [c1n, d1n] = fitline(xy1_n);
    [c2n, d2n] = fitline(xy2_n);
    
    D_1n = sum(d1n .^2);
    D1(i) = D_1n;
    D_2n = sum(d2n .^2);
    D2(i) = D_2n;
end

Dsum = D1 + D2;
[minsweep, idxmin] = min(Dsum);
f_min = f_vals(idxmin);

figure; hold on; grid on;
f = 400:20:800;
plot(f, D1, 'g-', f, D2, 'b-', f, Dsum, 'r-', 'LineWidth', 2);

%Oznacen minimum
plot(f_min, minsweep, 'ko', 'MarkerSize', 8, 'MarkerFaceColor', 'y');
xline(f_min, '--k');
xlabel('Vrednosti parametra f');
ylabel('Suma kvadrata udaljenosti');
legend('Rub','Centar','Zbir','Min(Zbir)');

fprintf('Minimum pri f_min = %.1f\n', f_min);



% Optimizacija
f0=400;
cos_function = @(f)cost_fcn(f, ugao_rob,r_rub, ugao_centar, r_centar); %cos radijalne distorzije
[f_opt,e] = fminsearch(cos_function,f0); 
fprintf('Najboljše korigirana radijalna distrozija je pri f = %d',round(f_opt))

