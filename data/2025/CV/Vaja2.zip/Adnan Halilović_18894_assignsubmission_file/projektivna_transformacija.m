% 2. Projektivna transformacija
clear; close all; clc;

% Preberi sivinsko sliko (že brez radialne distorzije)
I = imread('Image_rect1.tif');  % tukaj vstavi svojo undistorted sliko
if size(I,3) == 3
    I = rgb2gray(I);
end

% Kliknem 4 vogale šahovnice (v smeri urinega kazalca)
figure; imshow(I); title('Klikni 4 vogale šahovnice (v smeri urinega kazalca)');
[x, y] = ginput(4);
hold on; plot(x, y, 'ro-', 'LineWidth', 2);
%Scatter za risanje pikic
% Določi idealne (nepopačene) točke
X = [0 640 640 0];
Y = [0 0 480 480];


% Izračun projektivne transformacije (fitgeotrans)
tform = fitgeotrans([x y], [X' Y'], 'projective');

% Korekcija slike (imwarp)
J = imwarp(I, tform, 'OutputView', imref2d(size(I)));

% Rezultati
figure;
subplot(1,2,1); imshow(I); title('Izvirna slika');
subplot(1,2,2); imshow(J); title('Korigirana slika');


% Velikost mreže
numCols = 12; % število stolpcev
numRows = 11; % število vrstic
stepX = 640 / numCols;
stepY = 480 / numRows;

[Xg, Yg] = meshgrid(0:stepX:640, 0:stepY:480);
gridPoints = [Xg(:), Yg(:)];

% Inverzna transformacija – iz idealnega koordinatnega sistema v originalno sliko
tform_inv = invert(tform);
[origX, origY] = transformPointsForward(tform_inv, gridPoints(:,1), gridPoints(:,2));

% Prikaži mrežo na originalni sliki
figure; imshow(I); title('Izvirna slika z izrisano mrežo (inverzna transformacija)');
hold on;
plot(origX, origY, 'g.', 'MarkerSize', 10);

% Po želji izrišeš povezave (linije med točkami)
for r = 1:size(Yg,1)
    idx = (r-1)*(numCols+1)+(1:(numCols+1));
    plot(origX(idx), origY(idx), 'y-');
end
for c = 1:size(Xg,2)
    idx = c:(numCols+1):numel(Xg);
    plot(origX(idx), origY(idx), 'y-');
end