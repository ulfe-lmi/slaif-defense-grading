% 2. Projektivna transformacija
clear; close all; clc;

% Preberi sivinsko sliko (že brez radialne distorzije)
I = imread('Image_rect1.tif');  % tukaj vstavi svojo undistorted sliko
if size(I,3) == 3
    I = rgb2gray(I);
end

% Kliknem 4 vogale šahovnice (v smeri urinega kazalca)
figure; imshow(I); title('Klikni 4 vogale šahovnice (v smeri urinega kazalca)');
[x, y] = ginput(4);
hold on; plot(x, y, 'ro-', 'LineWidth', 2);

% Določi idealne (nepopačene) točke
X = [0 640 640 0];
Y = [0 0 480 480];

% Izračun projektivne transformacije (fitgeotrans)
tform = fitgeotrans([x y], [X' Y'], 'projective');

% Korekcija slike (imwarp)
J = imwarp(I, tform, 'OutputView', imref2d(size(I)));

% Rezultati
figure;
subplot(1,2,1); imshow(I); title('Izvirna slika');
subplot(1,2,2); imshow(J); title('Korigirana slika');

% Velikost mreže
numCols = 14; % število stolpcev
numRows = 13; % število vrstic
xv = linspace(0, 640, numCols+1);
yv = linspace(0, 480, numRows+1);

% Generiraj mrežne točke
[Xlist, Ylist] = deal([]);
for i = 1:length(yv)
    for j = 1:length(xv)
        Xlist = [Xlist; xv(j)];
        Ylist = [Ylist; yv(i)];
    end
end
gridPoints = [Xlist, Ylist];

% Inverzna transformacija – iz idealnega koordinatnega sistema v originalno sliko
tform_inv = invert(tform);
[origX, origY] = transformPointsForward(tform_inv, gridPoints(:,1), gridPoints(:,2));

figure; imshow(I); title('Izvirna slika z mrežo (scatter prikaz)');
hold on;
scatter(origX, origY, 20, 'g', 'filled'); % 20 = velikost markerja

% Če želiš obarvati vogalne točke posebej:
cornerIdx = [1, numCols+1, (numRows)*(numCols+1)+1, (numRows+1)*(numCols+1)];
scatter(origX(cornerIdx), origY(cornerIdx), 60, 'r', 'filled'); % rdeče vogale
legend('Mrežne točke', 'Vogali');
