%Nelinearna optimizacija fminsearch
%Mihaela Temelkova & Jakob Suhadolc
inputImage = imread('Image15.tif');
imshow(inputImage)
imageCenterX = 319.5;
imageCenterY = 239.5;

disp('Oznaci tocke za robno navpicno linijo')
[selectedEdgeX, selectedEdgeY] = ginput;
edgePoints = [selectedEdgeX'; selectedEdgeY'];

disp('Oznaci tocke za centralno navpicno linijo:')
[selectedCenterX, selectedCenterY] = ginput;
centerPoints = [selectedCenterX'; selectedCenterY'];
%%
%preveris ali je f=540

selectedEdgeX = [43 44 40 43 41 39 41 45 44 49];
selectedEdgeY = [69 106 146 181  221  259  290  392 423  451];
selectedCenterY=[84 124 157 195 231 332 394 428 454];
selectedCenterX=[275 272 269 265 262 256 251 250 250];
edgePoints   = [selectedEdgeX; selectedEdgeY];
centerPoints = [selectedCenterX; selectedCenterY];

objective = @(f) total_error_for_f(f, edgePoints, centerPoints, imageCenterX, imageCenterY);

initialGuess = 600;
bestFocalLength = fminsearch(objective, initialGuess);

fprintf('Najboljsi: %.3f\n', bestFocalLength);

f = bestFocalLength;
[xGrid, yGrid] = meshgrid(1:size(inputImage,2), 1:size(inputImage,1));
radialDistanceOriginal = sqrt((xGrid - imageCenterX).^2 + (yGrid - imageCenterY).^2);
radialDistanceMapped = f .* log((radialDistanceOriginal ./ f) + sqrt(1 + (radialDistanceOriginal ./ f).^2));
xGridCorrected = imageCenterX + (xGrid - imageCenterX) .* (radialDistanceMapped ./ radialDistanceOriginal);
yGridCorrected = imageCenterY + (yGrid - imageCenterY) .* (radialDistanceMapped ./ radialDistanceOriginal);

correctedImage = interp2(double(inputImage), xGridCorrected, yGridCorrected, 'linear', 0);
imshow(uint8(correctedImage))
title(sprintf('Popravljena slika (f = %.0f)', f))



function totalError = total_error_for_f(f, edgePoints, centerPoints, imageCenterX, imageCenterY)
    edgeError = compute_line_error(edgePoints, f, imageCenterX, imageCenterY);
    centerError = compute_line_error(centerPoints, f, imageCenterX, imageCenterY);
    totalError = edgeError + 1.0 * centerError;
end


function lineError = compute_line_error(points, f, imageCenterX, imageCenterY)
    x = points(1, :);
    y = points(2, :);
    radialDistanceOriginal = sqrt((x - imageCenterX).^2 + (y - imageCenterY).^2);
    radialDistanceCorrected = -(f/2) .* ((exp(-2*radialDistanceOriginal/f)) - 1) ./ exp(-radialDistanceOriginal/f);
    correctedX = imageCenterX + (x - imageCenterX) .* (radialDistanceCorrected ./ radialDistanceOriginal);
    correctedY = imageCenterY + (y - imageCenterY) .* (radialDistanceCorrected ./ radialDistanceOriginal);
    [~, distancesToLine] = fitline([correctedX; correctedY]);
    lineError = sum(distancesToLine.^2);
end
