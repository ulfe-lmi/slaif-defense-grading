% Mihaela Temelkova & Jakob Suhadolc
% Projektivna transformacija sahovnice
clear; close all; clc;
I = imread('Image1.tif');  

figure; imshow(I); title('Klikni: TL, TR, BR, BL'); 
[x,y] = ginput(4);                    
tocke_slika = [x y];   

st_kvad_x = 12;  % kvadratki po širini
st_kvad_y = 11;  % kvadratki po višini
dx = 30;  % [px]

W = st_kvad_x*dx;
H = st_kvad_y*dx;

% Idealne točke 
tocke_ideal = [0 0; W 0; W H; 0 H];

% Izračun projektivne transformacije
tform = maketform('projective', tocke_slika, tocke_ideal);

% Izvedemo transformacijo slike (poravnamo sahovnico)
[korigirana, xdata, ydata] = imtransform(I, tform, 'XData', [0 W], 'YData', [0 H]);
figure;
imshow(korigirana, []);
title('Korigirana (poravnana) sahovnica');

% Ustvarimo mrežo vseh oglišč (v idealni poravnani ravnini)
nx = st_kvad_x + 1;  % število stolpcev oglišč
ny = st_kvad_y + 1;  % število vrstic oglišč

[xg, yg] = meshgrid(linspace(0, W, nx), linspace(0, H, ny));

% Inverzna transformacija – iz idealnih koordinat v originalno sliko
tform_inv = maketform('projective', tocke_ideal, tocke_slika);
[mx, my] = tformfwd(tform_inv, xg, yg);

% 9. Narišemo mrežo oglišč na originalni sliki
figure;
imshow(I, []);
hold on;
title('Oglisca sahovnice');
axis image;

for j = 1:ny
    for i = 1:nx
        % Rdeče pike za oglišča
        plot(mx(j,i), my(j,i), 'x', 'MarkerSize', 4, 'LineWidth', 1);
    end
end

hold off;
