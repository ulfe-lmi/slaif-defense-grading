%Radialna distorzija 
%Jakob Suhadolc & Mihaela Temelkova
inputImage = imread('Image15.tif');
imshow(inputImage)

imageCenterX = 319.5;
imageCenterY = 239.5;

%selectamo dve navpicni liniji in potrdimo s ENTER
disp('Oznaci tocke za robno navpicno linijo')
[selectedEdgeX, selectedEdgeY] = ginput;
edgePoints = [selectedEdgeX'; selectedEdgeY'];

disp('Oznaci tocke za centralno navpicno linijo:')
[selectedCenterX, selectedCenterY] = ginput;
centerPoints = [selectedCenterX'; selectedCenterY'];

selectedPoints = [selectedEdgeX'; selectedEdgeY'];
size(selectedPoints)
%%
%Preveris ce se ujema f = 540
selectedEdgeX = [43 44 40 43 41 39 41 45 44 49]';
selectedEdgeY = [69 106 146 181  221  259  290  392 423  451]';

selectedCenterY=[84 124 157 195 231 332 394 428 454]';
selectedCenterX=[275 272 269 265 262 256 251 250 250]';

edgePoints   = [selectedEdgeX; selectedEdgeY];
centerPoints = [selectedCenterX; selectedCenterY];

focalLengthCandidates = 400:20:800;
totalErrorPerCandidate = zeros(size(focalLengthCandidates));


for idx = 1:length(focalLengthCandidates)
    currentFocalLength = focalLengthCandidates(idx);

    edgeRadialDistanceOriginal = sqrt((selectedEdgeX - imageCenterX).^2 + (selectedEdgeY - imageCenterY).^2);
    edgeRadialDistanceCorrected = -(currentFocalLength/2) .* ((exp(-2*edgeRadialDistanceOriginal/currentFocalLength)) - 1) ./ exp(-edgeRadialDistanceOriginal/currentFocalLength);
    correctedEdgeX = imageCenterX + (selectedEdgeX - imageCenterX) .* (edgeRadialDistanceCorrected ./ edgeRadialDistanceOriginal);
    correctedEdgeY = imageCenterY + (selectedEdgeY - imageCenterY) .* (edgeRadialDistanceCorrected ./ edgeRadialDistanceOriginal);
    [~, edgePointLineDistances] = fitline([correctedEdgeX'; correctedEdgeY']);
    edgeLineError = sum(edgePointLineDistances.^2);

    centerRadialDistanceOriginal = sqrt((selectedCenterX - imageCenterX).^2 + (selectedCenterY - imageCenterY).^2);
    centerRadialDistanceCorrected = -(currentFocalLength/2) .* ((exp(-2*centerRadialDistanceOriginal/currentFocalLength)) - 1) ./ exp(-centerRadialDistanceOriginal/currentFocalLength);
    correctedCenterX = imageCenterX + (selectedCenterX - imageCenterX) .* (centerRadialDistanceCorrected ./ centerRadialDistanceOriginal);
    correctedCenterY = imageCenterY + (selectedCenterY - imageCenterY) .* (centerRadialDistanceCorrected ./ centerRadialDistanceOriginal);
    [~, centerPointLineDistances] = fitline([correctedCenterX'; correctedCenterY']);
    centerLineError = sum(centerPointLineDistances.^2);

    totalErrorPerCandidate(idx) = edgeLineError + 1.0 * centerLineError;
end

figure('Name','SSD vs f'); 
plot(focalLengthCandidates, totalErrorPerCandidate, '-o');
grid on; xlabel('f'); ylabel('Vsota kvadratov razdalje'); title('Iskanje najboljšega f');


[~, bestIndex] = min(totalErrorPerCandidate);
bestFocalLength = focalLengthCandidates(bestIndex)

f = bestFocalLength;
[xGrid, yGrid] = meshgrid(1:size(inputImage,2), 1:size(inputImage,1));
radialDistanceOriginal = sqrt((xGrid - imageCenterX).^2 + (yGrid - imageCenterY).^2);

radialDistanceMapped = f .* log((radialDistanceOriginal ./ f) + sqrt(1 + (radialDistanceOriginal ./ f).^2));
xGridCorrected = imageCenterX + (xGrid - imageCenterX) .* (radialDistanceMapped ./ radialDistanceOriginal);
yGridCorrected = imageCenterY + (yGrid - imageCenterY) .* (radialDistanceMapped ./ radialDistanceOriginal);

figure('Name','Popravljena slika');
correctedImage = interp2(double(inputImage), xGridCorrected, yGridCorrected, 'linear', 0);
imshow(uint8(correctedImage))
title(sprintf('Popravljena slika (f = %.0f)', f))
