
%Radialna distorzija 
%Jakob Suhadolc & Mihaela Temelkova

inputImage = imread('Image15.tif');
imshow(inputImage)

imageCenterX = 319.5;
imageCenterY = 239.5;

% izberi dve navpični liniji (Enter za konec)
disp('Označi točke za robno navpično linijo in pritisni ENTER')
[selectedEdgeX, selectedEdgeY] = ginput;
edgePoints = [selectedEdgeX; selectedEdgeY];
% Xedge=[43 44 40 43 41 39 41 45 44 49]
% Yedge=[69 106 146 181  221  259  290  392 423  451]

disp('Označi točke za centralno navpično linijo in pritisni ENTER')
[selectedCenterX, selectedCenterY] = ginput;
centerPoints = [selectedCenterX; selectedCenterY];
%Xcen=[275 272 269 265 262 256 251 250 250]
%Ycen=[84 124 157 195 231 332 394 428 454]

selectedPoints = [selectedEdgeX; selectedEdgeY];
size(selectedPoints)

%%
%Preveris ce se ujema f = 540
% selectedEdgeX = [43 44 40 43 41 39 41 45 44 49]';
% selectedEdgeY = [69 106 146 181  221  259  290  392 423  451]';
% 
% selectedCenterY=[84 124 157 195 231 332 394 428 454]';
% selectedCenterX=[275 272 269 265 262 256 251 250 250]';
% 
% edgePoints   = [selectedEdgeX; selectedEdgeY];
% centerPoints = [selectedCenterX; selectedCenterY];
% 
focalLengthCandidates = 400:20:800;
totalErrorPerCandidate = zeros(size(focalLengthCandidates));

for idx = 1:length(focalLengthCandidates)
    f = focalLengthCandidates(idx);

    %  ROBNA linija
    % radialna razdalja r' (od centra) za vsako robno točko
    rE = sqrt((selectedEdgeX - imageCenterX).^2 + (selectedEdgeY - imageCenterY).^2);
    rE = max(rE, eps); % varovalo
    rE_corr = -(f/2) .* (exp(-2*rE/f) - 1) ./ exp(-rE/f);  % podana enačba

    scaleE = rE_corr ./ rE;
    xE = imageCenterX + (selectedEdgeX - imageCenterX).*scaleE;
    yE = imageCenterY + (selectedEdgeY - imageCenterY).*scaleE;
    [~, dE] = fitline([xE'; yE']);
    errE = sum(dE.^2);

 
    % CENTRALNA linija
    rC = sqrt((selectedCenterX - imageCenterX).^2 + (selectedCenterY - imageCenterY).^2);
    rC = max(rC, eps);
    rC_corr = -(f/2) .* (exp(-2*rC/f) - 1) ./ exp(-rC/f);

    scaleC = rC_corr ./ rC;
    xC = imageCenterX + (selectedCenterX - imageCenterX).*scaleC;
    yC = imageCenterY + (selectedCenterY - imageCenterY).*scaleC;

    [~, dC] = fitline([xC'; yC']);
    errC = sum(dC.^2);

    % skupna SSD napaka (rob + center)
    totalErrorPerCandidate(idx) = errE + errC;
end

% graf SSD
figure('Name','SSD vs f'); 
plot(focalLengthCandidates, totalErrorPerCandidate, '-o'); grid on;
xlabel('f'); ylabel('Vsota kvadratov razdalj (SSD)');
title('Iskanje najboljšega f');

[~, bestIndex] = min(totalErrorPerCandidate);
bestFocalLength = focalLengthCandidates(bestIndex)
hold on;

plot(bestFocalLength, totalErrorPerCandidate(bestIndex), 'rx', 'MarkerSize', 12, 'LineWidth', 2);
xline(bestFocalLength, '--r', sprintf('  best f = %d', bestFocalLength), 'LabelVerticalAlignment','bottom');
hold off;

% popravek slike
f = bestFocalLength;
[xGrid, yGrid] = meshgrid(1:size(inputImage,2), 1:size(inputImage,1));
r_new = sqrt((xGrid - imageCenterX).^2 + (yGrid - imageCenterY).^2);
r_new = max(r_new, eps); % varovalo

% inverzni model: r' = f * log( r/f + sqrt(1 + (r/f)^2) )
r_old = f .* log((r_new./f) + sqrt(1 + (r_new./f).^2));
ratio = r_old ./ r_new;
xGridCorrected = imageCenterX + (xGrid - imageCenterX).*ratio;
yGridCorrected = imageCenterY + (yGrid - imageCenterY).*ratio;

figure('Name','Popravljena slika');
correctedImage = interp2(double(inputImage), xGridCorrected, yGridCorrected, 'linear', 0);
imshow(uint8(correctedImage));
title(sprintf('Popravljena slika (f = %d)', f));
