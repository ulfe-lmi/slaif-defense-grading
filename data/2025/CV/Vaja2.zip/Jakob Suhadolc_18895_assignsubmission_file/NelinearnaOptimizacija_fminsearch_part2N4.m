%Nelinearna optimizacija - fminsearch
%Mihaela Temelkova & Jakob Suhadolc

close all; clear; clc;

inputImage = imread('Image15.tif');
imshow(inputImage)
  
imageCenterX = 319.5;
imageCenterY = 239.5;

disp('Označi točke za robno navpično linijo in pritisni ENTER')
[selectedEdgeX, selectedEdgeY] = ginput;
edgePoints = [selectedEdgeX'; selectedEdgeY'];

disp('Označi točke za centralno navpično linijo in pritisni ENTER')
[selectedCenterX, selectedCenterY] = ginput;
centerPoints = [selectedCenterX'; selectedCenterY'];

selectedPoints = [selectedEdgeX'; selectedEdgeY'];
size(selectedPoints)
%%
% varovalo, da ne optimiziramo s praznimi podatki
if isempty(edgePoints) || isempty(centerPoints)
    error('Klikni nekaj tock na obeh linijah in pritisni Enter.');
end

%Preveris ce se ujema f = 540
selectedEdgeX = [43 44 40 43 41 39 41 45 44 49];
selectedEdgeY = [69 106 146 181  221  259  290  392 423  451];

selectedCenterY=[84 124 157 195 231 332 394 428 454];
selectedCenterX=[275 272 269 265 262 256 251 250 250];

edgePoints   = [selectedEdgeX; selectedEdgeY];
centerPoints = [selectedCenterX; selectedCenterY];

% minimizacija napake preko fminsearch 
objective = @(f) ...
    line_error(edgePoints,f,imageCenterX,imageCenterY) + ...
    line_error(centerPoints,f,imageCenterX,imageCenterY);

initialGuess = 600;
bestF = fminsearch(objective, initialGuess);

%  total error pri najboljšem f (in razbij po linijah) 
errEdge   = line_error(edgePoints,   bestF, imageCenterX, imageCenterY);
errCenter = line_error(centerPoints, bestF, imageCenterX, imageCenterY);
totalErr  = errEdge + errCenter;

fprintf('Najboljsi f = %.3f | total error = %.6f (edge=%.6f, center=%.6f)\n', ...
        bestF, totalErr, errEdge, errCenter);

%  popravek slike 
f = bestF;
[xGrid, yGrid] = meshgrid(1:size(inputImage,2), 1:size(inputImage,1));
r = sqrt((xGrid - imageCenterX).^2 + (yGrid - imageCenterY).^2);
r = max(r, eps);
r_mapped = f .* log((r./f) + sqrt(1 + (r./f).^2));
ratio = r_mapped ./ r;
xCorr = imageCenterX + (xGrid - imageCenterX).*ratio;
yCorr = imageCenterY + (yGrid - imageCenterY).*ratio;

correctedImage = interp2(double(inputImage), xCorr, yCorr, 'linear', 0);
figure; imshow(uint8(correctedImage));
title(sprintf('Popravljena slika (f = %.0f)', f));

% funcija ki racuna koliko je linija iskrivljena
function err = line_error(points, f, cx, cy)
    % prisili f v smiseln interval (da fminsearch ne pobegne)
    f = max(400, min(800, f));

    x = points(1,:);  y = points(2,:);
    r = sqrt((x - cx).^2 + (y - cy).^2);
    r = max(r, eps);  % varovalo proti deljenju z 0

    % inverse model: r = f^{-1}(r')
    r_corr = -(f/2) .* (exp(-2*r/f) - 1) ./ exp(-r/f);

    % popravljene koordinate
    scale = r_corr ./ r;
    x_corr = cx + (x - cx) .* scale;
    y_corr = cy + (y - cy) .* scale;

    % razdalje tock do najboljse premice
    [~, d] = fitline([x_corr; y_corr]);

    err = sum(d.^2);
end

