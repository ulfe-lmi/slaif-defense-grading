%% RV2_VSE_NALOGE
close all; clear; clc;

%% ---- nastavitve slik ----
projImgName = 'Image_rect6.tif';   % 2. naloga -> prilagodi po potrebi
radImgName  = 'Image15.tif';   % 3. in 4. naloga

%% ---- središče distorzije iz Calib_Results.mat ----
R = load('Calib_Results.mat');

cx = R.cc(1); cy = R.cc(2);

%% ===================== 2. NALOGA: PROJEKTIVNA =====================
Ip = imread(projImgName);

figure; imshow(Ip,[]); axis image;
title({'2. naloga: klikni 4 vogale šahovnice v zaporedju:', ...
       '1: levo zgoraj, 2: desno zgoraj, 3: desno spodaj, 4: levo spodaj'});
[xv, yv] = ginput(4);
moving = [xv yv];

% prilagodi glede na svojo šahovnico:
numSquaresX = 12;
numSquaresY = 11;
squareSize  = 30;
W = numSquaresX * squareSize;
H = numSquaresY * squareSize;

fixed = [0 0; W 0; W H; 0 H];

T = maketform('projective', moving, fixed);
[J, ~, ~] = imtransform(Ip, T, 'XData',[0 W], 'YData',[0 H]);

figure; imshow(J,[]); axis image;
title('2. naloga: korigirana (projektivna) slika');

% oglišča v idealni mreži + preslikava nazaj na original
[Xg, Yg] = meshgrid(0:squareSize:W, 0:squareSize:H);
ideal_pts = [Xg(:) Yg(:)];
invT = maketform('projective', fixed, moving);
[xg, yg] = tformfwd(invT, ideal_pts(:,1), ideal_pts(:,2));

figure; imshow(Ip,[]); axis image; hold on;
plot(xg, yg, 'r.', 'MarkerSize', 6);
title('2. naloga: oglišča šahovnice na originalni sliki');


%% ========== 3. & 4. NALOGA: RADIALNA DISTORZIJA (Image15) ==========

Ir = imread(radImgName);

figure; imshow(Ir,[]); axis image;
title({'3./4. naloga:', ...
       'Najprej klikni ROBNO vertikalno vrsto oglišč (Enter za konec),', ...
       'nato SREDINSKO vertikalno vrsto (Enter za konec).'});

disp('3./4. naloga: robna vrsta, Enter za konec.');
[x1, y1] = ginput;
disp('3./4. naloga: sredinska vrsta, Enter za konec.');
[x2, y2] = ginput;
close;

%% ---- 3. naloga: diskretno iskanje f v [400:20:800] ----

f_vals = 400:20:800;
E_vals = zeros(size(f_vals));

for k = 1:length(f_vals)
    E_vals(k) = radial_error(f_vals(k), x1,y1,x2,y2, cx,cy);
end

[Emin, idxMin] = min(E_vals);
f_best_grid = f_vals(idxMin);

fprintf('3. naloga: najboljši f (diskretno) = %.4f, napaka = %.4f\n', ...
        f_best_grid, Emin);

figure;
plot(f_vals, E_vals, '-o'); grid on;
xlabel('f'); ylabel('Vsota kvadratov razdalj');
title('3. naloga: napaka glede na f (diskretno)');
    


%% ---- 4. naloga: nelinearno iskanje f z fminsearch ----

f0 = f_best_grid;                 % začnemo pri diskretnem minimumu
opts = optimset('Display','off'); % minimalno, brez spama v konzoli

[f_best_cont, E_best_cont] = fminsearch( ...
    @(f) radial_error(f, x1,y1,x2,y2, cx,cy), f0, opts);

fprintf('4. naloga: optimalni f (fminsearch) = %.6f, napaka = %.6f\n', ...
        f_best_cont, E_best_cont);

% (neobvezno, a pregledno) lokalni prikaz okoli optimuma
f_loc = linspace(max(100, f_best_cont-200), min(1000, f_best_cont+200), 30);
E_loc = arrayfun(@(f) radial_error(f, x1,y1,x2,y2, cx,cy), f_loc);

figure;
plot(f_loc, E_loc, '-o'); grid on;
xlabel('f'); ylabel('Vsota kvadratov razdalj');
title('4. naloga: napaka okoli optimalnega f');


%% ===== LOKALNE FUNKCIJE (OSTANEJO V ISTEM .m, TO JE ŠE VEDNO SKRIPTA) =====

function E = radial_error(f, x1,y1,x2,y2, cx,cy)
    % Napaka za dano f: vsota kvadratov razdalj obeh stolpcev do svojih premic
    if f <= 0
        E = 1e12;
        return;
    end

    [xu1, yu1] = undistort_points(x1, y1, cx, cy, f);
    [xu2, yu2] = undistort_points(x2, y2, cx, cy, f);

    [~, d1] = fitline([xu1.'; yu1.']);   % 2xN
    [~, d2] = fitline([xu2.'; yu2.']);

    E = sum(d1.^2) + sum(d2.^2);
end


function [xu, yu] = undistort_points(x, y, cx, cy, f)
    % Inverz radialne distorzije:
    % r' -> r_l = f * sinh(r'/f)

    dx = x - cx;
    dy = y - cy;

    rp = sqrt(dx.^2 + dy.^2);       % popačen radij
    rl = f .* sinh(rp ./ f);        % nepopačen radij

    scale = ones(size(rp));
    mask = (rp > 0);
    scale(mask) = rl(mask) ./ rp(mask);

    xu = cx + dx .* scale;
    yu = cy + dy .* scale;
end
