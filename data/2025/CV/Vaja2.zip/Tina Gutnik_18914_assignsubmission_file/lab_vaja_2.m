addpath('C:\Users\tgutn\TOOLBOX_calib');
calib_gui;

%% Projektivna transformacija

I = imread('Image_rect3.tif');
image(I); colormap gray; hold on;

[x,y] = ginput(4); %označimo 4 točke (levo zgoraj!, desno zgoraj, desno spodaj, levo spodaj)
tocke = [x(:) y(:)]; %shranimo koordinate točk v matriko 4x2, kjer je vsaka vrstica ena točka [x y]
plot(tocke([1:4 1],1), tocke([1:4 1],2)); %narišemo te točke(1 znotraj [] je, da je zaprt pravokotnik, na koncu spet prva točka)

W = 12*30; %širina šahovnice je 12 kvadratkov po 30mm
H = 11*30; %višina šahovnice
piksli = 3; %ločljivost naj bo 3 piksli/mm
pravokotnik = [0 0; W 0; W H; 0 H]; %to je ciljni pravokotnik, v katerega želimo izvesti projektivno transformacijo

G = fitgeotrans(tocke, pravokotnik, 'projective');   %ocenimo projektivno preslikavo iz tocke v pravokotnik
tform = maketform('projective', G.T); %ustvari tform, ki ga razume imtransform  %T je 3x3 homogena matrika projektivne trans.
%Irect = imtransform(I, tform); %podamo še velikosti x in y, da dobimo sliko zgolj šahovnice, ne pa tudi ozadja
Irect = imtransform(I, tform, 'XData', [0 W], 'YData', [0 H]); %preslika sliko v ciljni pravokotnik
figure; image(Irect); colormap gray; axis image off; hold on;
[X,Y] = meshgrid(0:30:W, 0:30:H); 
plot(X(:), Y(:), 'mx');



Tinv = inv(G.T); % inverzna 3x3 matrika
inv_tform = maketform('projective', Tinv);
[x0, y0] = tformfwd(inv_tform, X(:), Y(:));

figure; image(I); colormap gray; axis image off; hold on;
plot(x0(:), y0(:), 'mx');   


%% Radialna distorzija 
figure;
R = imread('Image15.tif');
image(R); colormap gray; hold on;

W = 12*30; 
H = 11*30;
piksli = 3;

% fitline pričakuje 2*N matriko, prva vrstica x, druga y
% vrne koeficiente premice ax+by+c=0 z normo sqrt(a^2+b^2)=1, torej C = [a;b;c] 
% vrne tudi d - pravokotna razdalja vsake točke do premice 

% stranska premica
[x1,y1] = ginput(12); %poklikati je potrebno vsa presečišča stranske premice 
plot(x1,y1,'rx');
[C1,d1] = fitline([x1'; y1']); 
a1=C1(1); b1=C1(2); c1=C1(3);

if abs(b1) > eps %primer, ko premica ni vertikalna 
    x = [0 W];
    y = -(a1*x + c1)/b1;        
    plot(x, y, 'r');
else
    x0 = -c1/a1;  %vertikalna premica x=x0, nagib je neskončen, b=0 torej ax+c=0
    plot(x0, [0 H], 'r');
end


% sredinska premica
[x2,y2] = ginput(12); %poklikati je potrebno vsa presečišča sredinske premice 
plot(x2,y2,'gx');
[C2,d2] = fitline([x2'; y2']);
a2=C2(1); b2=C2(2); c2=C2(3);

if abs(b2) > eps %primer, ko premica ni vertikalna 
    x = [0 W];
    y = -(a2*x + c2)/b2;        
    plot(x, y, 'g');
else
    x0 = -c2/a2;  % vertikalna premica x=x0, nagib je neskončen, b=0 torej ax+c=0
    plot(x0, [0 H], 'g');
end


% minimizacija vsote kvadratov razdalj
load Calib_Results.mat;
cx = cc(1);            %središče v pikslih cx= 303, cy=243
cy = cc(2);              

% popačeni radiji
r0_rob    = hypot(x1 - cx, y1 - cy);   %hypot - hipotenuza 
r0_center = hypot(x2 - cx, y2 - cy);

% nepopačeni radiji
f = 400:20:800;
vsota_kvadratov = zeros(size(f)); 

for i = 1:size(f,2)  %f je vrstični vektor (21)
    ft = f(i);

    rl_rob = -(ft/2) .* (exp(-2 .* r0_rob ./ ft) - 1) ./ exp(-r0_rob ./ ft);  % ., ker množimo in delimo po elementih (r0_rob je lahko element in vektor)
    rl_center = -(ft/2) .* (exp(-2 .* r0_center ./ ft) - 1) ./ exp(-r0_center ./ ft);

    s1 = rl_rob ./ r0_rob; %radialni faktor
    s2 = rl_center ./ r0_center;

    x1u = cx + (x1 - cx).*s1;   y1u = cy + (y1 - cy).*s1; %x in y koor. undistorted robnih točk
    x2u = cx + (x2 - cx).*s2;   y2u = cy + (y2 - cy).*s2; %x in y koor. undistorted centerskih točk
    
    [~,d1] = fitline([x1u'; y1u']); %fitline undistorted točk
    [~,d2] = fitline([x2u'; y2u']);

    vsota_kvadratov(i) = sum(d1.^2) + sum(d2.^2);
    %vsota_kvadratov(i)= sqrt((sum(d1.^2) + sum(d2.^2)) / (numel(d1)+numel(d2)) ); če bi želeli rms 
end

figure; plot(f, vsota_kvadratov);
xlabel('f'); ylabel('vsota kvadratov razdalj');

% Nelinearna optimizacija vrednosti parametra distorzije
f0 = 500;
obj = @(ft) optimizacija(ft, x1, y1, x2, y2, r0_rob, r0_center, cx, cy); %anonimna fun., da dostopamo do vseh elementov
f_opt = fminsearch(obj, f0)