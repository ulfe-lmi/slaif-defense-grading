function  vsota_kvadratov = optimizacija (ft, x1, y1, x2, y2, r0_rob, r0_center, cx, cy) 
    rl_rob = -(ft/2) .* (exp(-2 .* r0_rob ./ ft) - 1) ./ exp(-r0_rob ./ ft);  % ., ker množimo in delimo po elementih (r0_rob je lahko element in vektor)
    rl_center = -(ft/2) .* (exp(-2 .* r0_center ./ ft) - 1) ./ exp(-r0_center ./ ft);

    s1 = rl_rob ./ r0_rob; %radialni faktor
    s2 = rl_center ./ r0_center;

    x1u = cx + (x1 - cx).*s1;   y1u = cy + (y1 - cy).*s1; %x in y koor. undistorted robnih točk
    x2u = cx + (x2 - cx).*s2;   y2u = cy + (y2 - cy).*s2; %x in y koor. undistorted centerskih točk
    
    [~,d1] = fitline([x1u'; y1u']); %fitline undistorted točk
    [~,d2] = fitline([x2u'; y2u']);

    vsota_kvadratov = sum(d1.^2) + sum(d2.^2);
end
