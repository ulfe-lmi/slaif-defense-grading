
%% 2 naloga
figure(1);
shahovnica = imread('Image_rect13.tif');
imshow(shahovnica);

[x0,y0] = ginput(4);
points = [x0, y0];
squares_alongX = 12;
squares_alongY = 11;
dxy = 30;

dolzinoX = squares_alongX*dxy;
dolzinoY = squares_alongY*dxy;

OutputP = [0 0;
    dolzinoX 0; 
    dolzinoX dolzinoY; 
    0 dolzinoY];

T = maketform('projective', points, OutputP);
I_corrected = imtransform (shahovnica,T,'XData', [0 dolzinoX],'YData', [0 dolzinoY]);

[xg, yg] = meshgrid(0:dxy:dolzinoX, 0:dxy:dolzinoY); 

figure;
imshow(I_corrected);
hold on;
plot(xg, yg, 'rx', 'MarkerSize', 5);

T_inv = maketform('projective', OutputP, points); 

[x_back, y_back] = tformfwd(T_inv, xg(:), yg(:));

figure; 
imshow(shahovnica);
hold on;
plot(x_back, y_back, 'rx', 'MarkerSize', 6, 'LineWidth',1);
title('Vsa oglišča šahovnice preslikana nazaj na original (inverzna transformacija)');

%% 3 naloga

figure
ImDistortion = imread('Image15.tif');
imshow(ImDistortion);
title('oznaci 6 tocke ki so kotov kvadratkov na eno vertikalo, da bi se izrisali 3 premici')
hold on

cx = 305.69055;
cy = 243.09499;

%X = [43, 41, 40, 41, 44, 47;
 %    311, 304, 298, 292, 284, 279];
%Y = [69, 146, 221, 294, 394, 454;
 %    88, 162, 233, 301, 396, 454];
for i=1:2
    [x2,y2] = ginput(6);
    %x2 = X(i, :);
    %y2 = Y(i, :);
    XY = [x2'; y2']; %jo transporiramo(') ce pisemo tocke z ginuput, da dobimo obliko 2xN, avtomatski pa prevzame Nx2 oblika
    C = fitline(XY);

    yPoints = linspace(min(y2), max(y2), 500);
    xPoints = (-(yPoints*C(2)) - C(3))/ C(1);

    if i == 1
        plot(xPoints, yPoints, 'g')
        alpha1 = atan2(XY(2,:) - cy, XY(1,:) - cx);
        rad1_popacen = sqrt((cx - XY(1, :)).^2 + (cy - XY(2,:)).^2);
    elseif i ==2
        plot(xPoints, yPoints, 'b')
        alpha2 = atan2(XY(2,:) - cy, XY(1,:) - cx);
        rad2_popacen = sqrt((cx - XY(1, :)).^2 + (cy - XY(2,:)).^2);
    end
end

f_values = 400:20:800;
SumSq1 = zeros(size(f_values));
SumSq2 = zeros(size(f_values));
SumAll = zeros(size(f_values));


for k = 1:numel(f_values)
    f = f_values(k);

    r_popr1 = (-f/2) .* ((exp(-(2*rad1_popacen)./f) - 1) ./ (exp(-(rad1_popacen)./f))); %pika zarad mnozenje posebnega elementa iz vektor z vec elementov
    r_popr2 = (-f/2) .* ((exp(-(2*rad2_popacen)./f) - 1) ./ (exp(-(rad2_popacen)./f)));
    
    X1_popr = cx + r_popr1 .* cos(alpha1);
    Y1_popr = cy + r_popr1 .* sin(alpha1);
    XY1 = [X1_popr;Y1_popr]; %tukaj ne transporniramo, ker r_popr1,2,3 so ze vrsticni vektorji 1xN
    [~, dist1] = fitline(XY1);
    SumSq1(k) = sum(dist1.^2);
    
    X2_popr = cx + r_popr2 .* cos(alpha2);
    Y2_popr = cy + r_popr2 .* sin(alpha2);
    XY2 = [X2_popr;Y2_popr]; 
    [~, dist2] = fitline(XY2);
    SumSq2(k) = sum(dist2.^2);
    
    SumAll(k) = SumSq1(k) + SumSq2(k);

end

figure
title("Napaka distorzije")
plot(f_values,SumSq1,'b')
hold on
plot(f_values,SumSq2,'g');
hold on
plot(f_values,SumAll,'y')
legend('Napaka prve črte','Napaka druge črte', 'Skupna napaka')
xlabel("f")
ylabel("Napaka")

% 4 Naloga

r_popacen = {rad1_popacen, rad2_popacen};
alphas = {alpha1, alpha2};
f0 = 600;

[f_optimalen, minNapaka] = fminsearch(@(f) distorzijapopr(f, cx, cy, r_popacen, alphas), f0);
 %@(f) pomeni da vhodni parameter v funkciji je f, ker fminsearch prevzame
 %funkcijo samo z enim parametrom tukaj povedamo s tem da spreminjamo samo f
 %ostale par. v fji ostanejo nespremenjeni, zacne pa iskati pri f0
 fprintf('Optimalni parameter f = %.2f\n', f_optimalen);
 fprintf('Minimalna skupna napaka = %.6f\n', minNapaka);
 
 function skupnaNapaka = distorzijapopr(f, cx, cy, r_popacen, alphas)
        
         skupnaNapaka = 0;
         for i = 1:numel(r_popacen)

             r_popravljen = (-f/2) .* ((exp(-(2*r_popacen{i})./f) - 1) ./ (exp(-(r_popacen{i})./f)));
           
             X_popravljen = cx + r_popravljen .* cos(alphas{i});
             Y_popravljen = cy + r_popravljen .* sin(alphas{i});

             XYo = [X_popravljen; Y_popravljen];
             [~, dist] = fitline(XYo);

             skupnaNapaka = skupnaNapaka + sum(dist.^2);
         end
end

























