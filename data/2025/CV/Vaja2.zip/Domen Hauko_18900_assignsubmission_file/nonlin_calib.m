function nonlin_calib = nonlin_calib(f, corners_edge, corners_middle, principal_point)
% Izračuna vsoto kvadratov napak za dano vrednost f.
% Uporablja enačbo: r' = (f/2)*(exp(r/f) - exp(-r/f)) = f*sinh(r/f)
% in metodo phi–cos/sin za popravljanje koordinat.
    
    % center
    cx = principal_point(1);
    cy = principal_point(2); 

    % x,y od principal point do tock na robu
    dx_e = corners_edge(:,1)   - cx;   
    dy_e = corners_edge(:,2)   - cy;
    % x,y od principal point do tock na sredini
    dx_m = corners_middle(:,1) - cx;   
    dy_m = corners_middle(:,2) - cy;
    
    % radij do tock na robu
    r_e  = sqrt(dx_e.^2 + dy_e.^2);  
    % phi za tocke na robu
    phi_e = atan2(dy_e, dx_e);

    % radij do tock na sredini
    r_m  = sqrt(dx_m.^2 + dy_m.^2);  
    % phi do tock na sredini
    phi_m = atan2(dy_m, dx_m);

    % corrected distortion (po formuli)
    rl_e = (f/2) * (exp(r_e./f) - exp(-r_e./f));
    rl_m = (f/2) * (exp(r_m./f) - exp(-r_m./f));

    % razlika v dolzini ko je r popravljen
    dr_e = rl_e - r_e; % za robne piksle
    dr_m = rl_m - r_m; % za sredinske piksle

    
    % robne tocke
    x_e_corr = corners_edge(:,1)   + dr_e .* cos(phi_e); % x za kolikor se mora premakniti originalno tocko
    y_e_corr = corners_edge(:,2)   + dr_e .* sin(phi_e); % y za kolikor se mora premakniti originalno tocko
    % sredinske tocke
    x_m_corr = corners_middle(:,1) + dr_m .* cos(phi_m); % x za kolikor se mora premakniti originalno tocko
    y_m_corr = corners_middle(:,2) + dr_m .* sin(phi_m); % y za kolikor se mora premakniti originalno tocko

    [~, dist_e] = fitline([x_e_corr'; y_e_corr']);
    [~, dist_m] = fitline([x_m_corr'; y_m_corr']);
    nonlin_calib = sum(dist_e.^2) + sum(dist_m.^2);

end