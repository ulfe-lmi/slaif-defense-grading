slika = imread('Image_rect2.tif'); 
slika = repmat(slika, [1, 1, 3]);

figure;
image(slika);
title('Izberite 4 točke na sliki');
[x, y] = ginput(4); 

% risanje točk
hold on;
plot(x, y, 'ro', 'MarkerSize', 5); %rdeči krogi
hold off;

% Definiranje vhodnih in idelnih točk za projektivno transformacijo
input = [x(1) y(1); x(2) y(2); x(3) y(3); x(4) y(4)]; 
ideal = [0 0; 0 255; 255 255; 255 0]; 

% projektivna transformacija
T = maketform("projective", input, ideal); 
transf = imtransform(slika, T, 'XData', [0, 255], 'YData', [0, 255]);

% sahovnica
korakX = 255 / 11;
korakY = 255 / 12;
[X, Y] = meshgrid(0:korakX:255, 0:korakY:255);
vogal = [X(:), Y(:)];

figure;
imshow(transf);
title('Korigirana slika');
hold on;
plot(vogal(:,1), vogal(:,2), 'rx');
hold off;

% inverzna transformacija
T_inverz = maketform('projective', ideal, input);

% prikaz oglišč na osnovni sliki
vogal_ = tformfwd(T_inverz, vogal);

figure;
imshow(slika);
title('Označeni vsi vogali');
hold on;
plot(vogal_(:,1), vogal_(:,2), 'rx');
hold off;