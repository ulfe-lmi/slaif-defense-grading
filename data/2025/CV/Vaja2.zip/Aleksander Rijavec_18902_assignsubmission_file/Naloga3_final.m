slika = imread('Image15.tif');
rgb_slika = repmat(slika, 1, 1, 3);
figure;
imshow(rgb_slika);
title('Kliknite 12 točk: prvih 6 na robu, naslednjih 6 v središču');

[x_koordinate, y_koordinate] = ginput(12);
disp('Izbrane točke (x, y):');
tabela_tock = [x_koordinate, y_koordinate];
disp(tabela_tock);
[visina, sirina, ~] = size(slika);
tocke_rob = [(sirina / 2 - x_koordinate(1:6))'; (visina / 2 - y_koordinate(1:6))'];
tocke_center = [(sirina / 2 - x_koordinate(7:12))'; (visina / 2 - y_koordinate(7:12))'];
[theta_rub, r_rub] = cart2pol(tocke_rob(1,:), tocke_rob(2,:));
[theta_center, r_center] = cart2pol(tocke_center(1,:), tocke_center(2,:));


[koef_rub, pocetna_greska_rub] = fitline(tocke_rob);
[koef_srediste, pocetna_greska_srediste] = fitline(tocke_center);
ukupna_greska_rub = sqrt(sum(pocetna_greska_rub.^2));
ukupna_greska_srediste = sqrt(sum(pocetna_greska_srediste.^2));
suma_odstupanja_rub = ukupna_greska_rub;
suma_odstupanja_srediste = ukupna_greska_srediste;

for f = 400:20:800
    optimizirani_rob_r = (-f / 2) .* ((exp(-2 .* r_rub ./ f) - 1) ./ exp(-r_rub ./ f));
    optimizirani_center_r = (-f / 2) .* ((exp(-2 .* r_center ./ f) - 1) ./ exp(-r_center ./ f));

    % polarni v krtezicni
    [x_rub_opt, y_rub_opt] = pol2cart(theta_rub, optimizirani_rob_r);
    [x_srediste_opt, y_srediste_opt] = pol2cart(theta_center, optimizirani_center_r);

    rub_opt_tocke = [x_rub_opt; y_rub_opt];
    srediste_opt_tocke = [x_srediste_opt; y_srediste_opt];

    % Izračun grešaka za optimizirane točke
    [~, greska_rub] = fitline(rub_opt_tocke);
    [~, greska_srediste] = fitline(srediste_opt_tocke);
    
    suma_odstupanja_rub = [suma_odstupanja_rub, sqrt(sum(greska_rub.^2))];
    suma_odstupanja_srediste = [suma_odstupanja_srediste, sqrt(sum(greska_srediste.^2))];
end

% prikaz
f_values = 400:20:800;
figure;
plot(f_values, suma_odstupanja_rub(2:end) + suma_odstupanja_srediste(2:end));
title('Skupna napaka v odvisnosti od f');
xlabel('f');
ylabel('Skupna vsota kvadratov napak');
