slika = imread('Image15.tif');
rgb_slika = repmat(slika, 1, 1, 3);
%figure;
%imshow(rgb_slika);
%title('Kliknite 12 točk: prvih 6 na robu, naslednjih 6 v središču');

% Izberi 12 točk na sliki
%[x_koordinate, y_koordinate] = ginput(12);
x_koordinate = [43.8898, 42.0124, 40.7608, 38.8833, 43.2640, 43.8898,274.8155, 271.6864, 266.6799, 259.1701, 254.1636, 251.6604]';
y_koordinate = [67.1493, 144.7503, 221.0997, 257.3970, 326.2366, 392.5730,82.1688, 120.3435, 194.1897, 266.1584, 333.7464, 396.3279]';
[visina, sirina, ~] = size(slika);


% Razdeli točke na robne in sredinske
tocke_rob = [(sirina / 2 - x_koordinate(1:6))'; (visina / 2 - y_koordinate(1:6))'];
tocke_center = [(sirina / 2 - x_koordinate(7:12))'; (visina / 2 - y_koordinate(7:12))'];

% Pretvori točke iz kartezičnih v polarne koordinate
[theta_rub, r_rub] = cart2pol(tocke_rob(1,:), tocke_rob(2,:));
[theta_center, r_center] = cart2pol(tocke_center(1,:), tocke_center(2,:));
% Začetni izračun napak brez optimizacije
[koef_rub, pocetna_greska_rub] = fitline(tocke_rob);
[koef_srediste, pocetna_greska_srediste] = fitline(tocke_center);
ukupna_greska_rub = sqrt(sum(pocetna_greska_rub.^2));
ukupna_greska_srediste = sqrt(sum(pocetna_greska_srediste.^2));
suma_odstupanja_rub = ukupna_greska_rub;
suma_odstupanja_srediste = ukupna_greska_srediste;

% Funkcija za izračun skupne napake glede na f
function skupna_napaka = izracunNapake(f, theta_rub, r_rub, theta_center, r_center)
    % Optimiziraj robne točke
    optimizirani_rob_r = (-f / 2) .* ((exp(-2 .* r_rub ./ f) - 1) ./ exp(-r_rub ./ f));
    optimizirani_center_r = (-f / 2) .* ((exp(-2 .* r_center ./ f) - 1) ./ exp(-r_center ./ f));
    
    % Pretvori nazaj v kartezične koordinate
    [x_rub_opt, y_rub_opt] = pol2cart(theta_rub, optimizirani_rob_r);
    [x_srediste_opt, y_srediste_opt] = pol2cart(theta_center, optimizirani_center_r);
    
    rub_opt_tocke = [x_rub_opt; y_rub_opt];
    srediste_opt_tocke = [x_srediste_opt; y_srediste_opt];

    % Izračunaj napake
    [~, greska_rub] = fitline(rub_opt_tocke);
    [~, greska_srediste] = fitline(srediste_opt_tocke);
    
    % Skupna napaka
    skupna_napaka = sqrt(sum(greska_rub.^2)) + sqrt(sum(greska_srediste.^2));
end

% Optimizacija z uporabo fminsearch
f_optimalno = fminsearch(@(f) izracunNapake(f, theta_rub, r_rub, theta_center, r_center), 400);

% Izpis optimalne vrednosti f
disp(['Optimalna vrednost f: ', num2str(f_optimalno)]);

