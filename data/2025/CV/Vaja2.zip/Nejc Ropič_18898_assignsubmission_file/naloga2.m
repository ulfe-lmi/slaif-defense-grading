A = imread('Image_rect3.tif');  

[height, width, channels] = size(A);

imshow(A)
hold on;

[x,y] = ginput(4);
%% 2. naloga
x = [197.3159; 502.1915; 499.4055; 112.5398];
y = [95.4254; 144.7786; 425.7736; 358.1119];

U = [x y];
X = [0 0;
     500 0;
     500 500;
     0 500];

T = fitgeotrans(U, X,'projective');
outputView = imref2d([500 500]);

B = imwarp(A, T, 'OutputView', outputView);
figure, imshow(B);

kvadrati_x_os = 13;
kvadrati_y_os = 12;
[Xg, Yg] = meshgrid(linspace(0, 500, kvadrati_x_os), linspace(0, 500, kvadrati_y_os));
idealGrid = [Xg(:), Yg(:)];

% pretvorba idealnih koordinat nazaj v originalne s pomočjo inverzne transformacije
[origX, origY] = transformPointsInverse(T, idealGrid(:,1), idealGrid(:,2));

% zzris mreže oglišč na originalno (popačeno) sliko 
figure, image(A), colormap gray, axis image
title('Označena oglišča vseh kvadratov šahovnice na originalni sliki')
hold on
plot(origX, origY, 'r.', 'MarkerSize', 10);

