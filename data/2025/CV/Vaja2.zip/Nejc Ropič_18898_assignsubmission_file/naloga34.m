%% dolocanje premice
addpath("toolbox_calib\")
A = imread('Image15.tif');
[height, width, ~] = size(A);

imshow(A); hold on;
st_vstavljenih_tock = 5;

[x_robni, y_robni] = ginput(st_vstavljenih_tock);
[x_sredinska, y_sredinska] = ginput(st_vstavljenih_tock);
%% 3. naloga
x_robni = [44.8781; 40.8980; 41.2960; 43.6841; 46.8682];
y_robni = [68.3607; 183.3856; 256.6194; 360.5000; 452.8383];
x_sredinska = [309.5547; 301.1965; 295.6244; 285.6741; 279.3060];
y_sredinska = [86.2711; 196.5199; 265.7736; 364.0821; 452.8383];

principal_point = [ 303.80733   243.91482 ];
x_sredina = principal_point(1);
y_sredina = principal_point(2);
% Interval za f
f_values = 400:20:800;
errors = zeros(size(f_values));

for i = 1:length(f_values)
    f = f_values(i);
    % racunanje napake
    errors(i) = compute_error(f,x_robni, y_robni, x_sredinska, ...
                                    y_sredinska, x_sredina, y_sredina);
end

figure;
plot(f_values, errors, 'b-o');
xlabel('f ');
ylabel('Vsota kvadratov razdalj');
grid on;

%% 4. naloga

% funkcija napake
error_fun = @(f) compute_error(f, x_robni, y_robni, x_sredinska, y_sredinska, x_sredina, y_sredina);

% iskanje minimuma
f0 = 500;
f_opt = fminsearch(error_fun, f0);

figure;
plot(f_values, errors, 'b-o');
xline(f_opt, 'r--', 'LineWidth', 1.5);
xlabel('f');
ylabel('Vsota kvadratov razdalj');
legend('Napake', sprintf('Minimiziran f = %.2f', f_opt));
grid on;


