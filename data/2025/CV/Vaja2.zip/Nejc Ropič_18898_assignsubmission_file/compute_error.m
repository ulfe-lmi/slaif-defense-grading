function error = compute_error(f, x_robni, y_robni, x_sredinska, y_sredinska, x_sredina, y_sredina)
    
    % izracun obeh radijev - razdalja vsake tocke od sredisce
    r_rob = sqrt((x_robni - x_sredina).^2 + (y_robni - y_sredina).^2);
    r_center = sqrt((x_sredinska - x_sredina).^2 + (y_sredinska - y_sredina).^2);

    % Preslikava iz popačenih radijev r' v nepopačene r'_l po enačbi (2)
    r_rob_popacen = - (f/2) .* ((exp(-2 .* r_rob ./ f)) - 1) ./ exp(-r_rob ./ f);
    r_center_popacen = - (f/2) .* ((exp(-2 .* r_center ./ f)) - 1) ./ exp(-r_center ./ f);

    % korekcijski faktor
    korekcija_rob = r_rob_popacen ./ r_rob;
    korekcija_center = r_center_popacen ./ r_center;

    % korekcija tock po formuli korig_tocka = sredina + (tocka_premice - sredina) * korekcijski faktor
    x_rob_korigiran = x_sredina + (x_robni - x_sredina) .* korekcija_rob;
    y_rob_korigiran = y_sredina + (y_robni - y_sredina) .* korekcija_rob;

    x_center_korigiran = x_sredina + (x_sredinska - x_sredina) .* korekcija_center;
    y_center_korigiran = y_sredina + (y_sredinska - y_sredina) .* korekcija_center;

    % fit premice
    [C_rob, dist_rob] = fitline([x_rob_korigiran'; y_rob_korigiran']);
    [C_center, dist_center] = fitline([x_center_korigiran'; y_center_korigiran']);

    % vsota kvadratov napaka
    error = sum(dist_rob.^2) + sum(dist_center.^2);
end