%% projekcijska transformacija
clc; close all;

slika =imread("Image_rect2.tif");

% figure; imshow(slika);
% [x,y] = ginput(4);              % moraš označiti v pravilnem vrstnem redu
% tocke = [x y];                  % levo zgoraj, desno zgoraj, desno spodaj, levo spodaj
% close;

velikost_polja = 30;
vrstice = 11; stolpci = 12;

idealna_sahovnica = [0 0;
                     velikost_polja*stolpci 0;
                     velikost_polja*stolpci velikost_polja*vrstice;
                     0 velikost_polja*vrstice];       % naredi idealno šahovnico
                          % levo zgoraj, desno zgoraj, desno spodaj, levo
                          % spodaj

% Ustvari mrežo v koordinatah idealne šahovnice
[Xgrid, Ygrid] = meshgrid(0:velikost_polja:(stolpci*velikost_polja), ...
                          0:velikost_polja:(vrstice*velikost_polja));
        
% izračunaj projektivno transformacijo
tform = maketform('projective', tocke, idealna_sahovnica);

% izvedi transformacijo slike
[projekcija, Xdata, Ydata] = imtransform(slika, tform, ...
    'XData', [0 stolpci*velikost_polja], ...
    'YData', [0 vrstice*velikost_polja]);

% inverzna transformacija za izris mreže na originalni sliki

tform_inv = maketform('projective', idealna_sahovnica, tocke);
[origX, origY] = tformfwd(tform_inv, Xgrid(:), Ygrid(:));           % vrne točke na origginalno sliko

% Prikaži vse tri slike
figure; 

subplot(1,3,1); imshow(slika);
hold on;
plot(tocke(:,1), tocke(:,2), 'bx','MarkerSize',5);
title('Originalna slika + izbrane točke');


subplot(1,3,2); imshow(projekcija, 'XData', Xdata, 'YData', Ydata);
hold on;
plot(Xgrid, Ygrid, 'rx', 'MarkerSize',4);
title('projektivna tranformacija');


subplot(1,3,3); imshow(slika);
hold on;
plot(origX, origY, 'g.');
title('Original slika z mrežo ogljišč po transformaciji');

