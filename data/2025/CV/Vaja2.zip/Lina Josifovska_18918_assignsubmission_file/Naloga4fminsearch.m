clear; close all; clc;

I = imread('Image15.tif');
figure; imshow(I); title('Izberi točk'); hold on;

disp('Izberi točk v robni vrstici.');
[x1_zajete, y1_zajete] = ginput(10);
disp('Izberi točk v notranji vrstici.');
[x2_zajete, y2_zajete] = ginput(10);

cc = [319.5, 239.5];   
xc = cc(1);             
yc = cc(2);             

x_rel = [x1_zajete; x2_zajete] - xc;
y_rel = [y1_zajete; y2_zajete] - yc;

options = optimset('MaxFunEvals',5000);
f_opt = fminsearch(@(ff) funkcija_za_fminsearch_from_points(ff, x_rel, y_rel), 400);
fprintf('Optimalni f = %.6f\n', f_opt);
