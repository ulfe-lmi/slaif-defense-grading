clear; close all; clc;

imgName = 'Image_rect3.tif';
outSize = 300;        
numCols = 12;         
numRows = 11;         
markerColor = 'red';
markerSize = 4;

I = imread(imgName);
figure; imshow(I); title('Klikni 4 vogale');
[x, y] = ginput(4);
inputPts = [x(:), y(:)];

a = [0; outSize; outSize; 0];
b = [0; 0; outSize; outSize];
idealPts = [a, b];
T = maketform('projective', inputPts, idealPts);

Irect = imtransform(I, T, 'XData', [0 outSize], 'YData', [0 outSize]);

xs = linspace(0, outSize, numCols+1);   
ys = linspace(0, outSize, numRows+1);   
[GX, GY] = meshgrid(xs, ys);
gridRect = [GX(:), GY(:)];  

Irect_marked = insertMarker(Irect, gridRect, 'o', 'Color', markerColor, 'Size', markerSize);
figure; imshow(Irect_marked); title('Popravljena slika s presecisci mreze');

invT = maketform('projective', idealPts, inputPts);
[xOrig, yOrig] = tformfwd(invT, gridRect(:,1), gridRect(:,2)); 

Iorig_marked = insertMarker(I, [xOrig, yOrig], 'o', 'Color', markerColor, 'Size', markerSize);
figure; imshow(Iorig_marked); title('Originalna slika s preslikanimi presecisci mreze');

