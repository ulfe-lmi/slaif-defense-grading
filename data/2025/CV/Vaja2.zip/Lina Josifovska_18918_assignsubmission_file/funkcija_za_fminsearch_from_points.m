function napaka = funkcija_za_fminsearch_from_points(f, x_rel, y_rel)
    x_rel = x_rel(:); y_rel = y_rel(:);
    n = numel(x_rel);
    r = sqrt(x_rel.^2 + y_rel.^2);
    theta = atan2(y_rel, x_rel);
    r_pop = f .* sinh(r ./ f);   

    [x_corr, y_corr] = pol2cart(theta, r_pop); 

    XY = [x_corr.'; y_corr.'];

    finiteIdx = all(isfinite(XY),1);
    XY = XY(:, finiteIdx);
    if size(XY,2) < 2
        napaka = Inf; return;
    end

    [~, dist] = fitline(XY);
    napaka = sqrt(sum(dist.^2));
end
