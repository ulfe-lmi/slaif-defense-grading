clear; close all; clc;

I = imread('Image15.tif');
figure; imshow(I); title('Select points: first column (edge), then second column (center)');
hold on;

stevilo_tock = 10;
disp('Izberi točk v prvi stolpec, nato pritisni Enter.');
[x1_zajete, y1_zajete] = ginput(stevilo_tock);
disp('Izberi točk v drugi stolpec, nato pritisni Enter.');
[x2_zajete, y2_zajete] = ginput(stevilo_tock);

plot(x1_zajete,y1_zajete,'ro','MarkerFaceColor','r');
plot(x2_zajete,y2_zajete,'go','MarkerFaceColor','g');

cc = [319.5, 239.5];   
xc = cc(1);             
yc = cc(2);             
   
x1 = x1_zajete - xc;
y1 = y1_zajete - yc;
x2 = x2_zajete - xc;
y2 = y2_zajete - yc;

r1 = sqrt(x1.^2 + y1.^2);     
r2 = sqrt(x2.^2 + y2.^2);
theta1 = atan2(y1, x1);
theta2 = atan2(y2, x2);

f = 400:20:800;   
napaka = zeros(size(f));     

for aind = 1:length(f)
    ff = f(aind);
    rl1 = ff .* sinh(r1 ./ ff);   
    rl2 = ff .* sinh(r2 ./ ff);
   
    [X1, Y1] = pol2cart(theta1, rl1);  
    [X2, Y2] = pol2cart(theta2, rl2);
    
    X1_img = X1 + xc;  Y1_img = Y1 + yc;
    X2_img = X2 + xc;  Y2_img = Y2 + yc;
    
    XY1 = [X1_img(:)'; Y1_img(:)'];
    XY2 = [X2_img(:)'; Y2_img(:)'];
   
   [~, d1] = fitline(XY1);
   [~, d2] = fitline(XY2);
   
    napaka(aind) = sum(d1.^2) + sum(d2.^2);   
    
end

figure;
plot(f, napaka, '-o', 'LineWidth', 1.4);
xlabel('f'); ylabel('Sum of squared distances'); grid on;
title('f vs napaka');

[bestVal, idx] = min(napaka);
bestF = f(idx);
fprintf('Best f = %.3f (sumsq = %.6g) at index %d\n', bestF, bestVal, idx);

% ----- optional: show corrected points for best f -----
ff = bestF;
rl1 = ff .* sinh(r1 ./ ff); rl2 = ff .* sinh(r2 ./ ff);
[X1b, Y1b] = pol2cart(theta1, rl1); [X2b, Y2b] = pol2cart(theta2, rl2);
X1b = X1b + xc; Y1b = Y1b + yc; X2b = X2b + xc; Y2b = Y2b + yc;

figure; imshow(I); hold on;
plot(x1_zajete, y1_zajete, 'ro', 'MarkerFaceColor','r');    % originals
plot(x2_zajete, y2_zajete, 'go', 'MarkerFaceColor','g');
plot(X1b, Y1b, 'rx','MarkerSize',10,'LineWidth',1.2);       % corrected
plot(X2b, Y2b, 'gx','MarkerSize',10,'LineWidth',1.2);

% draw fitted straight lines on corrected points
XY1b = [X1b(:)'; Y1b(:)']; XY2b = [X2b(:)'; Y2b(:)'];
[C1b, d1b] = fitline(XY1b); [C2b, d2b] = fitline(XY2b);
draw_line(C1b, 'y-'); draw_line(C2b, 'y-');
title(sprintf('Corrected points for f = %.3f', bestF));

% helper to draw line (same as before)
function draw_line(C, style)
    a = C(1); b = C(2); c = C(3);
    ax = axis;
    xs = linspace(ax(1), ax(2), 2);
    if abs(b) > 1e-9
        ys = -(a*xs + c)/b;
    else
        xs = -c/a * ones(1,2);
        ys = linspace(ax(3), ax(4), 2);
    end
    plot(xs, ys, style, 'LineWidth', 1.5);
end
