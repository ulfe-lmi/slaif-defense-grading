import fitline.*
import normalise2dpts.*


sahovnica = imread("Image_rect7.tif");
imshow(sahovnica);
title("Izberi presečiščne točke oblike 12x11")

[x,y] = ginput(4);

input_points = [x,y];

x_kvadratov = 12;
y_kvadratov = 11;
dxy = 30;

sizex = x_kvadratov*dxy;
sizey = y_kvadratov*dxy;

output_points = [0 0;           
                 sizex 0;
                 sizex sizey;
                 0 sizey];

T = maketform('projective', input_points, output_points);


I_corrected = imtransform(sahovnica, T, 'XData', [0 sizex], 'YData', [0 sizey]);

num_corners_x = x_kvadratov + 1;
num_corners_y = y_kvadratov + 1;

[xg, yg] = meshgrid(0:dxy:(num_corners_x-1)*dxy, 0:dxy:(num_corners_y-1)*dxy);

figure;
imshow(I_corrected);
hold on;
plot(xg, yg, 'ro', 'MarkerSize', 5);
title('Projektivno popravljena slika (maketform + imtransform)');

tocke_pop = [xg(:),yg(:)];

Ti = maketform('projective',output_points, input_points);

[X_orig, Y_Orig] = tformfwd(Ti, tocke_pop(:,1), tocke_pop(:,2));

figure;
imshow(sahovnica)
hold on;
plot(X_orig, Y_Orig,'ro', 'MarkerSize', 5)
title('popravljene točke')

%naloga 3
figure
ImDistorsion = imread("Image15.tif");
imshow(ImDistorsion)
title("Označi 6 presečišč vertikalnih stranic šahovnice to izriše premico, nariši 2 premice")
hold on

cx = 303.44701;
cy = 242.59023;

for i = 1:2
    [x2,y2] = ginput(6);
    XY = [x2'; y2'];
    C = fitline(XY);

    ypoints = linspace(min(y2), max(y2), 500);
    xpoints = (-(ypoints*C(2)) - C(3)) / C(1);

    if i == 1
        plot(xpoints,ypoints,"b")
        alpha1  = atan2(XY(2,:) - cy, XY(1,:) - cx);
        r_dist1 = sqrt((cx-XY(1,:)).^2 + (cy-XY(2,:)).^2);
    elseif i == 2
        plot(xpoints,ypoints,"g")
        alpha2 = atan2(XY(2,:) - cy, XY(1,:) - cx);
        r_dist2 = sqrt((cx-XY(1,:)).^2 + (cy-XY(2,:)).^2);
    end
 
end  
  

r1_popr = r_dist1;
r2_popr = r_dist2;



X1_popr = XY(1);
Y1_popr = XY(2);

f_values = 400:20:800;      
sumSq1 = zeros(size(f_values));
sumSq2 = zeros(size(f_values));
SummAll = zeros(size(f_values));


for k = 1:numel(f_values)
    f = f_values(k);

        r1_popr = (-f/2) .* ((exp(-(2*r_dist1)./f) - 1) ./ exp(-(r_dist1)./f));
        r2_popr = (-f/2) .* ((exp(-(2*r_dist2)./f) - 1) ./ exp(-(r_dist2)./f));

        X1_popr = cx + r1_popr .* cos(alpha1);
        Y1_popr = cy + r1_popr .* sin(alpha1);
        XY1 = [X1_popr; Y1_popr];
        [~,dst1] = fitline(XY1);
        sumSq1(k) = sum(dst1.^2);

        X2_popr = cx + r2_popr .* cos(alpha2);
        Y2_popr = cy + r2_popr .* sin(alpha2);
        XY2 = [X2_popr; Y2_popr];
        [~,dst2] = fitline(XY2);
        sumSq2(k) = sum(dst2.^2);

        SummAll(k) = sumSq1(k) + sumSq2(k);

end
      
figure
title("Napaka distorzije")
plot(f_values,sumSq1,'b')
hold on
plot(f_values,sumSq2,'g');
hold on
plot(f_values,SummAll,'y')
legend('Napaka prve črte','Napaka druge črte', 'skupna napaka')
xlabel("f")
ylabel("Napaka")

%Naloga 4
function skupna_napaka = PopraviDistorzijo(f, cx, cy, r_dists, alphas)

    skupna_napaka = 0;

    for i = 1:numel(r_dists)
        r_corr = (-f/2) .* ((exp(-(2*r_dists{i})./f) - 1) ./ exp(-(r_dists{i})./f));

        X_corr = cx + r_corr .* cos(alphas{i});
        Y_corr = cy + r_corr .* sin(alphas{i});

        [~, dist] = fitline([X_corr; Y_corr]);

        skupna_napaka = skupna_napaka + sum(dist.^2);
    end
end


r_dists = {r_dist1, r_dist2};
alphas = {alpha1, alpha2};

f0 = 600;

f_opt = fminsearch(@(f) PopraviDistorzijo(f, cx, cy, r_dists, alphas), f0);

fprintf('Optimalni parameter f = %.2f\n', f_opt);

    
   