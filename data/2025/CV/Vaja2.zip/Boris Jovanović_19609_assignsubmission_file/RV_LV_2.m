clear all;
close all;

%% Druga naloga:
A = imread('Image_rect2.tif');
A = repmat(A,[1,1,3]);

figure;
image(A);                  % prikaz slike
%axis image;               % ohrani razmerje stranic
axis off;                  % skrij osi (enako kot imshow)
%set(gca,'YDir','reverse') % obvezno! da se Y-os obrne kot pri imshow
title('Klikni 4 vogale šahovnice v pravilnem vrstnem redu (npr. levo zgoraj, desno zgoraj, desno spodaj, levo spodaj)');
hold on;
for i = 1:4
    [x(i), y(i)] = ginput(1); % vrne vektor x in y koordinat klikov
    scatter(x(i), y(i), 500, 'red', 'x', 'LineWidth', 2);
    drawnow; % osveži prikaz takoj
end
hold off; % končamo dodajanje, naslednja risba bo nova figura

vhodne_tocke_vogali = [x(:), y(:)]; % 4×2 matrika
[visina, sirina] = size(A); % višina in širina nove slike
izhodne_tocke_vogali = [0 0; sirina-1 0; sirina-1 visina-1; 0 visina-1];

projektivna_transformacija = maketform('projective', vhodne_tocke_vogali, izhodne_tocke_vogali);
poravnana_slika = imtransform(A, projektivna_transformacija, 'XData', [0 sirina-1], 'YData', [0 visina-1]);

figure;
image(poravnana_slika);
%axis image;
axis off;
%set(gca,'YDir','reverse');
title('Poravnana (projektivno popravljena) šahovnica');

st_kvadratkov_X = 12; % število kvadratkov horizontalno
st_kvadratkov_Y = 13; % število kvadratkov vertikalno

vsi_vogali_x = linspace(0, sirina-1, st_kvadratkov_X+1); % +1 ker vogalov je vedno za ena več kot kvadratov
vsi_vogali_y = linspace(0, visina-1, st_kvadratkov_Y+1);

[x, y] = meshgrid(vsi_vogali_x, vsi_vogali_y);
vsi_vogali = [x(:), y(:)];  % vse vogalne točke v poravnani sliki

% Poravnana šahovnica
figure;
image(poravnana_slika);
%axis image;
axis off;
%set(gca,'YDir','reverse');
axis([0 sirina 0 visina]);
hold on; % da lahko dodamo vse vogalne točke
scatter(vsi_vogali(:,1), vsi_vogali(:,2), 'r', 'filled'); % označimo vse vogale
title('Vsi vogali kvadratov na poravnani sliki');
hold off; % zaključimo risanje čez sliko

inverzna_projektivna_transformacija = fliptform(projektivna_transformacija); % inverzna transformacija
originalni_vogali = tformfwd(inverzna_projektivna_transformacija, vsi_vogali); % preslika v izhodiščno sliko

figure;
image(A);
%axis image;
axis off;
%set(gca,'YDir','reverse');
hold on;
scatter(originalni_vogali(:,1), originalni_vogali(:,2), 'r', 'filled');
title('Vsi vogali kvadratov na originalni sliki');

%% Tretja naloga:
A = imread('Image_rect15.tif');
A = repmat(A,[1,1,3]);

f1 = figure;
image(A);
%axis image;
axis off;
%set(gca,'YDir','reverse');
hold on;
calib = load('/home/risbo/Dokumenti/RV_vaje/RV_LV_2/Calib_Results.mat', 'cc'); % središčno točko slike naložimo iz kalibracijskih rezultatov prve naloge
scatter(calib.cc(1), calib.cc(2), 'filled'); 
legend('Optični center');

st_tock = 12; % število točk za vsako vertikalno linijo
uiwait(msgbox('Označi eno vertikalno linijo oglišč na robu šahovnice (12 oglišč).', 'Navodila', 'modal'));
for i = 1:st_tock
    [xe(i), ye(i)] = ginput(1); % vrne vektor x in y koordinat klikov
    scatter(xe(i), ye(i), 500, 'red', 'x', 'LineWidth', 2);
    drawnow; % osveži prikaz takoj
end
uiwait(msgbox('Označi vertikalno linijo oglišč najbližje sredini slike (12 oglišč).', 'Navodila', 'modal'));
for i = 1:st_tock
    [xc(i), yc(i)] = ginput(1); % vrne vektor x in y koordinat klikov
    scatter(xc(i), yc(i), 500, 'green', 'x', 'LineWidth', 2);
    drawnow; % osveži prikaz takoj
end

% Naredimo fit premice na točke samo za prikaz na sliki:
edge_line = fitline([xe; ye]);
center_line = fitline([xc; yc]);

hold on;
% Risanje premice za robne točke:
fplot(@(x) -edge_line(1)/edge_line(2)*x - edge_line(3)/edge_line(2), [0, size(A,2)], 'r', 'LineWidth', 1.5);
ylim([0, size(A,1)]);

% Risanje premice za centralne točke:
fplot(@(x) -center_line(1)/center_line(2)*x - center_line(3)/center_line(2), [0, size(A,2)], 'b', 'LineWidth', 1.5);
ylim([0, size(A,1)]);

% Premik koordinat v center slike:
xe_c = xe - calib.cc(1);
ye_c = ye - calib.cc(2);
xc_c = xc - calib.cc(1);
yc_c = yc - calib.cc(2);

% Fitanje premic v koordinatnem sistemu s središčem v optičnem centru:
[edge_line, edge_dist] = fitline([xe_c(:)'; ye_c(:)']);  
[center_line, center_dist] = fitline([xc_c; yc_c]);

% Izračun skupne napake:
err(1,1) = sqrt(sum(edge_dist.^2));         
err(1,2) = sqrt(sum(center_dist.^2));
err(1,3) = err(1,1) + err(1,2);

% Definicija vektorja parametra f:
f = 400:20:800;

r_e = zeros(st_tock, 1); % radiji robnih točk (edge points), računani od optičnega središča
r_e_cor = zeros(size(f,2), st_tock, 1); % korigirani radiji robnih točk
% Za vsako možno vrednost f bomo shranili nov niz popravljenih radijev r_e_cor.
% Na koncu bomo to uporabili za iskanje optimalnega f, ki manjša napako.

theta_e = zeros(st_tock, 1);
% theta_e bodo koti (v radianih) vsake robne točke glede na optično središče.
% Z njimi bomo kasneje rekonstruirali položaje točk po korekciji (v polarni obliki).

% Pretvorba iz kartezičnih koordinat v polarne koordinate:
r_c = zeros(st_tock, 1);
theta_c = zeros(st_tock, 1);

for i = 1 : st_tock
    r_e(i) = sqrt(xe_c(i)^2 + ye_c(i)^2);
    theta_e(i) = atan2(ye_c(i), xe_c(i));

    r_c(i) = sqrt(xc_c(i)^2 + yc_c(i)^2);
    theta_c(i) = atan2(yc_c(i), xc_c(i));
end

% Izračun korigiranih radijev vseh točk in napake za vsak definiran f:
r_c_cor = zeros(size(f, 2), st_tock, 1);

for j = 1 : size(f, 2) % size(f,2) je dolžina vektorja f, v tem primeru 21 različnih vrednosti.
    for i = 1 : st_tock % Gre čez vse točke, ki smo jih predhodno pretvorili v polarne koordinate (r_e(i) in r_c(i)).
        r_e_cor(j, i) = -f(j)/2 * (exp(-2*r_e(i)/f(j)) - 1) / (exp(-r_e(i)/f(j)));
        r_c_cor(j, i) = -f(j)/2 * (exp(-2*r_c(i)/f(j))-1)/(exp(-r_c(i)/f(j)));
    end

    % Pretvorba nazaj iz polarnih v kartezicne koordinate:
    [x_novi_tmp, y_novi_tmp] = pol2cart(theta_e, r_e_cor(j,:));
    
    % Prileganje premice skozi popravljene robne točke:
    [edge_line, edge_dist] = fitline([x_novi_tmp(:)'; y_novi_tmp(:)']);
    
    % Izračun napake prileganja:
    err(j+1, 1) = sqrt(sum(edge_dist.^2));
    
    % Isto za središčne točke:
    [x_novi_tmp, y_novi_tmp] = pol2cart(theta_c, r_c_cor(j,:));
    [edge_line, edge_dist] = fitline([x_novi_tmp(:)'; y_novi_tmp(:)']);
    err(j+1, 2) = sqrt(sum(edge_dist.^2));
    
    % Skupna napaka za obe liniji:
    err(j+1, 3) = err(j+1, 1) + err(j+1, 2);
end

% Prikaz izračunane napake glede na f:
figure;
plot(f, err(2:end,1), f, err(2:end,2), f, err(2:end,3));
% Zakaj 2:end?
%Ker je bila prva vrstica v err(1,:) rezervirana za izvorno, nekorigirano napako (brez popravka f = 0).
xlabel('f')
ylabel('error')
legend('error - edge','error - center', 'error - sum')

% Prikaz robnih točk pri različnih f:
figure;
polarscatter(theta_e, r_e);
hold on;
polarscatter(theta_e, r_e_cor(:,:));
legend(['original', string(f)]);
hold off;

% Nove korigirane vrednosti:
[minimum, min_index] = min(err(2:end,3));
figure(f1);
hold on;
[x_novi_tmp, y_novi_tmp] = pol2cart(theta_e, r_e_cor(min_index - 1,:)');
x_novi_tmp = x_novi_tmp + calib.cc(1);
y_novi_tmp = y_novi_tmp + calib.cc(2);
scatter(x_novi_tmp, y_novi_tmp, 500, 'yellow', 'x');
[x_novi_tmp, y_novi_tmp]=pol2cart(theta_c, r_c_cor(min_index - 1,:)');
x_novi_tmp = x_novi_tmp + calib.cc(1);
y_novi_tmp = y_novi_tmp + calib.cc(2);
scatter(x_novi_tmp, y_novi_tmp, 500, 'blue', 'x');
legend('optical center', 'uncorrected edge points (red)', 'uncorrected center points (green)', '', '', 'corrected edge points (yellow)', 'corrected center points (blue)');
hold off;

