% Intrinsic and Extrinsic Camera Parameters
%
% This script file can be directly excecuted under Matlab to recover the camera intrinsic and extrinsic parameters.
% IMPORTANT: This file contains neither the structure of the calibration objects nor the image coordinates of the calibration points.
%            All those complementary variables are saved in the complete matlab data file Calib_Results.mat.
% For more information regarding the calibration model visit http://www.vision.caltech.edu/bouguetj/calib_doc/


%-- Focal length:
fc = [ 657.453175445359875 ; 658.137763319905275 ];

%-- Principal point:
cc = [ 303.895457971947508 ; 243.148190633409371 ];

%-- Skew coefficient:
alpha_c = 0.000000000000000;

%-- Distortion coefficients:
kc = [ -0.259868440258877 ; 0.149982959551292 ; -0.000175643518561 ; 0.000161206278902 ; 0.000000000000000 ];

%-- Focal length uncertainty:
fc_error = [ 0.687675459393088 ; 0.841665238010820 ];

%-- Principal point uncertainty:
cc_error = [ 1.599052776163214 ; 1.337220319371903 ];

%-- Skew coefficient uncertainty:
alpha_c_error = 0.000000000000000;

%-- Distortion coefficients uncertainty:
kc_error = [ 0.006355147452469 ; 0.027288269606693 ; 0.000308398798660 ; 0.000333504419788 ; 0.000000000000000 ];

%-- Image size:
nx = 640;
ny = 480;


%-- Various other variables (may be ignored if you do not use the Matlab Calibration Toolbox):
%-- Those variables are used to control which intrinsic parameters should be optimized

n_ima = 20;						% Number of calibration images
est_fc = [ 1 ; 1 ];					% Estimation indicator of the two focal variables
est_aspect_ratio = 1;				% Estimation indicator of the aspect ratio fc(2)/fc(1)
center_optim = 1;					% Estimation indicator of the principal point
est_alpha = 0;						% Estimation indicator of the skew coefficient
est_dist = [ 1 ; 1 ; 1 ; 1 ; 0 ];	% Estimation indicator of the distortion coefficients


%-- Extrinsic parameters:
%-- The rotation (omc_kk) and the translation (Tc_kk) vectors for every calibration image and their uncertainties

%-- Image #1:
omc_1 = [ NaN ; NaN ; NaN ];
Tc_1  = [ NaN ; NaN ; NaN ];
omc_error_1 = [ NaN ; NaN ; NaN ];
Tc_error_1  = [ NaN ; NaN ; NaN ];

%-- Image #2:
omc_2 = [ 1.849050e+00 ; 1.899768e+00 ; -3.958709e-01 ];
Tc_2  = [ -1.560270e+02 ; -1.599115e+02 ; 7.574126e+02 ];
omc_error_2 = [ 1.510634e-03 ; 2.082767e-03 ; 3.048229e-03 ];
Tc_error_2  = [ 1.851173e+00 ; 1.536760e+00 ; 9.355543e-01 ];

%-- Image #3:
omc_3 = [ NaN ; NaN ; NaN ];
Tc_3  = [ NaN ; NaN ; NaN ];
omc_error_3 = [ NaN ; NaN ; NaN ];
Tc_error_3  = [ NaN ; NaN ; NaN ];

%-- Image #4:
omc_4 = [ 1.828132e+00 ; 2.116401e+00 ; -1.101009e+00 ];
Tc_4  = [ -6.552472e+01 ; -1.554527e+02 ; 7.789827e+02 ];
omc_error_4 = [ 1.239792e-03 ; 2.379591e-03 ; 3.103293e-03 ];
Tc_error_4  = [ 1.906508e+00 ; 1.568718e+00 ; 7.539772e-01 ];

%-- Image #5:
omc_5 = [ NaN ; NaN ; NaN ];
Tc_5  = [ NaN ; NaN ; NaN ];
omc_error_5 = [ NaN ; NaN ; NaN ];
Tc_error_5  = [ NaN ; NaN ; NaN ];

%-- Image #6:
omc_6 = [ -1.700934e+00 ; -1.929378e+00 ; -7.938686e-01 ];
Tc_6  = [ -1.495206e+02 ; -7.998263e+01 ; 4.446337e+02 ];
omc_error_6 = [ 1.306607e-03 ; 2.442212e-03 ; 2.908863e-03 ];
Tc_error_6  = [ 1.083711e+00 ; 9.199644e-01 ; 7.284896e-01 ];

%-- Image #7:
omc_7 = [ NaN ; NaN ; NaN ];
Tc_7  = [ NaN ; NaN ; NaN ];
omc_error_7 = [ NaN ; NaN ; NaN ];
Tc_error_7  = [ NaN ; NaN ; NaN ];

%-- Image #8:
omc_8 = [ 1.960734e+00 ; 1.823866e+00 ; 1.328207e+00 ];
Tc_8  = [ -1.708364e+02 ; -1.039293e+02 ; 4.619777e+02 ];
omc_error_8 = [ 2.735092e-03 ; 1.241001e-03 ; 2.777801e-03 ];
Tc_error_8  = [ 1.169357e+00 ; 9.821592e-01 ; 9.287919e-01 ];

%-- Image #9:
omc_9 = [ -1.364030e+00 ; -1.981796e+00 ; 3.189586e-01 ];
Tc_9  = [ -2.906223e+00 ; -2.257365e+02 ; 7.286411e+02 ];
omc_error_9 = [ 1.584587e-03 ; 2.033593e-03 ; 2.527327e-03 ];
Tc_error_9  = [ 1.786141e+00 ; 1.485933e+00 ; 9.163574e-01 ];

%-- Image #10:
omc_10 = [ NaN ; NaN ; NaN ];
Tc_10  = [ NaN ; NaN ; NaN ];
omc_error_10 = [ NaN ; NaN ; NaN ];
Tc_error_10  = [ NaN ; NaN ; NaN ];

%-- Image #11:
omc_11 = [ NaN ; NaN ; NaN ];
Tc_11  = [ NaN ; NaN ; NaN ];
omc_error_11 = [ NaN ; NaN ; NaN ];
Tc_error_11  = [ NaN ; NaN ; NaN ];

%-- Image #12:
omc_12 = [ NaN ; NaN ; NaN ];
Tc_12  = [ NaN ; NaN ; NaN ];
omc_error_12 = [ NaN ; NaN ; NaN ];
Tc_error_12  = [ NaN ; NaN ; NaN ];

%-- Image #13:
omc_13 = [ NaN ; NaN ; NaN ];
Tc_13  = [ NaN ; NaN ; NaN ];
omc_error_13 = [ NaN ; NaN ; NaN ];
Tc_error_13  = [ NaN ; NaN ; NaN ];

%-- Image #14:
omc_14 = [ NaN ; NaN ; NaN ];
Tc_14  = [ NaN ; NaN ; NaN ];
omc_error_14 = [ NaN ; NaN ; NaN ];
Tc_error_14  = [ NaN ; NaN ; NaN ];

%-- Image #15:
omc_15 = [ NaN ; NaN ; NaN ];
Tc_15  = [ NaN ; NaN ; NaN ];
omc_error_15 = [ NaN ; NaN ; NaN ];
Tc_error_15  = [ NaN ; NaN ; NaN ];

%-- Image #16:
omc_16 = [ NaN ; NaN ; NaN ];
Tc_16  = [ NaN ; NaN ; NaN ];
omc_error_16 = [ NaN ; NaN ; NaN ];
Tc_error_16  = [ NaN ; NaN ; NaN ];

%-- Image #17:
omc_17 = [ NaN ; NaN ; NaN ];
Tc_17  = [ NaN ; NaN ; NaN ];
omc_error_17 = [ NaN ; NaN ; NaN ];
Tc_error_17  = [ NaN ; NaN ; NaN ];

%-- Image #18:
omc_18 = [ NaN ; NaN ; NaN ];
Tc_18  = [ NaN ; NaN ; NaN ];
omc_error_18 = [ NaN ; NaN ; NaN ];
Tc_error_18  = [ NaN ; NaN ; NaN ];

%-- Image #19:
omc_19 = [ NaN ; NaN ; NaN ];
Tc_19  = [ NaN ; NaN ; NaN ];
omc_error_19 = [ NaN ; NaN ; NaN ];
Tc_error_19  = [ NaN ; NaN ; NaN ];

%-- Image #20:
omc_20 = [ NaN ; NaN ; NaN ];
Tc_20  = [ NaN ; NaN ; NaN ];
omc_error_20 = [ NaN ; NaN ; NaN ];
Tc_error_20  = [ NaN ; NaN ; NaN ];

