pretvori_hsv('yosemite_meadows.jpg', 1, 0.5)
pretvori_hsv('yosemite_meadows.jpg', 2, 0.5)
pretvori_hsv('yosemite_meadows.jpg', 3, 0.5);

pretvori_hsv('coloured_pencils.jpg', 1, 0.5)
pretvori_hsv('coloured_pencils.jpg', 2, 0.5)
pretvori_hsv('coloured_pencils.jpg', 3, 0.5);

function pretvori_hsv(slika, komponenta, vrednost)
    figure
    A = imread(slika);
    lab = rgb2hsv(A);
    lab(:,:,komponenta) = vrednost;
    rgb = hsv2rgb(lab);
    imshow(rgb)
end
%%
pretvori_lab('yosemite_meadows.jpg', 1, 50);
pretvori_lab('yosemite_meadows.jpg', 2, 0);
pretvori_lab('yosemite_meadows.jpg', 3, 0);

pretvori_lab('coloured_pencils.jpg', 1, 50);
pretvori_lab('coloured_pencils.jpg', 2, 0);
pretvori_lab('coloured_pencils.jpg', 3, 0);

function pretvori_lab(slika, komponenta, vrednost)
    figure
    A = imread(slika);
    lab = rgb2lab(A);
    lab(:,:,komponenta) = vrednost;
    rgb = lab2rgb(lab);
    imshow(rgb)
end