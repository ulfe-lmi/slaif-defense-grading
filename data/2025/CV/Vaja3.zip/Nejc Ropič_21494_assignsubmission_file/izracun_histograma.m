function [N,edgesR,edgesG,edgesB] = izracun_histograma(bins, R, G, B)

    R_norm = double(R(:)) / 255;
    G_norm = double(G(:)) / 255;
    B_norm = double(B(:)) / 255;

    edges = linspace(0,1,bins+1);

    idxR = discretize(R_norm, edges);
    idxG = discretize(G_norm, edges);
    idxB = discretize(B_norm, edges);

    valid = ~isnan(idxR) & ~isnan(idxG) & ~isnan(idxB);

    N = accumarray([idxR(valid), idxG(valid), idxB(valid)], 1, [bins bins bins]);

    edgesR = edges;
    edgesG = edges;
    edgesB = edges;
end
