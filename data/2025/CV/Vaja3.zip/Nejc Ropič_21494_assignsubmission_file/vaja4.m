clc, clear;
video = VideoReader('ladja.avi');
frames = read(video,[1, Inf]); 
[height, width, channels, num_of_frames] =size(frames);

% okvir za učenje barve morja
frame = 40;
slika = frames(275,:,:,frame); 

R = slika(:,:,1);
G = slika(:,:,2);
B = slika(:,:,3);

% izracun histograma
[N,edgesR,edgesG,edgesB] = izracun_histograma(8,R,G,B);

% Normalizacija histograma na 0,255
max_bin = max(N(:));
N_norm = uint8( (N / max_bin) * 255 );

% iskanje najbolj polnega bina po normalizaciji
[max_val, idx] = max(N(:));
[iR, iG, iB] = ind2sub(size(N_norm), idx);

% meje bina
R_min = edgesR(iR);
R_max = edgesR(iR+1);

G_min = edgesG(iG);
G_max = edgesG(iG+1);

B_min = edgesB(iB);
B_max = edgesB(iB+1);

% segmentacija slike po barvi
R_all = double(frames(:,:,1,frame))/255;
G_all = double(frames(:,:,2,frame))/255;
B_all = double(frames(:,:,3,frame))/255;

mask = (R_all >= R_min & R_all < R_max & ...
        G_all >= G_min & G_all < G_max & ...
        B_all >= B_min & B_all < B_max);

% prikaz segmentacije
figure;
subplot(1,2,1); imshow(frames(:,:,:,frame)); title('Izvirni frame');
subplot(1,2,2); imshow(mask); title('Segmentacija morja');

%% drugi del
writer = VideoWriter('ladja_sivinska_8bit.avi');
open(writer);

for f = 1:num_of_frames
    
    frameRGB = frames(:,:,:,f);
    
    % normalizerani kanali
    R_all = double(frameRGB(:,:,1)) / 255;
    G_all = double(frameRGB(:,:,2)) / 255;
    B_all = double(frameRGB(:,:,3)) / 255;
    
    % piksli v vektorjih
    R_vec = R_all(:);
    G_vec = G_all(:);
    B_vec = B_all(:);
    
    % ugotavljanje binov
    idxR = discretize(R_vec, edgesR);
    idxG = discretize(G_vec, edgesG);
    idxB = discretize(B_vec, edgesB);
    
    % veljavni piksli
    valid = ~isnan(idxR) & ~isnan(idxG) & ~isnan(idxB);
    
    % vektor za izhodno sivinsko sliko
    gray_vec = zeros(size(R_vec), 'uint8');
    
    % vrednosti iz histograma v vektor
    gray_vec(valid) = N_norm(sub2ind(size(N_norm), idxR(valid), idxG(valid), idxB(valid)));
    
    % pretvorba v 2d sliko
    gray_img = reshape(gray_vec, height, width);
    
    % zapis v video
    writeVideo(writer, gray_img);
end

close(writer);

%% nov video
video_rgb = VideoReader('ladja.avi');
video_gray = VideoReader('ladja_sivinska_8bit.avi');

figure;
while hasFrame(video_gray) && hasFrame(video_rgb)
    frame_rgb = readFrame(video_rgb);
    frame_gray = readFrame(video_gray);

    subplot(1,2,1); imshow(frame_rgb); title('Originalni video');
    subplot(1,2,2); imshow(frame_gray, []); title('Sivinski video (histogram)');
    
    pause(1/video_rgb.FrameRate);
end
