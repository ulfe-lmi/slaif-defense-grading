A = imread('yosemite_meadows.jpg');
hsv = rgb2hsv(A);
imshow(hsv)
%%
h = hsv(:,:,1);
s = hsv(:,:,2);
v = hsv(:,:,3);

izrisi_sliko(h, 'H')
izrisi_sliko(s, 'S')
izrisi_sliko(v, 'V')

A = imread('yosemite_meadows.jpg');
lab = rgb2lab(A);

l = lab(:,:,1);
a = lab(:,:,2);
b = lab(:,:,3);

izrisi_sliko(l, 'L')
izrisi_sliko(a, 'A')
izrisi_sliko(b, 'B')


function izrisi_sliko(vrednost, naslov)
    figure;
    imagesc(vrednost);
    colormap(gray);
    colorbar;
    axis image;
    title(naslov);
end