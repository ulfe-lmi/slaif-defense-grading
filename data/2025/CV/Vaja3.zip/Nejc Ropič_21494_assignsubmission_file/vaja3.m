video = VideoReader('ladja.avi');
frames = read(video,[1, Inf]); 

frame = 1;
slika = frames(:,:,:,frame);
imshow(slika);          
impixelinfo;
%% RGB
video = VideoReader('ladja.avi');
frames = read(video,[1, Inf]);
[~, ~, ~, num_frames] = size(frames);

minR = 50;
maxR = 105;
minG = 75;
maxG = 115;
minB = 50;     
maxB = 100;

for k = 1:num_frames
    frame = frames(:,:,:,k);
    R = frame(:,:,1);
    G = frame(:,:,2);
    B = frame(:,:,3);

    mask = (R >= minR & R <= maxR & G >= minG & ...
        G <= maxG & B >= minB & B <= maxB);

    imshow(mask);
    colormap(gray);
end
%%
video = VideoReader('ladja.avi');
frames = read(video,[1, Inf]); 

frame = 1;
slika = frames(:,:,:,frame);
hsv = rgb2hsv(slika);
H = hsv(:,:,1);
imshow(H);
colormap(gray);
impixelinfo;

%% HSV
video = VideoReader('ladja.avi');
frames = read(video,[1, Inf]);
[~, ~, ~, num_frames] = size(frames);

minH = 0.3;
maxH = 0.45;
minS = 0.25;
maxS = 0.99;


for k = 1:num_frames
    frame = frames(:,:,:,k);
    hsv = rgb2hsv(frame);
    H = hsv(:,:,1); 

    mask = (H >= minH & H <= maxH) & ...
       (S >= minS & S <= maxS) ;


    imshow(mask);
    colormap(gray);
end
