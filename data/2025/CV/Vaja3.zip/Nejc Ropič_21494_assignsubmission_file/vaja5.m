clc; clear;

video = VideoReader('ladja.avi');
frames = read(video,[1, Inf]); 
[height, width, ~, num_frames] = size(frames);

% okvir za učenje barve morja
frame = 40;
slika = frames(275:end,:,:,frame);

% model histograma morja 4×4×4
[H_model, edgesR, edgesG, edgesB] = izracun_histograma(4, slika(:,:,1), slika(:,:,2), slika(:,:,3));

% model normaliziramo na verjetnostno porazdelitev
H_model = double(H_model);
H_model = H_model / sum(H_model(:));

writer = VideoWriter('ladja_sivinska_4bit.avi');
open(writer);

block = 8;

for f = 1:num_frames
    
    frameRGB = frames(:,:,:,f);
    out = zeros(height, width, 'uint8');

    for i = 1:block:height-block+1
        for j = 1:block:width-block+1

            blok = frameRGB(i:i+block-1, j:j+block-1, :);

            % histogram bloka
            [H_block, ~, ~, ~] = izracun_histograma(4, blok(:,:,1), blok(:,:,2), blok(:,:,3));
            H_block = double(H_block);
            
            if sum(H_block(:)) == 0
                s = 0;
            else
                % normalizacija
                s = sum(min(H_model(:), H_block(:)));
            end
            
            % preslikava na [0,255]
            s_norm = uint8(round(255 * s));


            % zapis enake vrednosti za cel blok
            out(i:i+block-1, j:j+block-1) = s_norm;
        end
    end

    writeVideo(writer, out);
end

close(writer);

%% nov video
video_rgb = VideoReader('ladja.avi');
video_gray = VideoReader('ladja_sivinska_4bit.avi');

figure;
while hasFrame(video_gray) && hasFrame(video_rgb)
    frame_rgb = readFrame(video_rgb);
    frame_gray = readFrame(video_gray);

    subplot(1,2,1); imshow(frame_rgb); title('Originalni video');
    subplot(1,2,2); imshow(frame_gray, []); title('Sivinski video (histogram)');
    
    pause(1/video_rgb.FrameRate);
end
