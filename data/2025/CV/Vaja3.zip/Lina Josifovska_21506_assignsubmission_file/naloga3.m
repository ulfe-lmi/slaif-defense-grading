vidObj = VideoReader('ladja.avi');  
nFrames = vidObj.NumFrames;         
frameExample = read(vidObj,1);      
imshow(frameExample);               
title('Select a ROI that contains the sea');

h = imrect;             
position = round(wait(h)); 
x1 = position(1); y1 = position(2);
w = position(3); hgt = position(4);
roi = frameExample(y1:y1+hgt, x1:x1+w, :);  

roi = im2double(roi);  
R = roi(:,:,1);
G = roi(:,:,2);
B = roi(:,:,3);

Rmin = min(R(:)); Rmax = max(R(:));
Gmin = min(G(:)); Gmax = max(G(:));
Bmin = min(B(:)); Bmax = max(B(:));

fprintf('R range: %.2f - %.2f\n', Rmin, Rmax);
fprintf('G range: %.2f - %.2f\n', Gmin, Gmax);
fprintf('B range: %.2f - %.2f\n', Bmin, Bmax);


outputRGB = VideoWriter('morje_RGB.avi'); 
outputRGB.FrameRate = vidObj.FrameRate;
open(outputRGB);

for k = 1:nFrames
    frame = im2double(read(vidObj,k));
    
    mask = frame(:,:,1) >= Rmin & frame(:,:,1) <= Rmax & ...
           frame(:,:,2) >= Gmin & frame(:,:,2) <= Gmax & ...
           frame(:,:,3) >= Bmin & frame(:,:,3) <= Bmax;
    
    maskRGB = repmat(uint8(mask*255), [1 1 3]);
    
    writeVideo(outputRGB, maskRGB);
end
close(outputRGB);
disp('RGB segmentation finished!');


hsvROI = rgb2hsv(roi);
Hmin = min(hsvROI(:,:,1),[],'all'); Hmax = max(hsvROI(:,:,1),[],'all');
Smin = min(hsvROI(:,:,2),[],'all'); Smax = max(hsvROI(:,:,2),[],'all');

outputHSV = VideoWriter('morje_HSV.avi'); 
outputHSV.FrameRate = vidObj.FrameRate;
open(outputHSV);

for k = 1:nFrames
    frame = im2double(read(vidObj,k));
    hsvFrame = rgb2hsv(frame);
    
    mask = hsvFrame(:,:,1) >= Hmin & hsvFrame(:,:,1) <= Hmax & ...
           hsvFrame(:,:,2) >= Smin & hsvFrame(:,:,2) <= Smax;
       
    maskHSV = repmat(uint8(mask*255), [1 1 3]);
    writeVideo(outputHSV, maskHSV);
end
close(outputHSV);
disp('Konec');
