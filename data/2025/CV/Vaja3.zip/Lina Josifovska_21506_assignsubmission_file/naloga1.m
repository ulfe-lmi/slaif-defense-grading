coloured_pencils = imread('coloured_pencils.jpg');
yosemite_meadows = imread('yosemite_meadows.jpg');

coloured_pencils_HSV = rgb2hsv(coloured_pencils);
yosemite_meadows_HSV = rgb2hsv(yosemite_meadows);

figure; imshow(coloured_pencils); title('Original - Pencils');
figure; imshow(yosemite_meadows); title('Original - Yosemite');

figure; imagesc(coloured_pencils_HSV(:,:,1)); title('Pencils - H (Hue)'), colorbar; colormap(gray);
figure; imagesc(coloured_pencils_HSV(:,:,2)); title('Pencils - S (Saturation)'), colorbar; colormap(gray);
figure; imagesc(coloured_pencils_HSV(:,:,3)); title('Pencils - V (Value)'), colorbar; colormap(gray);
%%
figure; imagesc(yosemite_meadows_HSV(:,:,1)); title('Yosemite - H'), colorbar; colormap(gray);
figure; imagesc(yosemite_meadows_HSV(:,:,2)); title('Yosemite - S'), colorbar; colormap(gray);
figure; imagesc(yosemite_meadows_HSV(:,:,3)); title('Yosemite - V'), colorbar; colormap(gray);

coloured_pencils_LAB = rgb2lab(coloured_pencils);
yosemite_meadows_LAB = rgb2lab(yosemite_meadows);

figure; imagesc(coloured_pencils_LAB(:,:,1)); title('Pencils - L'), colorbar; colormap(gray);
figure; imagesc(coloured_pencils_LAB(:,:,2)); title('Pencils - a'), colorbar; colormap(gray);
figure; imagesc(coloured_pencils_LAB(:,:,3)); title('Pencils - b'), colorbar; colormap(gray);

figure; imagesc(yosemite_meadows_LAB(:,:,1)); title('Yosemite - L'), colorbar; colormap(gray);
figure; imagesc(yosemite_meadows_LAB(:,:,2)); title('Yosemite - a'), colorbar; colormap(gray);
figure; imagesc(yosemite_meadows_LAB(:,:,3)); title('Yosemite - b'), colorbar; colormap(gray);
