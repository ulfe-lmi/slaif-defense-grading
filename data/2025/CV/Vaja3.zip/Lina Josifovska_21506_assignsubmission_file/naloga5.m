close all; clc;

vidObj = VideoReader('ladja.avi');
nFrames = vidObj.NumFrames;

frame1 = im2double(read(vidObj,1));
imshow(frame1); title('Izberi ROI za morje'); 
h = drawrectangle('Color','r'); 
disp('Ko končaš z izbiro, pritisni Enter v Command Window'); pause;
position = round(h.Position);
roi = frame1(position(2):position(2)+position(4), position(1):position(1)+position(3), :);
delete(h);

nBins = 4;
edges = linspace(0,1,nBins+1);
R_roi = roi(:,:,1); G_roi = roi(:,:,2); B_roi = roi(:,:,3);
histROI = zeros(nBins,nBins,nBins);

for i = 1:numel(R_roi)
    rBin = find(R_roi(i) >= edges,1,'last'); rBin = min(rBin,nBins);
    gBin = find(G_roi(i) >= edges,1,'last'); gBin = min(gBin,nBins);
    bBin = find(B_roi(i) >= edges,1,'last'); bBin = min(bBin,nBins);
    histROI(rBin,gBin,bBin) = histROI(rBin,gBin,bBin) + 1;
end

histROI = histROI / sum(histROI(:)); 

blockSize = 8; 
outputHist = VideoWriter('morje_hist_intersection.avi');
open(outputHist);

for k = 1:nFrames
    frame = im2double(read(vidObj,k));
    [rows, cols, ~] = size(frame);
    
    grayFrame = zeros(rows,cols);
    
    for i = 1:blockSize:rows-blockSize+1
        for j = 1:blockSize:cols-blockSize+1
            block = frame(i:i+blockSize-1, j:j+blockSize-1, :);
            
            Rb = block(:,:,1); Gb = block(:,:,2); Bb = block(:,:,3);
            histBlock = zeros(nBins,nBins,nBins);
            
            for p = 1:numel(Rb)
                rBin = find(Rb(p) >= edges,1,'last'); rBin = min(rBin,nBins);
                gBin = find(Gb(p) >= edges,1,'last'); gBin = min(gBin,nBins);
                bBin = find(Bb(p) >= edges,1,'last'); bBin = min(bBin,nBins);
                histBlock(rBin,gBin,bBin) = histBlock(rBin,gBin,bBin) + 1;
            end
            
            histBlock = histBlock / sum(histBlock(:)); 
            
            intersection = sum(min(histROI(:), histBlock(:))); 
            intensity = uint8(intersection * 256); 
            
            grayFrame(i:i+blockSize-1, j:j+blockSize-1) = intensity;
        end
    end
    
    writeVideo(outputHist, uint8(grayFrame));
end

close(outputHist);
disp('Segmentacija po histogram intersection končana, shranjeno kot morje_hist_intersection.avi');
