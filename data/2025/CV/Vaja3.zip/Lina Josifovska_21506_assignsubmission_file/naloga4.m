close all; clc;

vidObj = VideoReader('ladja.avi');
frame1 = im2double(read(vidObj,1));
imshow(frame1); 
title('Izberi ROI za morje');

h = drawrectangle('Color','r');  

disp('Ko končaš z izbiro, pritisni Enter v Command Window');
pause;  

position = round(h.Position); 

roi = frame1(position(2):position(2)+position(4), ...
             position(1):position(1)+position(3), :);

figure; imshow(roi); title('Izbrano območje morja');


nBins = 8; 

R_roi = roi(:,:,1); G_roi = roi(:,:,2); B_roi = roi(:,:,3);

edges = linspace(0,1,nBins+1);

hist3D = zeros(nBins,nBins,nBins);

for i = 1:numel(R_roi)
    rBin = find(R_roi(i) >= edges,1,'last'); rBin = min(rBin,nBins);
    gBin = find(G_roi(i) >= edges,1,'last'); gBin = min(gBin,nBins);
    bBin = find(B_roi(i) >= edges,1,'last'); bBin = min(bBin,nBins);
    hist3D(rBin,gBin,bBin) = hist3D(rBin,gBin,bBin) + 1;
end

hist3D = hist3D / max(hist3D(:)) * 255;

outputHist = VideoWriter('morje_histogram.avi');
open(outputHist);

for k = 1:nFrames
    frame = im2double(read(vidObj,k));
    [rows, cols, ~] = size(frame);
    grayFrame = zeros(rows,cols);
    
    Rf = frame(:,:,1); Gf = frame(:,:,2); Bf = frame(:,:,3);
    
    for i = 1:rows
        for j = 1:cols
            rBin = find(Rf(i,j) >= edges,1,'last'); rBin = min(rBin,nBins);
            gBin = find(Gf(i,j) >= edges,1,'last'); gBin = min(gBin,nBins);
            bBin = find(Bf(i,j) >= edges,1,'last'); bBin = min(bBin,nBins);
            
            grayFrame(i,j) = hist3D(rBin,gBin,bBin); 
        end
    end
    
    grayFrame_uint8 = uint8(grayFrame);
    
    writeVideo(outputHist, grayFrame_uint8);
end

close(outputHist);
disp('Histogram segmentacija končana in shranjena kot morje_histogram.avi');
