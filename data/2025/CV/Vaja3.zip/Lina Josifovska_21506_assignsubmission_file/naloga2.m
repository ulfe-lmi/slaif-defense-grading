coloured_pencils2=imread('coloured_pencils.jpg');

%HSV

coloured_pencils2_HSV=rgb2hsv(coloured_pencils2);
coloured_pencils_HSV_H=coloured_pencils2_HSV;
coloured_pencils_HSV_S=coloured_pencils2_HSV;
coloured_pencils_HSV_V=coloured_pencils2_HSV;

spremeni_H=coloured_pencils2_HSV(:,:,1);
spremeni_S=coloured_pencils2_HSV(:,:,2);
spremeni_V=coloured_pencils2_HSV(:,:,3);

spremeni_H(:,:)=0.5;
spremeni_S(:,:)=0.5;
spremeni_V(:,:)=0.5;

coloured_pencils_HSV_H(:,:,1)=spremeni_H;
coloured_pencils_HSV_S(:,:,2)=spremeni_S;
coloured_pencils_HSV_V(:,:,3)=spremeni_V;

coloured_pencils_H_RGB=hsv2rgb(coloured_pencils_HSV_H);
coloured_pencils_S_RGB=hsv2rgb(coloured_pencils_HSV_S);
coloured_pencils_V_RGB=hsv2rgb(coloured_pencils_HSV_V);
figure; imshow(coloured_pencils_H_RGB);
title('H Fixed');
figure; imshow(coloured_pencils_S_RGB);
title('S Fixed');
figure; imshow(coloured_pencils_V_RGB);
title('V Fixed');

%%
%LAB
coloured_pencils2=imread('coloured_pencils.jpg');
coloured_pencils2_LAB=rgb2lab(coloured_pencils2);
coloured_pencils_LAB_L=coloured_pencils_LAB;
coloured_pencils_LAB_A=coloured_pencils_LAB;
coloured_pencils_LAB_B=coloured_pencils_LAB;

spremeni_L=coloured_pencils2_LAB(:,:,1);
spremeni_A=coloured_pencils2_LAB(:,:,2);
spremeni_B=coloured_pencils2_LAB(:,:,3);

spremeni_L(:,:)=50;
spremeni_A(:,:)=0;
spremeni_B(:,:)=0;

coloured_pencils_LAB_L(:,:,1)=spremeni_L;
coloured_pencils_LAB_A(:,:,2)=spremeni_A;
coloured_pencils_LAB_B(:,:,3)=spremeni_B;

coloured_pencils_L_RGB=lab2rgb(coloured_pencils_LAB_L);
coloured_pencils_A_RGB=lab2rgb(coloured_pencils_LAB_A);
coloured_pencils_B_RGB=lab2rgb(coloured_pencils_LAB_B);
figure; imshow(coloured_pencils_L_RGB)
title('L fixed');
figure; imshow(coloured_pencils_A_RGB)
title('a fixed');
figure; imshow(coloured_pencils_B_RGB)
title('b fixed');