% Naloga 1 Koncept barv in barvni prostori RGB, HSV ter Lab
% Jakob Suhadolc & Mihaela Temelkova

slike = { 'yosemite_meadows.jpg', ...
          'coloured_pencils.jpg' };

%PRETVORBA V HSV PROSTORU
for i = 1:numel(slike)
    
    % Preberi RGB sliko
    I = imread(slike{i});
    I_d = im2double(I); %vrednosti pikslov preslika iz [0,255] v [0,1]

    %Pretvori RGB sliko v HSV in dobimo tri kanale slike
    I_hsv = rgb2hsv(I_d);
    H = I_hsv(:,:,1);
    S = I_hsv(:,:,2);
    V = I_hsv(:,:,3);

    figure('Name',['HSV - ' slike{i}]);

    subplot(2,2,1);
    imshow(I);
    title(['Original: ' slike{i}], 'Interpreter','none');

    subplot(2,2,2);
    imagesc(H);
    axis image off;
    title('H komponenta');
    colormap(gray); colorbar;

    subplot(2,2,3);
    imagesc(S);
    axis image off;
    title('S komponenta');
    colormap(gray); colorbar;

    subplot(2,2,4);
    imagesc(V);
    axis image off;
    title('V komponenta');
    colormap(gray); colorbar;

% PRETVORBA V Lab PROSTORU
    I_lab = rgb2lab(I_d);
    L = I_lab(:,:,1);   
    a = I_lab(:,:,2);   
    b = I_lab(:,:,3);  

    figure('Name',['Lab - ' slike{i}]);

    subplot(2,2,1);
    imshow(I);
    title(['Original: ' slike{i}], 'Interpreter','none');

    subplot(2,2,2);
    imagesc(L, [0 100]);
    axis image off;
    title('L komponenta');
    colormap(gray); colorbar;

    subplot(2,2,3);
    imagesc(a, [-128 127]);
    axis image off;
    title('a komponenta');
    colormap(gray); colorbar;

    subplot(2,2,4);
    imagesc(b, [-128 127]);
    axis image off;
    title('b komponenta');
    colormap(gray); colorbar;

end

%% Naloga 2 Vpliv posameznih komponent na rekonstruirano RGB sliko
close all; clear; clc;

slike = {'yosemite_meadows.jpg', 'coloured_pencils.jpg' };

% Izkloplenje HSV komponent
for i = 1:numel(slike)

    I = im2double(imread(slike{i}));
    HSV = rgb2hsv(I);
    % Ena komponenta je konstanta, z namenom da jo izklopimo in vidimo
    % njeneno delovanje 
    H = HSV;
    H(:,:,1) = 0.5;
    S = HSV;
    S(:,:,2) = 0.5;
    V = HSV;
    V(:,:,3) = 0.5;

    I_H = hsv2rgb(H);
    I_S = hsv2rgb(S);
    I_V = hsv2rgb(V);

    figure('Name', slike{i});
    subplot(2,2,1); imshow(I); title('Original');
    subplot(2,2,2); imshow(I_H); title('H = 0.5');
    subplot(2,2,3); imshow(I_S); title('S = 0.5');
    subplot(2,2,4); imshow(I_V); title('V = 0.5');
end

%% Naloga 2
close all; clear; clc;

slike = {'yosemite_meadows.jpg', 'coloured_pencils.jpg' };

%Izkloplenje Lab komponent

for i = 1:numel(slike)
    I = im2double(imread(slike{i}));
    Lab = rgb2lab(I);

    L = Lab;
    L(:,:,1) = 50; % Od 0 do 100
    a = Lab;
    a(:,:,2) = 0;  %Od -127 do 128
    b = Lab;
    b(:,:,3) = 0; %Od -127 do 128

    I_L = lab2rgb(L);
    I_a = lab2rgb(a);
    I_b = lab2rgb(b);

    figure('Name', slike{i});
    subplot(2,2,1); imshow(I); title('Original');
    subplot(2,2,2); imshow(I_L); title('L = 50');
    subplot(2,2,3); imshow(I_a); title('a = 0');
    subplot(2,2,4); imshow(I_b); title('b = 0');
end





