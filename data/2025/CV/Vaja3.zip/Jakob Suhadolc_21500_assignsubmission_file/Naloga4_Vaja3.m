%% Naloga 4
close all; clear; clc;

% Preberemo prvi frame videa
v = VideoReader('ladja.avi');
frame = readFrame(v);
framed = im2double(frame);

% Kliknemo točko na morju
figure; imshow(framed); title('Klikni na morje');
[x, y] = ginput(1);
x = round(x); y = round(y);
close;

% Izrežemo patch okoli klika (morje)
r = 50;
[H_img, W_img, ~] = size(framed);
x1 = max(1, x-r); x2 = min(W_img, x+r);
y1 = max(1, y-r); y2 = min(H_img, y+r);

% učenje barv morja
patch = framed(y1:y2, x1:x2, :);  

% Razdelimo vsak kanal R,G,B na 8 delov ali 8x8x8
bins = 8;
%Definiramo robove bina oziroma bin 1 je na intervalu [0,0.125], bin 2 na [0.125,0.25]
edges = linspace(0,1,bins+1);
% Dolocimo 8x8x8 matrika H oziroma histograma ki ima 0
H = zeros(bins,bins,bins);

% 3D RGB histogram patcha
R = patch(:,:,1); G = patch(:,:,2); B = patch(:,:,3);
% Pove v katerem binu se nahaja piksel iz patcha glede na edges
ri = discretize(R,edges);
gi = discretize(G,edges);
bi = discretize(B,edges);

%Steje piksle, koliko pikslov se pojavijo v posamezen bin
sz = size(patch,1)*size(patch,2);
for i=1:sz
    H(ri(i), gi(i), bi(i)) = H(ri(i), gi(i), bi(i)) + 1;
end

% Normalizacija histograma na [0,255]
H = H / max(H(:));
H = H * 255;

% Gremo čez cel video in vsako točko preslikamo skozi histogram
v = VideoReader('ladja.avi');
writer = VideoWriter('ladja_Naloga4.avi');  
open(writer);

while hasFrame(v)
    f = im2double(readFrame(v));
    R = f(:,:,1); G = f(:,:,2); B = f(:,:,3);

    ri = discretize(R,edges);
    gi = discretize(G,edges);
    bi = discretize(B,edges);

    M = zeros(size(R));          % izhodna sivinska slika
    for i=1:numel(R)
        M(i) = H(ri(i), gi(i), bi(i));   % vrednost iz histograma
    end

    M = uint8(M);
    writeVideo(writer, M);       % zapišemo frame
end

close(writer);
