%% Naloga 3 – segmentacija morja v RGB in HSV
close all; clear; clc;

% Preberemo prvi frame iz videa
v = VideoReader('ladja.avi');
frame = readFrame(v);
framed = im2double(frame); 

% Uporabnik klikne točko na morju (za določitev patcha)
figure; imshow(framed); title('Klikni na morje');
[x, y] = ginput(1);
x = round(x); y = round(y);
close;

% Izrežemo manjšo zaplato (patch) okoli klika
r = 50;
[H_img, W_img, ~] = size(framed);
x1 = max(1, x-r); x2 = min(W_img, x+r);
y1 = max(1, y-r); y2 = min(H_img, y+r);

%% RGB segmentacija 

% Patch nad morjem v RGB, ki ga naredimo iz okolice tocke ki smo jo
% kliknili
patchRGB = framed(y1:y2, x1:x2, :);

% Povprečne RGB vrednosti patcha (tipična barva morja)
mRGB = squeeze(mean(mean(patchRGB,1),2));

% Dovoljen odmik okoli povprečij 
dR = 0.10; dG = 0.10; dB = 0.10;

% Intervali za R, G, B in definicija barve morja
Rmin = max(0, mRGB(1)-dR); Rmax = min(1, mRGB(1)+dR);
Gmin = max(0, mRGB(2)-dG); Gmax = min(1, mRGB(2)+dG);
Bmin = max(0, mRGB(3)-dB); Bmax = min(1, mRGB(3)+dB);

% Ponovno odpremo video in pripravimo izhodni RGB video
v = VideoReader('ladja.avi');
outRGB = VideoWriter('ladja_morje_RGB.avi');
outRGB.FrameRate = v.FrameRate;
open(outRGB);

% Za vsak frame preverimo, kateri piksli so znotraj RGB intervalov
while hasFrame(v)
    frm = im2double(readFrame(v));
    R = frm(:,:,1); G = frm(:,:,2); B = frm(:,:,3);

    % Maska: 1 - barva podobna morju, 0 - ni 
    mask = (R>=Rmin & R<=Rmax) & ...
           (G>=Gmin & G<=Gmax) & ...
           (B>=Bmin & B<=Bmax);

    % Pretvorba maske v binarno (0/255) in v 3-kanalno sliko za video
    BW = uint8(mask)*255;
    BW_rgb = cat(3,BW,BW,BW);
    writeVideo(outRGB, BW_rgb);
end

close(outRGB);

%%  HSV segmentacija

% Patch nad morjem pretvorimo v HSV
patchHSV = rgb2hsv(patchRGB);

% Povprečne HSV vrednosti patcha
mHSV = squeeze(mean(mean(patchHSV,1),2));

% Dovoljen odmik za H in S (V ignoriramo)
dH = 0.10; dS = 0.25;        

% Intervali za H in S in definicija barve morja v HSV
Hmin = max(0, mHSV(1)-dH); Hmax = min(1, mHSV(1)+dH);
Smin = max(0, mHSV(2)-dS); Smax = min(1, mHSV(2)+dS);

% Ponovno odpremo video in pripravimo izhodni binarni video (HSV prag)
v = VideoReader('ladja.avi');
outHSV = VideoWriter('ladja_morje_HSV.avi');
outHSV.FrameRate = v.FrameRate;
open(outHSV);

% Za vsak frame naredimo vpragovljenje v HSV prostoru
while hasFrame(v)
    frm = im2double(readFrame(v));
    hsv = rgb2hsv(frm);
    Hc = hsv(:,:,1); Sc = hsv(:,:,2);

    % Maska: 1 - piksel ima H,S podobna morju
    mask = (Hc>=Hmin & Hc<=Hmax) & ...
           (Sc>=Smin & Sc<=Smax);  

    % Pretvorimo masko v binarno sliko in zapišemo v video
    BW = uint8(mask)*255;
    BW_rgb = cat(3,BW,BW,BW);
    writeVideo(outHSV, BW_rgb);
end

close(outHSV);
