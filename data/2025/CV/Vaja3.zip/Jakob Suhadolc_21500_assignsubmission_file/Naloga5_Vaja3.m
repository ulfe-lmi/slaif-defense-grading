%% Naloga 5 - Segmentacija z uporabo histogram intersection

close all; clear; clc;

% Preberemo prvi frame iz videa
v = VideoReader('ladja.avi');
frame = readFrame(v);
framed = im2double(frame);

%Izbere pravokotnik nad morjem (nas patch)
figure; imshow(framed);
title('Selektiraj pravokotnik cez morja');
patch_rect = round(getrect); % [x, y, width, height]

% Koordinate pravokotnika
px = patch_rect(1);  
py = patch_rect(2);
pw = patch_rect(3);  
ph = patch_rect(4);

% Izrežemo patch morja iz slike
patch = framed(py:py+ph, px:px+pw, :);

% Razdelimo R,G,B kanale na 4 delov, kar bo nas referencni histogram
bins = 4;                                   
edges = linspace(0,1,bins+1); 
% prazen 3D histogram 4x4x4
H_ref = zeros(bins,bins,bins);           

% Kanali patcha (morje)
R = patch(:,:,1); G = patch(:,:,2); B = patch(:,:,3);

% Za vsak piksel določimo, v kateri bin
ri = discretize(R, edges);
gi = discretize(G, edges);
bi = discretize(B, edges);

% Polnimo 3D histogram: štejemo, kolikokrat se pojavi kombinacija (ri,gi,bi)
for i = 1:numel(R)
    H_ref(ri(i), gi(i), bi(i)) = H_ref(ri(i), gi(i), bi(i)) + 1;
end

% Normaliziramo referenčni histogram
H_ref = H_ref / sum(H_ref(:));

% Priprava videa
v = VideoReader('ladja.avi');
writer = VideoWriter('ladja_morje_Naloga5.avi');
open(writer);

block = 8;   % velikost bloka: 8×8 pikslov

% Gremo čez vse frame-e videa
while hasFrame(v)
    frame = im2double(readFrame(v));
    [h, w, ~] = size(frame);

    % izhodna sivinska mapa podobnosti z morjem
    M = zeros(h, w);  

    % Premikamo se po sliki v korakih 8 px po y in x
    for y = 1:block:(h - mod(h,block))
        for x = 1:block:(w - mod(w,block))

            % Izrežemo trenutni blok velikosti 8x8
            blk = frame(y:y+block-1, x:x+block-1, :);

            %Izračun histograma za ta blok (Hb) 
            Hb = zeros(bins,bins,bins);    

            Rb = blk(:,:,1);
            Gb = blk(:,:,2);
            Bb = blk(:,:,3);

            % Določimo indekse binov za kanal R,G,B v bloku
            rbi = discretize(Rb, edges);
            gbi = discretize(Gb, edges);
            bbi = discretize(Bb, edges);

            % Polnimo histogram bloka: štejemo pojavitve kombinacij (rbi,gbi,bbi)
            for i = 1:numel(Rb)
                Hb(rbi(i), gbi(i), bbi(i)) = Hb(rbi(i), gbi(i), bbi(i)) + 1;
            end

            % Normaliziramo histogram bloka, če ni prazen (vsota = 1)
            if sum(Hb(:)) > 0
                Hb = Hb / sum(Hb(:));
            end

            % Histogram intersection (Swain & Ballard)
             % HI meri podobnost med histogramom morja (H_ref) in histogramom trenutnega bloka (Hb)
            HI = sum( min(H_ref(:), Hb(:)) );

            % Preslikamo HI v interval 0–255 za sivinsko sliko
            HI_val = uint8(HI * 256);

            % Celoten blok dobi isto sivinsko vrednost (HI_val)
            % Svetel blok - barve podobne morju, temen blok - drugačne barve
            M(y:y+block-1, x:x+block-1) = HI_val;
        end
    end

    % Zapišemo sivinski frame v video
    writeVideo(writer, uint8(M));
end

close(writer);

disp('konec');
