%% Prva naloga:
claear all;
img = imread('slika.jpg');   % preberi sliko
hsv_img = rgb2hsv(img);      % pretvori v HSV

