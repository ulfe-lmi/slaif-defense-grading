function konstantne_komponente(datoteka)
% vhod datoteke mora biti v obliki 'slika.jpg'
% funkcija vrne 6 rgb slik - v primeru konstantne vsake izmed komponent HSV in Lab

I_int = imread(datoteka);
I_double = im2double(I_int);

% HSV prostor

I_hsv = rgb2hsv(I_double);  % pretvorimo v HSV prostor

I_hsv_H = I_hsv;
I_hsv_H(:,:,1) = 0.5;  % H je konstanten, torej imajo vsi piksli isti odtenek barve

I_hsv_S = I_hsv; 
I_hsv_S(:,:,2) = 0.5;  % S kje konstanten, torej so vse barve enako žive

I_hsv_V = I_hsv; 
I_hsv_V(:,:,3) = 0.5;  % V je konstanten, torej so vsi piksli enako svetli


I_rgb_H = hsv2rgb(I_hsv_H);  % pretvorimo nazaj v RGB prostorž
figure;
imshow(I_rgb_H);
title('HSV: konstanten H');

I_rgb_S = hsv2rgb(I_hsv_S);
figure;
imshow(I_rgb_S);
title('HSV: konstanten S');

I_rgb_V = hsv2rgb(I_hsv_V);
figure;
imshow(I_rgb_V);
title('HSV: konstanten V');

% Lab prostor

I_lab = rgb2lab(I_double);

I_lab_L = I_lab;
I_lab_L(:,:,1) = 50;  % L je konstanten, torej 

I_lab_a = I_lab; 
I_lab_a(:,:,2) = 0;  % a kje konstanten, torej 

I_lab_b = I_lab; 
I_lab_b(:,:,3) = 0;  % b je konstanten, torej


I_rgb_L = lab2rgb(I_lab_L);  % pretvorimo nazaj v RGB prostor
figure;
imshow(I_rgb_L);
title('Lab: konstanten L');

I_rgb_a = lab2rgb(I_lab_a);
figure;
imshow(I_rgb_a);
title('Lab: konstanten a');

I_rgb_b = lab2rgb(I_lab_b);
figure;
imshow(I_rgb_b);
title('Lab: konstanten b');

end