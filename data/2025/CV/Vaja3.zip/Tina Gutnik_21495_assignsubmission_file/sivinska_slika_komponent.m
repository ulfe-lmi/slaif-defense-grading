function sivinska_slika_komponent(datoteka)
% vhod datoteke mora biti v obliki 'slika.jpg'
% funkcija vrne 6 sivinskih slik - vsako izmed HSV in Lab komponent


I_int = imread(datoteka);
I_double = im2double(I_int);

% HSV prostor

I_hsv = rgb2hsv(I_double);   % pretvorimo v HSV prostor

H = I_hsv(:,:,1); 
S = I_hsv(:,:,2); 
V = I_hsv(:,:,3);

figure;                  
imagesc(H);
colormap(gray);
title('HSV: H');

figure;                  
imagesc(S);
colormap(gray);
title('HSV: S');

figure;                  
imagesc(V);
colormap(gray);
title('HSV: V');

% Lab prostor

I_lab = rgb2lab(I_double);

L = I_lab(:,:,1); 
a = I_lab(:,:,2);   
b = I_lab(:,:,3);  

figure;                  
imagesc(L);
colormap(gray);
title('Lab: L');

figure;                  
imagesc(a);
colormap(gray);
title('Lab: a');

figure;                  
imagesc(b);
colormap(gray);
title('Lab: b');

end