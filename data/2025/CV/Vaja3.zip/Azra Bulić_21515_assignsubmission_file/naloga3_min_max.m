%Jedan frame iz videa
vid = VideoReader('ladja.avi');
frame = read(vid, 50);

figure; imshow(frame);
title('Klikni 15 tocaka na moru');

[x, y] = ginput(15);

%Očitane RGB vrijednosti
vals = zeros(length(x), 3);

%Očitan RGB za svaku točku
for i = 1:length(x)
    xi = round(x(i));
    yi = round(y(i));
    vals(i, :) = frame(yi, xi, :);
end

%min i max
Rmin = min(vals(:,1));
Rmax = max(vals(:,1));
Gmin = min(vals(:,2));
Gmax = max(vals(:,2));
Bmin = min(vals(:,3));
Bmax = max(vals(:,3));

%Rezultati
fprintf('Rmin = %d , Rmax = %d\n', Rmin, Rmax);
fprintf('Gmin = %d , Gmax = %d\n', Gmin, Gmax);
fprintf('Bmin = %d , Bmax = %d\n', Bmin, Bmax);