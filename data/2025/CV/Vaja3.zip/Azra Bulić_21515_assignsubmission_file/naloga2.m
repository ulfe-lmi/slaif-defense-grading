%HSV

%yosemite_meadows
rgb1 = im2double(imread('yosemite_meadows.jpg'));
hsv1 = rgb2hsv(rgb1);

h1 = hsv1(:,:,1);
s1 = hsv1(:,:,2);
v1 = hsv1(:,:,3);

% H konstantan
hsv1_Hconst = hsv1;
hsv1_Hconst(:,:,1) = 0.5;

% S konstantan
hsv1_Sconst = hsv1;
hsv1_Sconst(:,:,2) = 0.5;

% V konstantan
hsv1_Vconst = hsv1;
hsv1_Vconst(:,:,3) = 0.5;

figure;
subplot(2,2,1); 
imshow(rgb1);
title('Yosemite');

subplot(2,2,2); 
imshow(hsv2rgb(hsv1_Hconst)); 
title('H=const');

subplot(2,2,3); 
imshow(hsv2rgb(hsv1_Sconst)); 
title('S=const');

subplot(2,2,4); 
imshow(hsv2rgb(hsv1_Vconst)); 
title('V=const');


%coloured_pencils
rgb2 = im2double(imread('coloured_pencils.jpg'));
hsv2 = rgb2hsv(rgb2);

h2 = hsv2(:,:,1);
s2 = hsv2(:,:,2);
v2 = hsv2(:,:,3);

%H konstantan
hsv2_Hconst = hsv2;
hsv2_Hconst(:,:,1) = 0.5;

%S konstantan
hsv2_Sconst = hsv2;
hsv2_Sconst(:,:,2) = 0.5;

%V konstantan
hsv2_Vconst = hsv2;
hsv2_Vconst(:,:,3) = 0.5;

figure;
subplot(2,2,1); imshow(rgb2);
title('Pencils');

subplot(2,2,2); 
imshow(hsv2rgb(hsv2_Hconst)); 
title('H=const');

subplot(2,2,3); 
imshow(hsv2rgb(hsv2_Sconst)); 
title('S=const');

subplot(2,2,4); 
imshow(hsv2rgb(hsv2_Vconst)); 
title('V=const');

%Lab
%yosemite_meadows
lab1 = rgb2lab(rgb1);

L1 = lab1(:,:,1);
A1 = lab1(:,:,2);
B1 = lab1(:,:,3);

%L konstantan
lab1_Lconst = lab1;
lab1_Lconst(:,:,1) = 50;

%a konstantan
lab1_Aconst = lab1;
lab1_Aconst(:,:,2) = 0;

%b konstanatn
lab1_Bconst = lab1;
lab1_Bconst(:,:,3) = 0;

figure;
subplot(2,2,1); 
imshow(rgb1);
title('Yosemite');

subplot(2,2,2); 
imshow(lab2rgb(lab1_Lconst)); 
title('L=const');

subplot(2,2,3); 
imshow(lab2rgb(lab1_Aconst)); 
title('a=const');

subplot(2,2,4); 
imshow(lab2rgb(lab1_Bconst)); 
title('b=const');

%coloured_pencils
lab2 = rgb2lab(rgb2);

L2 = lab2(:,:,1);
A2 = lab2(:,:,2);
B2 = lab2(:,:,3);

%L konstanatn
lab2_Lconst = lab2;
lab2_Lconst(:,:,1) = 50;

%a konstanatn
lab2_Aconst = lab2;
lab2_Aconst(:,:,2) = 0;

%b konstantan
lab2_Bconst = lab2;
lab2_Bconst(:,:,3) = 0;

figure;
subplot(2,2,1); 
imshow(rgb2);
title('Pencils');

subplot(2,2,2); 
imshow(lab2rgb(lab2_Lconst)); 
title('L=const');

subplot(2,2,3); 
imshow(lab2rgb(lab2_Aconst)); 
title('a=const');

subplot(2,2,4); 
imshow(lab2rgb(lab2_Bconst)); 
title('b=const');

