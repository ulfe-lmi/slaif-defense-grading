clc; clear; close all;

%yosemite_meadows
rgb1 = im2double(imread('yosemite_meadows.jpg'));

% HSV
hsv1 = rgb2hsv(rgb1);
H1 = hsv1(:,:,1);
S1 = hsv1(:,:,2);
V1 = hsv1(:,:,3);

figure;
subplot(2,3,1); 
imshow(rgb1); 
title('RGB - Yosemite');

subplot(2,3,2); 
imagesc(H1); 
colormap gray;
axis image; 
title('H');

subplot(2,3,3); 
imagesc(S1); 
colormap gray; 
axis image; 
title('S');

subplot(2,3,4); 
imagesc(V1); 
colormap gray; 
axis image; 
title('V');

% Lab
lab1 = rgb2lab(rgb1);
L1 = lab1(:,:,1);
a1 = lab1(:,:,2);
b1 = lab1(:,:,3);

figure;
subplot(2,3,1); 
imshow(rgb1); 
title('RGB - Yosemite');

subplot(2,3,2); 
imagesc(L1); 
colormap gray; 
axis image; 
title('L');

subplot(2,3,3); 
imagesc(a1); 
colormap gray; 
axis image; 
title('a');

subplot(2,3,4); 
imagesc(b1); 
colormap gray; 
axis image; 
title('b');

%coloured_pencils
rgb2 = im2double(imread('coloured_pencils.jpg'));

% HSV
hsv2 = rgb2hsv(rgb2);
H2 = hsv2(:,:,1);
S2 = hsv2(:,:,2);
V2 = hsv2(:,:,3);

figure;
subplot(2,3,1); 
imshow(rgb2); 
title('RGB - Pencils');

subplot(2,3,2); 
imagesc(H2); 
colormap gray; 
axis image; 
title('H');

subplot(2,3,3); 
imagesc(S2); 
colormap gray; 
axis image; 
title('S');

subplot(2,3,4); 
imagesc(V2); 
colormap gray; 
axis image; 
title('V');

% Lab
lab2 = rgb2lab(rgb2);
L2 = lab2(:,:,1);
a2 = lab2(:,:,2);
b2 = lab2(:,:,3);

figure;
subplot(2,3,1); 
imshow(rgb2); 
title('RGB - Pencils');

subplot(2,3,2); 
imagesc(L2); 
colormap gray; 
axis image; 
title('L');

subplot(2,3,3); 
imagesc(a2); 
colormap gray; 
axis image; 
title('a');

subplot(2,3,4); 
imagesc(b2); 
colormap gray; 
axis image; 
title('b');