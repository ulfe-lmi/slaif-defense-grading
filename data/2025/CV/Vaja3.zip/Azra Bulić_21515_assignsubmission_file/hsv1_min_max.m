%% HSV min i max

vid = VideoReader('ladja.avi');
frame = read(vid, 50);

figure; imshow(frame);
title('Klikni 15 tačaka na moru');

[x, y] = ginput(15);

% pretvori u HSV
frameHSV = rgb2hsv(frame);

Hvals = zeros(15,1);
Svals = zeros(15,1);
Vvals = zeros(15,1);

for i = 1:15
    xi = round(x(i));
    yi = round(y(i));

    Hvals(i) = frameHSV(yi, xi, 1);
    Svals(i) = frameHSV(yi, xi, 2);
    Vvals(i) = frameHSV(yi, xi, 3);
end

% prikaz min i max
Hmin = min(Hvals);  Hmax = max(Hvals);
Smin = min(Svals);  Smax = max(Svals);
Vmin = min(Vvals);  Vmax = max(Vvals);

fprintf('Hmin = %.4f , Hmax = %.4f\n', Hmin, Hmax);
fprintf('Smin = %.4f , Smax = %.4f\n', Smin, Smax);
fprintf('Vmin = %.4f , Vmax = %.4f\n', Vmin, Vmax);