%% NALOGA 5: Segmentacija z histogram intersection
clear; close all; clc;

%% 1) Naloži video
video = VideoReader('ladja.avi');
frame = read(video,1);

%% 2) Interaktivni poligon za morje
imshow(frame); hold on;
title('Klikni vsaj 3 točke poligona za morje, Enter ko končaš');
[x, y] = ginput;
if length(x) < 3
    error('Moraš klikniti vsaj 3 točke za poligon.');
end
plot([x;x(1)],[y;y(1)],'r-','LineWidth',2);

[XX, YY] = meshgrid(1:size(frame,2), 1:size(frame,1));
mask = inpolygon(XX, YY, x, y);

%% 3) Histogram morja 4x4x4
numBins = 4;
edges = linspace(0,255,numBins+1);

R_sel = double(frame(:,:,1)); R_sel = R_sel(mask);
G_sel = double(frame(:,:,2)); G_sel = G_sel(mask);
B_sel = double(frame(:,:,3)); B_sel = B_sel(mask);

histSea = zeros(numBins,numBins,numBins);
for i = 1:length(R_sel)
    r_bin = find(edges >= R_sel(i),1)-1; r_bin = max(r_bin,1);
    g_bin = find(edges >= G_sel(i),1)-1; g_bin = max(g_bin,1);
    b_bin = find(edges >= B_sel(i),1)-1; b_bin = max(b_bin,1);
    histSea(r_bin,g_bin,b_bin) = histSea(r_bin,g_bin,b_bin) + 1;
end
histSea = histSea / sum(histSea(:)); % normaliziramo na vsoto 1

%% 4) Priprava output videa
outVid = VideoWriter('naloga5_output.avi');
outVid.FrameRate = video.FrameRate;
open(outVid);

blockSize = 8;  % 8x8 pikslov

%% 5) Obdelava frame-ov
video.CurrentTime = 0;
while hasFrame(video)
    frame = readFrame(video);
    [H, W, ~] = size(frame);
    
    % Število blokov
    H_blocks = floor(H/blockSize);
    W_blocks = floor(W/blockSize);
    
    grayFrame = zeros(H_blocks*blockSize, W_blocks*blockSize, 'uint8');
    
    % Obdelaj vsak blok
    for i = 1:H_blocks
        for j = 1:W_blocks
            rowIdx = (i-1)*blockSize + (1:blockSize);
            colIdx = (j-1)*blockSize + (1:blockSize);
            
            R_block = double(frame(rowIdx, colIdx,1));
            G_block = double(frame(rowIdx, colIdx,2));
            B_block = double(frame(rowIdx, colIdx,3));
            
            % histogram bloka
            histBlock = zeros(numBins,numBins,numBins);
            for r = 1:blockSize
                for c = 1:blockSize
                    r_bin = find(edges >= R_block(r,c),1)-1; r_bin = max(r_bin,1);
                    g_bin = find(edges >= G_block(r,c),1)-1; g_bin = max(g_bin,1);
                    b_bin = find(edges >= B_block(r,c),1)-1; b_bin = max(b_bin,1);
                    histBlock(r_bin,g_bin,b_bin) = histBlock(r_bin,g_bin,b_bin) + 1;
                end
            end
            histBlock = histBlock / sum(histBlock(:));
            
            % Histogram intersection
           intersectVal = sum(min(histSea(:), histBlock(:))) / sum(histSea(:));
            
            % Shrani v sivinski blok (0-256)
            grayBlock = uint8(intersectVal*256);
            grayFrame(rowIdx, colIdx) = grayBlock;
        end
    end
    
    writeVideo(outVid, grayFrame);
end

close(outVid);
disp('Video naloge 5 ustvarjen: naloga5_output.avi');
