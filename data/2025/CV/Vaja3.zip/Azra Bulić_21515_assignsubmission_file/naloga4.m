%% NALOGA 4: Avtomatska segmentacija morja z 3D RGB histogramom
clear; close all; clc;

%% Naloži video
video = VideoReader('ladja.avi');

%%  Preberi prvi frame za učno območje
frame = read(video, 1);
imshow(frame); hold on;
title('Klikni vsaj 3 točke poligona za označitev morja, Enter ko končaš');

%%  Interaktivni poligon za morje
[x, y] = ginput;  % klikni več točk in pritisni Enter

% Preveri, da je vsaj 3 točke
if length(x) < 3
    error('Moraš klikniti vsaj 3 točke za poligon.');
end

% Prikaži poligon
plot([x; x(1)], [y; y(1)], 'r-', 'LineWidth', 2);

%% Ustvarjanje maske z inpolygon (brez poly2mask)
[XX, YY] = meshgrid(1:size(frame,2), 1:size(frame,1));
mask = inpolygon(XX, YY, x, y);

% Prikaz maske
figure;
imshow(mask);
title('Maska izbranega območja');

%%Ekstrakcija pikslov morja
R_sel = double(frame(:,:,1));
G_sel = double(frame(:,:,2));
B_sel = double(frame(:,:,3));

R_sel = R_sel(mask);
G_sel = G_sel(mask);
B_sel = B_sel(mask);

%% Ustvarjanje 3D RGB histograma
numBins = 8;                        % 8x8x8 binov
edges = linspace(0, 255, numBins+1);
hist3D = zeros(numBins, numBins, numBins);

for i = 1:length(R_sel)
    r_bin = find(edges >= R_sel(i),1)-1; r_bin = max(r_bin,1);
    g_bin = find(edges >= G_sel(i),1)-1; g_bin = max(g_bin,1);
    b_bin = find(edges >= B_sel(i),1)-1; b_bin = max(b_bin,1);
    hist3D(r_bin,g_bin,b_bin) = hist3D(r_bin,g_bin,b_bin) + 1;
end

% Normalizacija histograma (maksimalni bin = 255)
hist3D = uint8(255 * hist3D / max(hist3D(:)));

outVid = VideoWriter('naloga4_output.avi');
outVid.FrameRate = video.FrameRate;
open(outVid);

%%  Obdelava vseh frame-ov videa (vektorizirano)
video.CurrentTime = 0;
while hasFrame(video)
    frame = readFrame(video);

    Rf = double(frame(:,:,1));
    Gf = double(frame(:,:,2));6
    Bf = double(frame(:,:,3));

    % določitev binov
    r_bin = discretize(Rf, edges);
    g_bin = discretize(Gf, edges);
    b_bin = discretize(Bf, edges);

    % nadomestimo NaN z 1
    r_bin(isnan(r_bin)) = 1;
    g_bin(isnan(g_bin)) = 1;
    b_bin(isnan(b_bin)) = 1;

    % vektorizirana dodelitev sivinskega frame-a
    grayFrame = hist3D(sub2ind(size(hist3D), r_bin, g_bin, b_bin));
    grayFrame = uint8(grayFrame);

    writeVideo(outVid, grayFrame);
end

close(outVid);
disp('Video naloge 4 ustvarjen: naloga4_output.avi');
