%% RGB

vid = VideoReader('ladja.avi');
frames = read(vid, [1 Inf]);

% Dimenzije videa
[H, W, ~, N] = size(frames);

% Izgled 50. framea (Opcionalno)
%frame_50 = frames(:, :, :, 50);

for m = 1:N
    for i = 1:H
        for j = 1:W

            R = frames(i, j, 1, m);
            G = frames(i, j, 2, m);
            B = frames(i, j, 3, m);

            %odredjeno iz koda za min i max vrijednosti
            if (33 <= R && R <= 114 && 63 <= G && G <= 139 && 37 <= B && B <= 129)
                frames(i, j, 1, m) = 255;
                frames(i, j, 2, m) = 255;
                frames(i, j, 3, m) = 255;
            else
                frames(i, j, 1, m) = 0;
                frames(i, j, 2, m) = 0;
                frames(i, j, 3, m) = 0;
            end
        end
    end
end

writer_object = VideoWriter('ladjaRGB.avi');
writer_object.FrameRate = 25;
open(writer_object);
writeVideo(writer_object, frames);
close(writer_object);

%% HSV1
vid = VideoReader('ladja.avi');
frames = read(vid, [1 Inf]);

% dimenzije
[H, W, ~, nFrames] = size(frames);

% konverzija svih frameova u HSV
framesHSV = zeros(H, W, 3, nFrames);
for m = 1:nFrames
    framesHSV(:,:,:,m) = rgb2hsv(frames(:,:,:,m));
end

%min i max za H
Hmin = 0.35;
Hmax = 0.45;

for m = 1:nFrames
    for i = 1:H
        for j = 1:W
            if Hmin <= framesHSV(i,j,1,m) && framesHSV(i,j,1,m) <= Hmax
                frames(i,j,1,m) = 255;
                frames(i,j,2,m) = 255;
                frames(i,j,3,m) = 255;
            else
                frames(i,j,1,m) = 0;
                frames(i,j,2,m) = 0;
                frames(i,j,3,m) = 0;
            end
        end
    end
end

% zapis videa
writer_object = VideoWriter('ladjaHSV1.avi');
writer_object.FrameRate = 25;
open(writer_object);
writeVideo(writer_object, frames);
close(writer_object);

%% HSV2

% Učitaj sve frameove videa
ladja  = VideoReader('ladja.avi');
frames = read(ladja,[1 Inf]);
[H, W, ~, nFrames] = size(frames);

% svi rameovi u HSV
framesHSV = zeros(H, W, 3, nFrames);
for k = 1:nFrames
    framesHSV(:,:,:,k) = rgb2hsv(frames(:,:,:,k));
end

% H i S, min i max
Hmin2 = 0.35;  
Hmax2 = 0.45;
Smin2 = 0.2;  
Smax2 = 0.45;

for m = 1:nFrames
    for i = 1:H
        for j = 1:W
            Hval = framesHSV(i,j,1,m);
            Vval = framesHSV(i,j,3,m);

            if (Hval >= Hmin2 && Hval <= Hmax2 && Vval >= Smin2 && Vval <= Smax2)
                frames(i,j,1,m) = 255;
                frames(i,j,2,m) = 255;
                frames(i,j,3,m) = 255;
            else
                frames(i,j,1,m) = 0;
                frames(i,j,2,m) = 0;
                frames(i,j,3,m) = 0;
            end
        end
    end
end

% rezultat
writer_object = VideoWriter('ladjaHSV2.avi');
writer_object.FrameRate = 25;
open(writer_object);
writeVideo(writer_object, frames);
close(writer_object);

%% HSV3

ladja   = VideoReader('ladja.avi');
frames  = read(ladja, [1 Inf]);
nFrames = size(frames, 4);

% Konverzija svih frameova u HSV
framesHSV = zeros(H,W,3,nFrames);
for m = 1:nFrames
    framesHSV(:,:,:,m) = rgb2hsv(frames(:,:,:,m));
end

% H,S,V min i max
Hmin3 = 0.35;  
Hmax3 = 0.45;
Smin3 = 0.2;  
Smax3 = 0.45;
Vmin = 0.3;  
Vmax = 0.49;

% piksel je bijel ako zadovoljava sva tri uslova, inače crn
[H, W, ~, ~] = size(frames);
for m = 1:nFrames
    for i = 1:H
        for j = 1:W
            Hval = framesHSV(i,j,1,m);
            Sval = framesHSV(i,j,2,m);
            Vval = framesHSV(i,j,3,m);

            if (Hval >= Hmin3 && Hval <= Hmax3 && Sval >= Smin3 && Sval <= Smax3 && Vval >= Vmin && Vval <= Vmax)
                frames(i,j,1,m) = 255;
                frames(i,j,2,m) = 255;
                frames(i,j,3,m) = 255;
            else
                frames(i,j,1,m) = 0;
                frames(i,j,2,m) = 0;
                frames(i,j,3,m) = 0;
            end
        end
    end
end

% rezultati
writer_object = VideoWriter('ladjaHSV3.avi');
writer_object.FrameRate = 25;
open(writer_object);
writeVideo(writer_object, frames);
close(writer_object);


