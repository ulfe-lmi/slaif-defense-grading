% Naloga 1 
% Prikaz komponent HSV in Lab

clear all; close all; clc;

% 1) prebere sliki
img1 = imread('yosemite_meadows.jpg');
img2 = imread('coloured_pencils.jpg');


%   HSV ZA YOSEMITE

hsv1 = rgb2hsv(img1);

H1 = hsv1(:,:,1);
S1 = hsv1(:,:,2);
V1 = hsv1(:,:,3);

figure('Name','Yosemite - HSV');
subplot(1,3,1); imagesc(H1); colormap(gray); axis image off; title('H');
subplot(1,3,2); imagesc(S1); colormap(gray); axis image off; title('S');
subplot(1,3,3); imagesc(V1); colormap(gray); axis image off; title('V');


%  Lab ZA YOSEMITE

lab1 = rgb2lab(img1);

L1 = lab1(:,:,1);
a1 = lab1(:,:,2);
b1 = lab1(:,:,3);

figure('Name','Yosemite - Lab');
subplot(1,3,1); imagesc(L1); colormap(gray); axis image off; title('L');
subplot(1,3,2); imagesc(a1); colormap(gray); axis image off; title('a');
subplot(1,3,3); imagesc(b1); colormap(gray); axis image off; title('b');



% HSV ZA PENCILS

hsv2 = rgb2hsv(img2);

H2 = hsv2(:,:,1);
S2 = hsv2(:,:,2);
V2 = hsv2(:,:,3);

figure('Name','Pencils - HSV');
subplot(1,3,1); imagesc(H2); colormap(gray); axis image off; title('H');
subplot(1,3,2); imagesc(S2); colormap(gray); axis image off; title('S');
subplot(1,3,3); imagesc(V2); colormap(gray); axis image off; title('V');



%  Lab ZA PENCILS

lab2 = rgb2lab(img2);

L2 = lab2(:,:,1);
a2 = lab2(:,:,2);
b2 = lab2(:,:,3);

figure('Name','Pencils - Lab');
subplot(1,3,1); imagesc(L2); colormap(gray); axis image off; title('L');
subplot(1,3,2); imagesc(a2); colormap(gray); axis image off; title('a');
subplot(1,3,3); imagesc(b2); colormap(gray); axis image off; title('b');
