%           NALOGA 2 
% Vpliv posameznih komponent HSV in Lab na končno RGB sliko

clear all; close all; clc;

% Branje slik
img1 = imread('yosemite_meadows.jpg');
img2 = imread('coloured_pencils.jpg');

images = {img1, img2};
names = {'Yosemite', 'Pencils'};


% HSV ANALIZA
for k = 1:2
    img = images{k};
    name = names{k};

    hsvImg = rgb2hsv(img);

    H = hsvImg(:,:,1);
    S = hsvImg(:,:,2);
    V = hsvImg(:,:,3);

    % konstante (polovica maksimalne vrednosti = 0.5)
    constH = 0.5;
    constS = 0.5;
    constV = 0.5;

    % --- 1) Vpliv H
    hsvMod = hsvImg;
    hsvMod(:,:,1) = constH;
    rgbH = hsv2rgb(hsvMod);

    figure('Name',[name ' - HSV brez H']);
    imshow(rgbH); title([name ' - konstanten H']);

    % --- 2) Vpliv S
    hsvMod = hsvImg;
    hsvMod(:,:,2) = constS;
    rgbS = hsv2rgb(hsvMod);

    figure('Name',[name ' - HSV brez S']);
    imshow(rgbS); title([name ' - konstanten S']);

    %% --- 3) Vpliv V
    hsvMod = hsvImg;
    hsvMod(:,:,3) = constV;
    rgbV = hsv2rgb(hsvMod);

    figure('Name',[name ' - HSV brez V']);
    imshow(rgbV); title([name ' - konstanten V']);

end


%       Lab ANALIZA
for k = 1:2
    img = images{k};
    name = names{k};

    labImg = rgb2lab(img);

    L = labImg(:,:,1);
    a = labImg(:,:,2);
    b = labImg(:,:,3);

    % konstante (sredina intervala)
    constL = 50;
    consta = 0;
    constb = 0;

    % --- 1) Vpliv L
    labMod = labImg;
    labMod(:,:,1) = constL;
    rgbL = lab2rgb(labMod);

    figure('Name',[name ' - Lab brez L']);
    imshow(rgbL); title([name ' - konstanten L']);

    % --- 2) Vpliv a
    labMod = labImg;
    labMod(:,:,2) = consta;
    rgbA = lab2rgb(labMod);

    figure('Name',[name ' - Lab brez a']);
    imshow(rgbA); title([name ' - konstanten a']);

    % --- 3) Vpliv b
    labMod = labImg;
    labMod(:,:,3) = constb;
    rgbB = lab2rgb(labMod);

    figure('Name',[name ' - Lab brez b']);
    imshow(rgbB); title([name ' - konstanten b']);

end
