clear all; close all; clc;

%% ===============================================
%     NALOGA 5 – Histogram Intersection (4x4x4)
% ================================================

% Preberi video
video = VideoReader('ladja.avi');

% Vzamemo en okvir za učenje (npr. 50)
frame = read(video, 50);
figure; imshow(frame); title('Klikni izsek MORJA (pravokotnik)');
h = imrect;
pos = wait(h);   % uporabnik izbere ROI

% Izreži učni del
x1 = round(pos(1)); 
y1 = round(pos(2));
w  = round(pos(3));
h_ = round(pos(4));

roi = frame(y1:y1+h_-1, x1:x1+w-1, :);   % <-- popravek (w_ ni obstajal!)

figure; imshow(roi); title('Izsek morja za učenje');

%% ===============================================
%     Izračun 4x4x4 RGB histograma MORJA
% ================================================

bins = 4;
binSize = 256 / bins;

hist_sea = zeros(bins, bins, bins);

for y = 1:size(roi,1)
    for x = 1:size(roi,2)

        R = roi(y,x,1);
        G = roi(y,x,2);
        B = roi(y,x,3);

        r_bin = min(floor(double(R)/binSize) + 1, bins);
        g_bin = min(floor(double(G)/binSize) + 1, bins);
        b_bin = min(floor(double(B)/binSize) + 1, bins);

        hist_sea(r_bin, g_bin, b_bin) = hist_sea(r_bin, g_bin, b_bin) + 1;
    end
end

hist_sea = hist_sea / sum(hist_sea(:));  % normalizacija

disp('Histogram MORJA pripravljen.');

%     PRIPRAVA IZHODNEGA VIDEA


out = VideoWriter('ladja_hist_intersection.avi');
out.FrameRate = video.FrameRate;
open(out);


%     OBDELAVA VIDEA


blockSize = 8;

for k = 1:video.NumFrames
    frame = read(video, k);

    % Izhodni sivinski frame
    frameGray = zeros(size(frame,1), size(frame,2), 'uint8');

    % Zanka po blokih
    for y = 1:blockSize:size(frame,1)-blockSize+1
        for x = 1:blockSize:size(frame,2)-blockSize+1

            block = frame(y:y+blockSize-1, x:x+blockSize-1, :);

            % histogram bloka
            hist_block = zeros(bins,bins,bins);

            for yy = 1:blockSize
                for xx = 1:blockSize

                    R = block(yy,xx,1);
                    G = block(yy,xx,2);
                    B = block(yy,xx,3);

                    r_bin = min(floor(double(R)/binSize) + 1, bins);
                    g_bin = min(floor(double(G)/binSize) + 1, bins);
                    b_bin = min(floor(double(B)/binSize) + 1, bins);

                    hist_block(r_bin, g_bin, b_bin) = ...
                        hist_block(r_bin, g_bin, b_bin) + 1;
                end
            end

            hist_block = hist_block / sum(hist_block(:));

         
            HI = sum(min(hist_block(:), hist_sea(:)));

            val = uint8(HI * 255);

            frameGray(y:y+blockSize-1, x:x+blockSize-1) = val;
        end
    end

    writeVideo(out, frameGray);
    fprintf('Frame %d / %d obdelan.\n', k, video.NumFrames);
end

close(out);

