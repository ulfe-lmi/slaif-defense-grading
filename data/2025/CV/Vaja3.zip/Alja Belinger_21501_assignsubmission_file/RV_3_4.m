clear all; close all; clc;

%% ===============================
%      NALOGA 4 – 3D RGB HISTOGRAM
% ================================

video = VideoReader('ladja.avi');
numF = floor(video.FrameRate * video.Duration);

%% --- 1. OKVIR IN IZREŽEMO MORJE ---
frame = read(video, 50);  % isti kot prej

figure; imshow(frame); title('Označi pravokotnik z MORJEM (tipično območje)');
rect = round(getrect());   % uporabnik z miško označi ROI

% izrez
roi = imcrop(frame, rect);

figure; imshow(roi); title('Izrez morja');

%% --- 2. KONSTRUKCIJA 3D HISTOGRAMA (8 × 8 × 8) ---

bins = 8;              % št. binov po osi R, G, B
binSize = 256 / bins;  % velikost posameznega intervala

% 3D histogram
H = zeros(bins, bins, bins);

% napolnimo histogram iz ROI
for y = 1:size(roi,1)
    for x = 1:size(roi,2)

        R = roi(y,x,1);
        G = roi(y,x,2);
        B = roi(y,x,3);

        % izračun bin indeksa
        Rbin = floor(double(R) / binSize) + 1;
        Gbin = floor(double(G) / binSize) + 1;
        Bbin = floor(double(B) / binSize) + 1;

        % omejitev (če je R==255 → pade v zadnji bin)
        Rbin = min(Rbin, bins);
        Gbin = min(Gbin, bins);
        Bbin = min(Bbin, bins);

        H(Rbin, Gbin, Bbin) = H(Rbin, Gbin, Bbin) + 1;
    end
end

%% --- 3. NORMALIZACIJA HISTOGRAMA (max = 255) ---

H = H * (255 / max(H(:)));


%% --- 4. SEGMENTACIJA VIDEA S POMOČJO HISTOGRAMA ---

out = VideoWriter('ladja_segment_histogram.avi');
out.FrameRate = video.FrameRate;
open(out);

for k = 1:numF
    frame = read(video, k);

    % izhodna slika (sivinska)
    outFrame = zeros(size(frame,1), size(frame,2), 'uint8');

    for y = 1:size(frame,1)
        for x = 1:size(frame,2)

            R = frame(y,x,1);
            G = frame(y,x,2);
            B = frame(y,x,3);

            Rbin = floor(double(R) / binSize) + 1;
            Gbin = floor(double(G) / binSize) + 1;
            Bbin = floor(double(B) / binSize) + 1;

            Rbin = min(Rbin, bins);
            Gbin = min(Gbin, bins);
            Bbin = min(Bbin, bins);

            % sivinska vrednost = vrednost histograma tega 3D bin-a
            outFrame(y,x) = uint8(H(Rbin, Gbin, Bbin));
        end
    end

    % VideoWriter zahteva 3-kanalno sliko, zato sivinsko ponovimo v RGB
    rgbFrame = repmat(outFrame, [1 1 3]);

    writeVideo(out, rgbFrame);
end

close(out);

