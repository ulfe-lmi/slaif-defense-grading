clear; close all; clc;

%% ===============================
%          NALOGA 3
%  Segmentacija morja
% ===============================

video = VideoReader('ladja.avi');

% število frejmov
numF = floor(video.FrameRate * video.Duration);

% vzamemo testni frame
frame0 = read(video,50);

figure, imshow(frame0)
title('Označi pravokotnik območja MORJA in 2x klikni');

% izberemo pravokotnik
roi = drawrectangle;
wait(roi);

% izrežemo območje
area = imcrop(frame0, roi.Position);

%% ===============================
%   MEJE V RGB (iz pravokotnika)
%% ===============================

Rmin = min(area(:,:,1),[],'all');
Rmax = max(area(:,:,1),[],'all');

Gmin = min(area(:,:,2),[],'all');
Gmax = max(area(:,:,2),[],'all');

Bmin = min(area(:,:,3),[],'all');
Bmax = max(area(:,:,3),[],'all');

%   SEGMENTACIJA RGB


outRGB = VideoWriter('ladja_segment_RGB.avi');
outRGB.FrameRate = video.FrameRate;
open(outRGB);

for k = 1:numF
    frame = read(video,k);

    mask = frame(:,:,1) >= Rmin & frame(:,:,1) <= Rmax & ...
           frame(:,:,2) >= Gmin & frame(:,:,2) <= Gmax & ...
           frame(:,:,3) >= Bmin & frame(:,:,3) <= Bmax;

    writeVideo(outRGB, uint8(mask)*255);
end

close(outRGB);



%     MEJE V HSV


hsv_area = rgb2hsv(area);

Hmin = min(hsv_area(:,:,1),[],'all');
Hmax = max(hsv_area(:,:,1),[],'all');

Smin = min(hsv_area(:,:,2),[],'all');
Smax = max(hsv_area(:,:,2),[],'all');


%     SEGMENTACIJA HSV


outHSV = VideoWriter('ladja_segment_HSV.avi');
outHSV.FrameRate = video.FrameRate;
open(outHSV);

for k = 1:numF
    frame = read(video,k);
    hsv = rgb2hsv(frame);

    % samo H + S
    mask = hsv(:,:,1) >= Hmin & hsv(:,:,1) <= Hmax & ...
           hsv(:,:,2) >= Smin & hsv(:,:,2) <= Smax;

    writeVideo(outHSV, uint8(mask)*255);
end

close(outHSV);

