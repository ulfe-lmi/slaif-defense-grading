clear all; close all; clc;
%% ===============================
%          NALOGA 2
%  Vpliv posameznih komponent HSV in Lab na končno RGB sliko
% ================================

%% Branje slik
img1 = imread('yosemite_meadows.jpg');
img2 = imread('coloured_pencils.jpg');

images = {img1, img2};
names = {'Yosemite', 'Pencils'};


%% HSV ANALIZA 
for k = 1:2
    img = images{k};
    name = names{k};

    hsvImg = rgb2hsv(img);

    % KONSTANTE
    constH = 0.5;
    constS = 0.5;
    constV = 0.5;

    % 1) Konstanten H
    hsvMod = hsvImg;
    hsvMod(:,:,1) = constH;
    rgbH = hsv2rgb(hsvMod);

    % 2) Konstanten S
    hsvMod = hsvImg;
    hsvMod(:,:,2) = constS;
    rgbS = hsv2rgb(hsvMod);

    % 3) Konstanten V
    hsvMod = hsvImg;
    hsvMod(:,:,3) = constV;
    rgbV = hsv2rgb(hsvMod);

    % ---- RISANJE NA ENO FIGURO ----
    figure('Name',[name ' - HSV vpliv komponent']);
    sgtitle([name ' – vpliv konstantnega H, S in V']);

    subplot(1,3,1); imshow(rgbH); title('Konstanten H');
    subplot(1,3,2); imshow(rgbS); title('Konstanten S');
    subplot(1,3,3); imshow(rgbV); title('Konstanten V');
end


%%  Lab ANALIZA 
for k = 1:2
    img = images{k};
    name = names{k};

    labImg = rgb2lab(img);

    % KONSTANTE
    constL = 50;
    consta = 0;
    constb = 50;

    % 1) Konstanten L
    labMod = labImg;
    labMod(:,:,1) = constL;
    rgbL = lab2rgb(labMod);

    % 2) Konstanten a
    labMod = labImg;
    labMod(:,:,2) = consta;
    rgbA = lab2rgb(labMod);

    % 3) Konstanten b
    labMod = labImg;
    labMod(:,:,3) = constb;
    rgbB = lab2rgb(labMod);

    % ---- RISANJE NA ENO FIGURO ----
    figure('Name',[name ' - Lab vpliv komponent']);
    sgtitle([name ' – vpliv konstantnega L, a in b']);

    subplot(1,3,1); imshow(rgbL); title('Konstanten L');
    subplot(1,3,2); imshow(rgbA); title('Konstanten a');
    subplot(1,3,3); imshow(rgbB); title('Konstanten b');
end
