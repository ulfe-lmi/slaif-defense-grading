%% VAJA 5 – 1. 
clc; clear; close all;

inputFile = 'Holywood2-t00427-rgb.avi';

if ~isfile(inputFile)
    alt = 'Holywood.avi';
    if isfile(alt)
        inputFile = alt;
    else
        error("Ne najdem videa '%s' (niti '%s') v trenutni mapi.", ...
              'Holywood2-t00427-rgb.avi', 'Holywood.avi');
    end
end

scales = [1/2, 1/4, 1/8];

methods(1).tag = "nearest";
methods(1).interp = "nearest";
methods(1).useAA = [];         

methods(2).tag = "bilinear_AAoff";
methods(2).interp = "bilinear";
methods(2).useAA = false;     

methods(3).tag = "bilinear_AAon";
methods(3).interp = "bilinear";
methods(3).useAA = true;      

for m = 1:numel(methods)
    for s = 1:numel(scales)

        v = VideoReader(inputFile); 

        outName = sprintf('%s_scale_%0.3f.avi', methods(m).tag, scales(s));
        w = VideoWriter(outName, 'Motion JPEG AVI');
        w.FrameRate = v.FrameRate; 
        open(w);

        while hasFrame(v)
            frame = readFrame(v);

            if methods(m).tag == "nearest"
                resized = imresize(frame, scales(s), methods(m).interp);
            else
                resized = imresize(frame, scales(s), methods(m).interp, ...
                                   'Antialiasing', methods(m).useAA);
            end

            writeVideo(w, resized);
        end

        close(w);
        fprintf("Shranjeno: %s\n", outName);
    end
end

disp("Končano: ustvarjenih 9 pomanjšanih posnetkov.");

%%
vN  = VideoReader('nearest_scale_0.125.avi');
vO  = VideoReader('bilinear_AAoff_scale_0.125.avi');
vI  = VideoReader('bilinear_AAon_scale_0.125.avi');

fN = readFrame(vN);
fO = readFrame(vO);
fI = readFrame(vI);

H = 288; W = 384; 
fN2 = imresize(fN,[H W],'nearest');
fO2 = imresize(fO,[H W],'nearest');
fI2 = imresize(fI,[H W],'nearest');

figure;
imshow([fN2 fO2 fI2]);
title('Nearest | Bilinear AA off | Bilinear AA on (vsi povečani z nearest)');

