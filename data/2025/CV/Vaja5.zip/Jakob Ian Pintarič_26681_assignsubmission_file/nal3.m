%% VAJA 5 – 3. 
clc;
close all;

video = VideoReader("squash.avi");
frame = readFrame(video);
gray = rgb2gray(frame);

alphaT = 0.03;
alphaP = 0.4;
search_radius = 40;
minScore = 0.45;       
learnScore = 0.65;
maxMove = 30;
border = 25;

lostCounter = 0;
lostLimit = 5;        

figure; imshow(frame);
title("Izberi 2 točki na rdečem igralcu");
p = round(ginput(2));
close;

x1 = min(p(:,1)); y1 = min(p(:,2));
x2 = max(p(:,1)); y2 = max(p(:,2));

w = x2 - x1;
h = y2 - y1;

template = gray(y1:y2, x1:x2);
cx = x1 + w/2;
cy = y1 + h/2;

fig = figure('visible','off');
ax = axes(fig);

videoout = VideoWriter("naloga3_sprotno_ucenje.avi","Uncompressed AVI");
open(videoout);

while hasFrame(video)

    frame = readFrame(video);
    gray = rgb2gray(frame);

    if lostCounter < lostLimit
        xs = max(1, round(cx - search_radius));
        ys = max(1, round(cy - search_radius));
        xe = min(size(gray,2), round(cx + search_radius + w));
        ye = min(size(gray,1), round(cy + search_radius + h));
    else
        xs = 1; ys = 1;
        xe = size(gray,2);
        ye = size(gray,1);
    end

    roi = gray(ys:ye, xs:xe);

    C = normxcorr2(template, roi);
    [peak, idx] = max(C(:));
    [ypeak, xpeak] = ind2sub(size(C), idx);

    xtl = xpeak - size(template,2) + 1;
    ytl = ypeak - size(template,1) + 1;

    xtl = max(1, min(xtl, size(roi,2)-w));
    ytl = max(1, min(ytl, size(roi,1)-h));

    cand_x = xs + xtl - 1;
    cand_y = ys + ytl - 1;

    cand_cx = cand_x + w/2;
    cand_cy = cand_y + h/2;

    dx = abs(cand_cx - cx);
    dy = abs(cand_cy - cy);

    if peak > minScore && dx < maxMove && dy < maxMove
        cx = (1-alphaP)*cx + alphaP*cand_cx;
        cy = (1-alphaP)*cy + alphaP*cand_cy;
        lostCounter = 0;
    else
        lostCounter = lostCounter + 1;
    end

    bx = round(cx - w/2);
    by = round(cy - h/2);

    bx = max(1, min(bx, size(gray,2)-w));
    by = max(1, min(by, size(gray,1)-h));

    if peak > learnScore && lostCounter == 0 && ...
       bx > border && by > border && ...
       bx+w < size(gray,2)-border && by+h < size(gray,1)-border

        patch = gray(by:by+h, bx:bx+w);
        template = uint8((1-alphaT)*double(template) + alphaT*double(patch));
    end

    cla(ax);
    imshow(frame, 'Parent', ax); hold(ax,'on');

    if peak > minScore
        rectangle(ax,'Position',[bx by w h],'EdgeColor','g','LineWidth',2);
    end

    text(ax,10,20,sprintf("score = %.2f",peak), ...
        'Color','y','FontSize',12,'FontWeight','bold');

    hold(ax,'off');

    F = getframe(ax);
    writeVideo(videoout, F.cdata);
end

close(videoout);
close(fig);

disp("NALOGA 3 KONČANA – algoritem je sproti pozabil, kaj je igralec se je naučil napačnega vzorca (ozadja). .");
