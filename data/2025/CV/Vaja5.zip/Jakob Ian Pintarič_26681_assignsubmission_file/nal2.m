%% VAJA 5 – 2. 
clc; clear; close all;

videoFile = 'squash.avi';
if ~isfile(videoFile)
    error("Ne najdem '%s' v trenutni mapi.", videoFile);
end

epsN = 40;          
bins = 32;          
betaSSD = 0.30;     
maxFrames = inf;

minW = 60;
minH = 40;

v0 = VideoReader(videoFile);
frame0 = readFrame(v0);

figure('Name','ROI','NumberTitle','off');
imshow(frame0);
title('Klikni 2x: zgornji-levo in spodnji-desno (ROI igralca)');
roi = selectROI2Clicks(frame0, minW, minH);
close;

disp("ROI = [x y w h]:");
disp(roi);

track(videoFile,'2_1_euclidean_rgb.avi',roi,epsN,maxFrames,'ssd',bins,betaSSD);

track(videoFile,'2_2_chi2_hue.avi',roi,epsN,maxFrames,'chi2',bins,0);

implay('2_2_chi2_hue.avi');

%%
function track(videoFile,outFile,roi,epsN,maxFrames,mode,bins,beta)

v = VideoReader(videoFile);
w = VideoWriter(outFile,'Motion JPEG AVI');
w.FrameRate = v.FrameRate;
open(w);

frame = readFrame(v);
[x,y,W,H] = deal(roi(1),roi(2),roi(3),roi(4));

if strcmp(mode,'ssd')
    img = im2single(frame);
    ref = img(y:y+H-1, x:x+W-1, :);
    col = uint8([255 0 0]);
else
    img = hueU8(frame);
    ref = histN(img(y:y+H-1, x:x+W-1), bins);
    col = uint8([0 255 0]);
end

writeVideo(w, drawRect(frame,[x y W H],col,2));
k = 1;

while hasFrame(v) && k < maxFrames
    k = k + 1;
    frame = readFrame(v);

    if strcmp(mode,'ssd')
        img = im2single(frame);
        [xNew,yNew] = searchSSD(img, ref, x, y, W, H, epsN);

        x = round((1-beta)*x + beta*xNew);
        y = round((1-beta)*y + beta*yNew);

    else
        img = hueU8(frame);
        [x,y] = searchChi2(img, ref, x, y, W, H, epsN, bins);
    end

    x = max(1, min(size(frame,2)-W+1, x));
    y = max(1, min(size(frame,1)-H+1, y));

    writeVideo(w, drawRect(frame,[x y W H],col,2));
end

close(w);
end

%%
function [xBest,yBest] = searchSSD(img, ref, x0, y0, W, H, epsN)

Himg = size(img,1);
Wimg = size(img,2);

xMin = max(1,x0-epsN);
xMax = min(Wimg-W+1,x0+epsN);
yMin = max(1,y0-epsN);
yMax = min(Himg-H+1,y0+epsN);

lambda = 0.05;   % kazen za skoke

bestVal = inf;
xBest = x0; yBest = y0;

for y = yMin:yMax
    for x = xMin:xMax
        p = img(y:y+H-1, x:x+W-1, :);
        d = sum((p(:)-ref(:)).^2);
        penalty = lambda*((x-x0)^2 + (y-y0)^2);
        score = d + penalty;

        if score < bestVal
            bestVal = score;
            xBest = x;
            yBest = y;
        end
    end
end
end

%%
function [xBest,yBest] = searchChi2(imgU8, refH, x0, y0, W, H, epsN, bins)

Himg = size(imgU8,1);
Wimg = size(imgU8,2);

xMin = max(1,x0-epsN);
xMax = min(Wimg-W+1,x0+epsN);
yMin = max(1,y0-epsN);
yMax = min(Himg-H+1,y0+epsN);

bestVal = inf;
xBest = x0; yBest = y0;

for y = yMin:yMax
    for x = xMin:xMax
        patch = imgU8(y:y+H-1, x:x+W-1);
        h = histN(patch,bins);
        d = sum((h-refH).^2 ./ (h+refH+1e-12));

        if d < bestVal
            bestVal = d;
            xBest = x;
            yBest = y;
        end
    end
end
end

%%
function roi = selectROI2Clicks(frame, minW, minH)

Wimg = size(frame,2);
Himg = size(frame,1);

while true
    imshow(frame);
    title('Klikni 2x: zgornji-levo in spodnji-desno');
    [x,y] = ginput(2);
    x = round(x); y = round(y);

    x1 = max(1,min(Wimg,x(1))); y1 = max(1,min(Himg,y(1)));
    x2 = max(1,min(Wimg,x(2))); y2 = max(1,min(Himg,y(2)));

    xMin = min(x1,x2);
    yMin = min(y1,y2);

    w = max(abs(x2-x1)+1, minW);
    h = max(abs(y2-y1)+1, minH);

    roi = [xMin yMin w h];
    rectangle('Position',roi,'EdgeColor','r','LineWidth',2);

    ok = questdlg('ROI OK?','ROI','OK','Ponovi','OK');
    if strcmp(ok,'OK'), break; end
end
end

%%
function H = hueU8(rgb)
hsvI = rgb2hsv(rgb);
H = uint8(255*hsvI(:,:,1));
end

function h = histN(patch,bins)
h = double(imhist(patch,bins));
h = h/(sum(h)+1e-12);
end

%%
function imgOut = drawRect(imgIn, rect, color, lw)

imgOut = imgIn;
x = rect(1); y = rect(2);
W = rect(3); H = rect(4);

x1 = max(1,x); y1 = max(1,y);
x2 = min(size(imgOut,2),x+W-1);
y2 = min(size(imgOut,1),y+H-1);

R = color(1); G = color(2); B = color(3);

for t=0:lw-1
    imgOut(y1+t,x1:x2,1)=R; imgOut(y1+t,x1:x2,2)=G; imgOut(y1+t,x1:x2,3)=B;
    imgOut(y2-t,x1:x2,1)=R; imgOut(y2-t,x1:x2,2)=G; imgOut(y2-t,x1:x2,3)=B;
    imgOut(y1:y2,x1+t,1)=R; imgOut(y1:y2,x1+t,2)=G; imgOut(y1:y2,x1+t,3)=B;
    imgOut(y1:y2,x2-t,1)=R; imgOut(y1:y2,x2-t,2)=G; imgOut(y1:y2,x2-t,3)=B;
end
end
