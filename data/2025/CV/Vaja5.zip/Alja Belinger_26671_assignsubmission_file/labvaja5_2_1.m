%% Vaja 5 – 2.1: Sledenje igralca (Evklidska razdalja v RGB, brez učenja)
clear; close all; clc;

v = VideoReader('squash.avi');

frameRGB = readFrame(v);

figure(1);
imshow(frameRGB);
title('Z dvema klikoma oznaci igralca (ROI naj bo majhen in informativen)');
[x, y] = ginput(2);

x = round(x); y = round(y);
x1 = min(x); x2 = max(x);
y1 = min(y); y2 = max(y);

w = x2 - x1;
h = y2 - y1;

template = frameRGB(y1:y2, x1:x2, :);   % RGB template

%% Parametri
epsilon = 25;      % ce mamo hitre premike, dej vec k 10
   

writer = VideoWriter('sledenje_L2_RGB.avi');
open(writer);

prevX = x1;
prevY = y1;

k = 1;
while hasFrame(v)

    frameRGB = readFrame(v);

    bestDist = inf;
    bestX = prevX;
    bestY = prevY;

    for dx = -epsilon:epsilon
        for dy = -epsilon:epsilon
            x = prevX + dx;
            y = prevY + dy;

            if x < 1 || y < 1 || ...
               x+w > size(frameRGB,2) || ...
               y+h > size(frameRGB,1)
                continue;
            end

            patch = frameRGB(y:y+h, x:x+w, :);

            diff = double(patch) - double(template);
            dist = mean(diff(:).^2);    % L2 v RGB (normaliziran)

            if dist < bestDist
                bestDist = dist;
                bestX = x;
                bestY = y;
            end
        end
    end

    prevX = bestX;
    prevY = bestY;

    imshow(frameRGB); hold on;
    rectangle('Position',[bestX bestY w h], 'EdgeColor','r','LineWidth',2);
    hold off;

    writeVideo(writer, getframe(gca));
    k = k + 1;
end

close(writer);
