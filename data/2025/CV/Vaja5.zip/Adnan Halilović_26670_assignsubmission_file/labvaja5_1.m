%% RV vaja 5 – 1. naloga: Podvzorčenje slik

% Primerjava treh metod interpolacije pri zmanjsevanju locljivosti

clear;
close all;
clc;

%% Branje videa
videoFile = 'Holywood.avi';
v = VideoReader(videoFile);

% Preberemo prvi frame
frame = readFrame(v);

figure;
imshow(frame);
title('Originalna slika');

%% Faktorji zmanjsanja
scales = [1/2, 1/4, 1/8];

%% Skupni figure
figure;
sgtitle('Primerjava metod interpolacije pri podvzorcenju');

%% METODA 1: Nearest Neighbor
disp('Metoda 1: Nearest Neighbor');

for i = 1:length(scales)
    s = scales(i);

    img_nn = imresize(frame, s, 'nearest');

    subplot(3,3,i);
    imshow(img_nn);
    title(['Nearest neighbor, faktor = ', num2str(s)]);
    
    % shranjevanje
    imwrite(img_nn, ...
        ['NN_scale_', num2str(s*100), '.png']);
end

%% METODA 2: Bilinear brez filtriranja (antialiasing OFF)
disp('Metoda 2: Bilinear brez filtriranja');

for i = 1:length(scales)
    s = scales(i);

    img_bl_noaa = imresize(frame, s, ...
        'bilinear', 'Antialiasing', false);

    subplot(3,3,i+3);
    imshow(img_bl_noaa);
    title(['Bilinear brez AA, faktor = ', num2str(s)]);
    
    imwrite(img_bl_noaa, ...
        ['BL_noAA_scale_', num2str(s*100), '.png']);
end

%% METODA 3: Bilinear s filtriranjem (antialiasing ON)
disp('Metoda 3: Bilinear s filtriranjem');

for i = 1:length(scales)
    s = scales(i);

    img_bl_aa = imresize(frame, s, ...
        'bilinear', 'Antialiasing', true);

    subplot(3,3,i+6);
    imshow(img_bl_aa);
    title(['Bilinear z AA, faktor = ', num2str(s)]);
    
    imwrite(img_bl_aa, ...
        ['BL_AA_scale_', num2str(s*100), '.png']);
end
