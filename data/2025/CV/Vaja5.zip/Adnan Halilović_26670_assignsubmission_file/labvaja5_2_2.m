%% Vaja 5 – 2.2: Sledenje igralca (Histogram + chi2) 
clear; close all; clc;

%% Branje videa
videoFile = 'squash.avi';
v = VideoReader(videoFile);

frameRGB = read(v,1);
frameGray = rgb2gray(frameRGB);

figure(1);
imshow(frameGray);
title('Z dvema klikoma oznaci igralca');
[x, y] = ginput(2);

x = round(x); y = round(y);
x1 = min(x); x2 = max(x);
y1 = min(y); y2 = max(y);

w = x2 - x1;
h = y2 - y1;

template = frameGray(y1:y2, x1:x2);

%% Histogram značilnica
numBins = 16;   % malo binov = stabilno
templateHist = imhist(template, numBins);
templateHist = templateHist / sum(templateHist);

%% Parametri
epsilon = 15;
numFrames = 150;

%% Izhodni video
writer = VideoWriter('sledenje_histogram_simple.avi');
open(writer);

prevX = x1;
prevY = y1;
k = 1;

%% Glavna zanka
while hasFrame(v)
    
    frameRGB = read(v, k);
    frameGray = rgb2gray(frameRGB);

    bestDist = inf;
    bestX = prevX;
    bestY = prevY;

    for dx = -epsilon:epsilon
        for dy = -epsilon:epsilon
            x = prevX + dx;
            y = prevY + dy;

            if x < 1 || y < 1 || ...
               x+w > size(frameGray,2) || ...
               y+h > size(frameGray,1)
                continue;
            end

            patch = frameGray(y:y+h, x:x+w);
            patchHist = imhist(patch, numBins);
            patchHist = patchHist / sum(patchHist);

            % chi2 razdalja
            chi2 = sum((patchHist - templateHist).^2);

            if chi2 < bestDist
                bestDist = chi2;
                bestX = x;
                bestY = y;
            end
        end
    end

    prevX = bestX;
    prevY = bestY;

    figure(1);
    imshow(frameRGB);
    hold on;
    rectangle('Position',[bestX bestY w h], ...
              'EdgeColor','g', 'LineWidth', 2);
    hold off;

    F = getframe(gca);
    writeVideo(writer, F);
    k = k + 1;
end

close(writer);

