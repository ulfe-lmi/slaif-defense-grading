%% Vaja 5 – 2.3: Sledenje igralca (RGB histogram + Bhattacharyya)
clear; close all; clc;

v = VideoReader('squash.avi');

frameRGB = readFrame(v);

figure(1); imshow(frameRGB);
title('Z dvema klikoma oznaci igralca');
[x, y] = ginput(2);

x = round(x); y = round(y);
x1 = min(x); x2 = max(x);
y1 = min(y); y2 = max(y);

w = x2 - x1;
h = y2 - y1;

template = frameRGB(y1:y2, x1:x2, :);

%% Histogram značilnica (RGB posebej)
numBins = 16;
templateHist = rgbHist(template, numBins);

%% Parametri
epsilon = 15;   
alpha = 0.05;      % update histogram 


writer = VideoWriter('sledenje_hist_bhatt_RGB.avi');
open(writer);

prevX = x1;
prevY = y1;
k = 1;

while hasFrame(v) 
    frameRGB = readFrame(v);

    bestCost = inf;
    bestX = prevX;
    bestY = prevY;

    for dx = -epsilon:epsilon
        for dy = -epsilon:epsilon
            x = prevX + dx;
            y = prevY + dy;

            if x < 1 || y < 1 || ...
               x+w > size(frameRGB,2) || ...
               y+h > size(frameRGB,1)
                continue;
            end

            patch = frameRGB(y:y+h, x:x+w, :);
            patchHist = rgbHist(patch, numBins);

            % Bhattacharyya distance
            bc = sum(sqrt(patchHist .* templateHist));
            dist = 1 - bc;

            % kazen za velike premike 
            motionPenalty = 1e-4 * (dx^2 + dy^2);
            cost = dist + motionPenalty;

            if cost < bestCost
                bestCost = cost;
                bestX = x;
                bestY = y;
            end
        end
    end

    prevX = bestX;
    prevY = bestY;

    % Posodabljanje histograma 
    if alpha > 0
        newPatch = frameRGB(bestY:bestY+h, bestX:bestX+w, :);
        newHist = rgbHist(newPatch, numBins);
        templateHist = (1-alpha)*templateHist + alpha*newHist;
        templateHist = templateHist / sum(templateHist);
    end

    imshow(frameRGB); hold on;
    rectangle('Position',[bestX bestY w h], 'EdgeColor','b','LineWidth',2);
    hold off;

    writeVideo(writer, getframe(gca));
    k = k + 1;
end

close(writer);
disp('Histogram Bhattacharyya (RGB) sledenje koncano');

%% -------- lokalna funkcija --------
function h = rgbHist(imgRGB, numBins)
    imgRGB = uint8(imgRGB);

    r = imgRGB(:,:,1);
    g = imgRGB(:,:,2);
    b = imgRGB(:,:,3);

    hr = imhist(r, numBins);
    hg = imhist(g, numBins);
    hb = imhist(b, numBins);

    h = double([hr; hg; hb]);
    h = h / sum(h);
end
