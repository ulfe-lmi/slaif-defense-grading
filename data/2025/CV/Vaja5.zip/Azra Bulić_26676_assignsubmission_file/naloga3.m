clear; clc; close all;


videoFile = 'squash.avi';
outFile   = 'squash_tracking_3.avi';

numBins = 32;      % število binov histograma
epsilon = 20;      % velikost lokalnega iskanja
alpha   = 0.05;    % faktor učenja (ONLINE LEARNING)
useGray = true;    % sivinski prostor


vid = VideoReader(videoFile);
writer = VideoWriter(outFile);
open(writer);


frame = readFrame(vid);

if useGray
    frameGray = rgb2gray(frame);
else
    frameGray = frame;
end

figure; imshow(frameGray);
title('Z dvema klikoma označi igralca');
[x, y] = ginput(2);

x = round(x);
y = round(y);

x0 = min(x);
y0 = min(y);
w  = abs(x(2) - x(1));
h  = abs(y(2) - y(1));

template = frameGray(y0:y0+h, x0:x0+w);
refHist = compute_hist(template, numBins);

pos = [x0 y0];

frameOut = insertShape(frame, 'Rectangle', [pos w h], ...
    'Color', 'red', 'LineWidth', 2);
writeVideo(writer, frameOut);


while hasFrame(vid)

    frame = readFrame(vid);

    if useGray
        frameGray = rgb2gray(frame);
    else
        frameGray = frame;
    end

    bestDist = inf;
    bestPos  = pos;

   
    for dx = -epsilon:epsilon
        for dy = -epsilon:epsilon

            xTest = pos(1) + dx;
            yTest = pos(2) + dy;

            if xTest < 1 || yTest < 1 || ...
               xTest+w > size(frameGray,2) || ...
               yTest+h > size(frameGray,1)
                continue;
            end

            patch = frameGray(yTest:yTest+h, xTest:xTest+w);
            patchHist = compute_hist(patch, numBins);

            dist = chi2_distance(refHist, patchHist);

            if dist < bestDist
                bestDist = dist;
                bestPos = [xTest yTest];
            end
        end
    end

   
    pos = bestPos;

   
    patch = frameGray(pos(2):pos(2)+h, pos(1):pos(1)+w);
    currentHist = compute_hist(patch, numBins);

    refHist = (1 - alpha) * refHist + alpha * currentHist;
   
    frameOut = insertShape(frame, 'Rectangle', ...
        [pos w h], 'Color', 'green', 'LineWidth', 2);
    writeVideo(writer, frameOut);
end

close(writer);
disp('Sledenje s sprotnim učenjem končano.');



function h = compute_hist(img, numBins)
    img = double(img);
    h = histcounts(img(:), numBins, 'Normalization', 'probability');
end

function d = chi2_distance(h1, h2)
    eps = 1e-10;
    d = sum(((h1 - h2).^2) ./ (h1 + h2 + eps));
end
