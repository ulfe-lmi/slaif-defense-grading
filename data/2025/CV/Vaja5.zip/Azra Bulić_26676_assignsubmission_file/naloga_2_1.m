vid = VideoReader('squash.avi');

% Prvi frame i ručno biranje pravougaonika
firstFrame = readFrame(vid);
figure; 
imshow(firstFrame); 
title('Klikni 2 ugla pravougaonika oko igraca');

[x, y] = ginput(2);
x = round(x); 
y = round(y);

x1 = max(1, min(x)); 
x2 = min(size(firstFrame,2), max(x));
y1 = max(1, min(y)); 
y2 = min(size(firstFrame,1), max(y));

w = x2 - x1 + 1;
h = y2 - y1 + 1;

% Pretvori u sivu i uzmi template
if size(firstFrame,3) == 3
    firstGray = rgb2gray(firstFrame);
else
    firstGray = firstFrame;
end
templ = double(firstGray(y1:y2, x1:x2));

% Parametar lokalne pretrage (epsilon)
eps = 6;  % podesi eksperimentalno

% Izlazni video
outFile = 'squash_track_L2.avi';
vw = VideoWriter(outFile);
vw.FrameRate = vid.FrameRate;
open(vw);

% Trenutna procjena pozicije (gornji lijevi ugao)
px = x1;
py = y1;

% Vrati video na početak i obradi sve frameove
vid.CurrentTime = 0;

while hasFrame(vid)
    frame = readFrame(vid);

    % siva slika
    if size(frame,3) == 3
        gray = rgb2gray(frame);
    else
        gray = frame;
    end
    grayD = double(gray);

    % Lokalno područje pretrage oko (px,py)
    xs = max(1, px - eps);
    ys = max(1, py - eps); %lijeva i gornja granica pretrage
    xe = min(size(gray,2) - w + 1, px + eps);
    ye = min(size(gray,1) - h + 1, py + eps); %desna i donja granica pretrage

    bestD = inf; %najveca moguca udaljenost
    bestX = px; 
    bestY = py;

    % Traži minimum L2 udaljenosti
    for yy = ys:ye
        for xx = xs:xe %xx i yy gdje bi igrac mogao biti u trenutnom frameu
            patch = grayD(yy:yy+h-1, xx:xx+w-1); %patch je istih dimenzija kao moj odabrani templ
            d = sum((patch(:) - templ(:)).^2);   % L2^2 (dovoljno, sqrt ne treba)
            if d < bestD %trazenje najmanjeg d
                bestD = d;
                bestX = xx;
                bestY = yy;
            end
        end
    end

    % Update pozicije
    px = bestX;
    py = bestY;

    % Ucrtavanje pravougaonika
    frameOut = insertShape(frame, 'Rectangle', [px py w h], 'LineWidth', 3);

    writeVideo(vw, frameOut);
end

close(vw);