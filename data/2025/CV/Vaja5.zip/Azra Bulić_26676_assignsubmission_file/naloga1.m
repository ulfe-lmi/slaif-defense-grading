vid = VideoReader('Holywood.avi');

% Skale i metode (3x3 = 9 videa)
scales = [0.5, 0.25, 0.125];

methods = {
    struct('tag','nearest','method','nearest',  'aa',[]), struct('tag','bilinear_AAoff','method','bilinear', 'aa',false), struct('tag','bilinear_AAon','method','bilinear', 'aa',true)
    };

% Napravi 9 writer-a
writers = cell(numel(scales), numel(methods));
for s = 1:numel(scales)
    for m = 1:numel(methods)
        outFile = sprintf('%s_%g.avi', methods{m}.tag, scales(s));
        vw = VideoWriter(outFile);
        vw.FrameRate = vid.FrameRate;   % zadrži originalni FPS
        open(vw);
        writers{s,m} = vw;
    end
end

% Obradi video frame po frame
vid.CurrentTime = 0;
while hasFrame(vid) %vrati video na pocetak i obradi frame po frame
    frame = readFrame(vid);  % uint8 HxWx3

    for s = 1:numel(scales)
        scale = scales(s);

        for m = 1:numel(methods)
            meth = methods{m};

            if strcmp(meth.method,'nearest')
                frameSmall = imresize(frame, scale, 'nearest');
            else
                frameSmall = imresize(frame, scale, 'bilinear', 'Antialiasing', meth.aa);
            end

            writeVideo(writers{s,m}, frameSmall);
        end
    end
end

% Zatvori sve
for s = 1:numel(scales)
    for m = 1:numel(methods)
        close(writers{s,m});
    end
end
