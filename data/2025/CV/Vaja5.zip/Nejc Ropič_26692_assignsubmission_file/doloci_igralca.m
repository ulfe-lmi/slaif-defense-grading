clc;
clear;
close all;

% 1. NALOŽI VIDEO
% ===============================
video = VideoReader('squash.avi');

firstFrame = readFrame(video);

%% za rocno izbiro
figure;
imshow(firstFrame);
title('Z dvema klikoma označi igralca');

% 2. IZBIRA PREDLOGE
% ===============================
[x, y] = ginput(2);
%% shranjena referenca
x = [110; 121];
y = [120; 131];
%%
x = round(x);
y = round(y);

x1 = min(x);
x2 = max(x);
y1 = min(y);
y2 = max(y);

w = x2 - x1;
h = y2 - y1;

templateRGB = firstFrame(y1:y2, x1:x2, :);
template = rgb2gray(templateRGB);
