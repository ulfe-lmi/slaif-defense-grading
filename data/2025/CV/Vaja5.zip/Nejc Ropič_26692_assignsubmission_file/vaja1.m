scales = [1/2, 1/4, 1/8];
methods = {'nearest', 'bilinear', 'bilinear'};
aa = [false, false, true];   % antialising izkljucn

for m = 1:length(methods)
    for s = 1:length(scales)

        scale = scales(s);

        vidIn = VideoReader('Holywood2-t00427-rgb.avi');

        outName = sprintf('out_%s_AA%d_scale_%g.avi', ...
                          methods{m}, aa(m), scale);

        vidOut = VideoWriter(outName);
        vidOut.FrameRate = vidIn.FrameRate;
        open(vidOut);

        while hasFrame(vidIn)
            frame = readFrame(vidIn);

            % pomanjšanje z imresize
            frame_resized = imresize( ...
                frame, scale, methods{m}, 'Antialiasing', aa(m));

            writeVideo(vidOut, frame_resized);
        end

        close(vidOut);
    end
end
