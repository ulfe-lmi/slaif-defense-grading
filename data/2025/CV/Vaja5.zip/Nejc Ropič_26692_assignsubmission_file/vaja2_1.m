%% 2.1
video = VideoReader('squash.avi');
readFrame(video);   

epsilon = 10;

prevX = x1;
prevY = y1;

writer = VideoWriter('sledenje_L2.avi');
open(writer);

figure;
imshow(firstFrame);
hold on;
rectangle('Position', [prevX prevY w h], ...
          'EdgeColor', 'r', 'LineWidth', 2);
hold off;

F = getframe(gca);
writeVideo(writer, F.cdata);

while hasFrame(video)

    frame = readFrame(video);
    frameGray = rgb2gray(frame);

    bestDist = inf;
    bestX = prevX;
    bestY = prevY;

    xMin = max(1, prevX - epsilon);
    xMax = min(size(frameGray,2) - w, prevX + epsilon);
    yMin = max(1, prevY - epsilon);
    yMax = min(size(frameGray,1) - h, prevY + epsilon);

    for i = xMin:xMax
        for j = yMin:yMax

            patch = frameGray(j:j+h, i:i+w);

            dist = sum((double(patch(:)) - double(template(:))).^2);

            if dist < bestDist
                bestDist = dist;
                bestX = i;
                bestY = j;
            end
        end
    end

    prevX = bestX;
    prevY = bestY;

    % izris
    figure(1);
    imshow(frame);
    hold on;
    rectangle('Position', [bestX bestY w h], ...
              'EdgeColor', 'r', 'LineWidth', 2);
    hold off;

    F = getframe(gca);
    writeVideo(writer, F.cdata);
    drawnow;
end

close(writer);

