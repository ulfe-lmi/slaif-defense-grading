%% 2.2
video = VideoReader('squash.avi');
readFrame(video);   

prevX = x1;
prevY = y1;

writer = VideoWriter('sledenje_chi2.avi');
open(writer);

nbins = 32;
templateHist = imhist(template, nbins);
templateHist = templateHist / sum(templateHist);

while hasFrame(video)

    frame = readFrame(video);
    frameGray = rgb2gray(frame);

    bestDist = inf;
    bestX = prevX;
    bestY = prevY;

    xMin = max(1, prevX - epsilon);
    xMax = min(size(frameGray,2) - w, prevX + epsilon);
    yMin = max(1, prevY - epsilon);
    yMax = min(size(frameGray,1) - h, prevY + epsilon);

    for i = xMin:xMax
        for j = yMin:yMax

            patch = frameGray(j:j+h, i:i+w);
            patchHist = imhist(patch, nbins);
            patchHist = patchHist / sum(patchHist);

            dist = sum((templateHist - patchHist).^2 ./ ...
                       (templateHist + patchHist + eps));

            if dist < bestDist
                bestDist = dist;
                bestX = i;
                bestY = j;
            end
        end
    end

    prevX = bestX;
    prevY = bestY;

    imshow(frame); hold on;
    rectangle('Position',[bestX bestY w h], ...
              'EdgeColor','r','LineWidth',2);
    hold off;

    F = getframe(gca);
    writeVideo(writer, F.cdata);
    drawnow;
end

close(writer);
disp('Video uspešno shranjen: sledenje_chi2.avi');
