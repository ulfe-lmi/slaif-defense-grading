epsilon = 10;
nbins = 32;
alpha = 0.05;   % hitrost učenja

prevX = x1;
prevY = y1;

% referencni histogram
templateHist = imhist(template, nbins);
templateHist = templateHist / sum(templateHist);

writer = VideoWriter('sledenje_chi2_ucenje.avi');
open(writer);

video = VideoReader('squash.avi');
readFrame(video);

while hasFrame(video)

    frame = readFrame(video);
    frameGray = rgb2gray(frame);

    bestDist = inf;
    bestX = prevX;
    bestY = prevY;

    xMin = max(1, prevX - epsilon);
    xMax = min(size(frameGray,2) - w, prevX + epsilon);
    yMin = max(1, prevY - epsilon);
    yMax = min(size(frameGray,1) - h, prevY + epsilon);

    for i = xMin:xMax
        for j = yMin:yMax

            patch = frameGray(j:j+h, i:i+w);
            patchHist = imhist(patch, nbins);
            patchHist = patchHist / sum(patchHist);

            dist = sum((templateHist - patchHist).^2 ./ ...
                       (templateHist + patchHist + eps));

            if dist < bestDist
                bestDist = dist;
                bestX = i;
                bestY = j;
            end
        end
    end

    % nova pozicija
    prevX = bestX;
    prevY = bestY;

    % ucenje sproti
    newPatch = frameGray(bestY:bestY+h, bestX:bestX+w);
    newHist = imhist(newPatch, nbins);
    newHist = newHist / sum(newHist);

    templateHist = (1 - alpha)*templateHist + alpha*newHist;
    templateHist = templateHist / sum(templateHist);

    % plotanje
    imshow(frame); hold on;
    rectangle('Position',[bestX bestY w h], ...
              'EdgeColor','r','LineWidth',2);
    hold off;

    F = getframe(gca);
    writeVideo(writer, F.cdata);
    drawnow;
end

close(writer);
disp('Video uspešno shranjen: sledenje_chi2_ucenje.avi');
