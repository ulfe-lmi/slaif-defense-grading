function interpolacija(vhodni_video, izhodni_video, faktor_skaliranja, metoda)
% uporabnik vnese ime vhodne datoteke, ime izhodne datoteke, faktor skaliranja in metodo interpolacije
% imeni vhodne in izhodne datoteke sta tipa string
% faktor skaliranja je številski npr. double
% METODA MORA BITI PODANA NA ENEGA IZMED TEH TREH NAČINOV: 'nearest', 'bilinear_aa_off', 'bilinear_aa_on'


    metoda = string(lower(metoda));             % lower za vsak slučaj naredi vnos neobčutljiv na male in velike črke
    
    video = VideoReader(vhodni_video);

    interpoliran_video = VideoWriter(izhodni_video);
    interpoliran_video.FrameRate = video.FrameRate;
    open(interpoliran_video)

    while hasFrame(video)
        frame = readFrame(video);

        if metoda == 'nearest'
            interpoliran_frame = imresize(frame, faktor_skaliranja, 'nearest');

        elseif metoda == 'bilinear_aa_off'
            interpoliran_frame = imresize(frame, faktor_skaliranja, 'bilinear', 'Antialiasing', false);

        elseif metoda == 'bilinear_aa_on'
            interpoliran_frame = imresize(frame, faktor_skaliranja, 'bilinear', 'Antialiasing', true);
        end
            
        writeVideo(interpoliran_video, interpoliran_frame);
    end

    close(interpoliran_video)
end


