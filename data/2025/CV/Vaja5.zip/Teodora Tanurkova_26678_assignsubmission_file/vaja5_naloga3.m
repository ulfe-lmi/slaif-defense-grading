%% Naloga 3 evklidska razd

Video2 = VideoReader('squash5.avi');
vsiOkviri = Video2.NumFrames;

frame1 = read(Video2,1);
figure;
imshow(frame1);
title('Izberi igralca (Naloga 3 – L2)');

[znacilkaRGB, bbox] = imcrop(frame1);
bbox = round(bbox);

znacilka = rgb2gray(znacilkaRGB);
w = bbox(3);
h = bbox(4);

eps = 20;

out = VideoWriter('squash_EVKLIDNaloga3.avi');
open(out);

for k = 1:vsiOkviri
    frame = read(Video2, k);
    gray  = rgb2gray(frame);

    xMin = max(1, bbox(1) - eps);
    yMin = max(1, bbox(2) - eps);
    xMax = min(size(gray,2)-w+1, bbox(1)+eps);
    yMax = min(size(gray,1)-h+1, bbox(2)+eps);

    bestD = inf;

    for y = yMin:yMax
        for x = xMin:xMax
            izsek = gray(y:y+h-1, x:x+w-1);
            dif = double(izsek) - double(znacilka);
            d = sum(dif(:).^2);

            if d < bestD
                bestD = d;
                bbox(1) = x;
                bbox(2) = y;
            end
        end
    end

    znacilka = gray(bbox(2):bbox(2)+h-1, bbox(1):bbox(1)+w-1);

    frameOut = insertShape(frame, 'Rectangle', bbox, 'LineWidth', 2);
    writeVideo(out, frameOut);
end

close(out);

%% Naloga 3 

Video3 = VideoReader('squash5.avi');
vsiOkviri3 = Video3.NumFrames;

% 1) Prva slika + izbor igralca
frame1 = read(Video3, 1);
figure; 
imshow(frame1);
title('Izberi igralca (Naloga 3 – χ^2)');

[znacilkaRGB3, bbox3] = imcrop(frame1);
bbox3 = round(bbox3);

znacilka3 = rgb2gray(znacilkaRGB3);
w3 = bbox3(3);
h3 = bbox3(4);

eps3 = 18;
nbins = 32;
binSize = 256 / nbins;

refHist = myHistGray(znacilka3, nbins, binSize);
refHist = refHist / sum(refHist);

out3 = VideoWriter('squash_CHI2Naloga3.avi');
open(out3);

for k = 1:vsiOkviri3

    frame = read(Video3, k);
    gray  = rgb2gray(frame);

    xMin = max(1, bbox3(1) - eps3);
    yMin = max(1, bbox3(2) - eps3);
    xMax = min(size(gray,2) - w3 + 1, bbox3(1) + eps3);
    yMax = min(size(gray,1) - h3 + 1, bbox3(2) + eps3);

    bestD = inf;

    for y = yMin:yMax
        for x = xMin:xMax
            izsek = gray(y:y+h3-1, x:x+w3-1);

            hst = myHistGray(izsek, nbins, binSize);
            hst = hst / sum(hst);

            d = 0.5 * sum(((refHist - hst).^2) ./ (refHist + hst + 1e-10));

            if d < bestD
                bestD = d;
                bbox3(1) = x;
                bbox3(2) = y;
            end
        end
    end

    noviIzsek = gray(bbox3(2):bbox3(2)+h3-1, bbox3(1):bbox3(1)+w3-1);
    refHist = myHistGray(noviIzsek, nbins, binSize);
    refHist = refHist / sum(refHist);

    frameOut = insertShape(frame, 'Rectangle', bbox3, 'LineWidth', 2);
    writeVideo(out3, frameOut);
end

close(out3);

%% ročni histogram sivinske slike 
function h = myHistGray(I, nbins, binSize)
    h = zeros(1, nbins);
    pixels = I(:);

    for i = 1:numel(pixels)
        bin = floor(double(pixels(i)) / binSize) + 1;
        if bin > nbins
            bin = nbins;
        end
        h(bin) = h(bin) + 1;
    end
end
