clear all;
squash=VideoReader("squash.avi");
frames=read(squash,[1 Inf]);
velikost_videa=size(frames);

imshow(frames(:,:,:,1));
[y_zac,x_zac]=ginput(2);
y_zac=floor(y_zac);
x_zac=floor(x_zac);
znacilka_evk3=frames(x_zac(1):x_zac(2),y_zac(1):y_zac(2),:,1);
velikost_znacilke_evk3=size(znacilka_evk3);

%imshow(znacilka_evk);
eps=25;
sred_x=floor(x_zac(1)+(x_zac(2)-x_zac(1))/2);
sred_y=floor(y_zac(1)+(y_zac(2)-y_zac(1))/2);

%i=3;  %samo za teste
for i=1:velikost_videa(4)
    okolica=frames((sred_y-eps):(sred_y+eps),(sred_x-eps):(sred_x+eps),:,i);
    velikost_okolice=size(okolica);
    
    for y=1:(velikost_okolice(2)-velikost_znacilke_evk3(2))
        for x=1:(velikost_okolice(1)-velikost_znacilke_evk3(1))
            evk(x,y)=mean(sqrt(sum((double(double(znacilka_evk3)-double(okolica(x:(x+velikost_znacilke_evk3(1)-1),y:(y+velikost_znacilke_evk3(2)-1),:)))).^2)),"all");
        end
    end
    
    minimum=min(min(evk));
    [poz1, poz2]=find(evk==minimum);
    sred_x=poz2-eps+sred_x(1)+floor(velikost_znacilke_evk3(2)/2);
    sred_y=poz1-eps+sred_y(1)+floor(velikost_znacilke_evk3(1)/2);
    
    koncna_slika_evk3(:,:,:,i)=insertShape(frames(:,:,:,i),"Circle",[sred_x(1) sred_y(1) 20],'LineWidth',3);
    %imshow(koncna_slika_evk3(:,:,:,i));   %samo za teste
    
    znacilka_evk3=okolica((poz1(1)):(poz1(1)+velikost_znacilke_evk3(1)-1),(poz2(1)):(poz2(1)+velikost_znacilke_evk3(2)-1),:);
    %imshow(znacilka_evk3);
end

writerObj=VideoWriter('3_naloga.avi');
writerObj.FrameRate=25;
open(writerObj);
writeVideo(writerObj,cast(koncna_slika_evk3,'uint8'));
close(writerObj);
