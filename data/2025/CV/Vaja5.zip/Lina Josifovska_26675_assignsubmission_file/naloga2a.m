clear all;
squash=VideoReader("squash.avi");
frames=read(squash,[1 Inf]);
velikost_videa=size(frames);

imshow(frames(:,:,:,1));
[y_zac,x_zac]=ginput(2);
y_zac=floor(y_zac);
x_zac=floor(x_zac);
znacilka_evk=frames(x_zac(1):x_zac(2),y_zac(1):y_zac(2),:,1);
velikost_znacilke_evk=size(znacilka_evk);
%imshow(znacilka_evk);

eps=35;
sred_x=x_zac(1);
sred_y=y_zac(2);

%i=3;  %samo za teste
for i=1:velikost_videa(4)
    okolica=frames((sred_y-eps):(sred_y+eps),(sred_x-eps):(sred_x+eps),:,i);
    velikost_okolice=size(okolica);
    
    for y=1:(velikost_okolice(2)-velikost_znacilke_evk(2))
        for x=1:(velikost_okolice(1)-velikost_znacilke_evk(1))
            evk(x,y)=mean(sqrt(sum((double(double(znacilka_evk)-double(okolica(x:(x+velikost_znacilke_evk(1)-1),y:(y+velikost_znacilke_evk(2)-1),:)))).^2)),"all");
        end
    end
    
    minimum=min(min(evk));
    [poz1, poz2]=find(evk==minimum);
    sred_x=poz2-eps+sred_x+floor(velikost_znacilke_evk(2)/2);
    sred_y=poz1-eps+sred_y+floor(velikost_znacilke_evk(1)/2);
    
    koncna_slika_evk(:,:,:,i)=insertShape(frames(:,:,:,i),"Circle",[sred_x sred_y 20],'LineWidth',3);
    %imshow(koncna_slika_evk(:,:,:,i));   %samo za teste
end

writerObj=VideoWriter('2a_naloga.avi');
writerObj.FrameRate=25;
open(writerObj);
writeVideo(writerObj,cast(koncna_slika_evk,'uint8'));
close(writerObj);