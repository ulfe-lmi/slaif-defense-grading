function histogram=poisci_histogram(vzorec)
    dim_vzorca=size(vzorec);
    histogram=zeros(8,8,8);
    for R_vrednost=0:32:224
        for G_vrednost=0:32:224
            for B_vrednost=0:32:224
                for j=1:dim_vzorca(2)
                    for i=1:dim_vzorca(1)
                        if ((vzorec(i,j,1)>=R_vrednost) && (vzorec(i,j,1)<=(R_vrednost+31)) && (vzorec(i,j,2)>=G_vrednost) && (vzorec(i,j,2)<=(G_vrednost+31)) && (vzorec(i,j,3)>=B_vrednost) && (vzorec(i,j,3)<=(B_vrednost+31)))
                            histogram((R_vrednost/32)+1,(G_vrednost/32)+1,(B_vrednost/32)+1)=histogram((R_vrednost/32)+1,(G_vrednost/32)+1,(B_vrednost/32)+1)+1;
                        end
                    end
                end
            end
        end
    end
end