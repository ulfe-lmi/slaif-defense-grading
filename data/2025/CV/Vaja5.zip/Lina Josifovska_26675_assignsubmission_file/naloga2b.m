clear all;
squash=VideoReader("squash.avi");
frames=read(squash,[1 Inf]);
velikost_videa=size(frames);

imshow(frames(:,:,:,1));
[y_zac,x_zac]=ginput(2);
y_zac=floor(y_zac);
x_zac=floor(x_zac);
znacilka_hi=frames(x_zac(1):x_zac(2),y_zac(1):y_zac(2),:,1);
velikost_znacilke_hi=size(znacilka_hi);
%imshow(znacilka_hi);

histogram_znacilke_hi=poisci_histogram(znacilka_hi);
max_vrednost_hist=max(max(max(histogram_znacilke_hi)));
koef=255/max_vrednost_hist;
for i=1:8
    for j=1:8
        for k=1:8
            histogram_znacilke_hi_norm(i,j,k)=floor((histogram_znacilke_hi(i,j,k)*koef));
        end
    end
end

eps=35;
sred_x=x_zac(1);
sred_y=y_zac(2);

%i=5;  %samo za teste
for i=1:250
    okolica=frames((sred_y-eps):(sred_y+eps),(sred_x-eps):(sred_x+eps),:,i);
    velikost_okolice=size(okolica);
    
    for y=1:(velikost_okolice(2)-velikost_znacilke_hi(2))
        for x=1:(velikost_okolice(1)-velikost_znacilke_hi(1))
            opazovani_del_okolice=okolica(x:(x+velikost_znacilke_hi(1)-1),y:(y+velikost_znacilke_hi(2)-1),:);
            histogram_opa_dela=poisci_histogram(opazovani_del_okolice);
            
            max_vrednost_hist=max(max(max(histogram_opa_dela)));
            koef=255/max_vrednost_hist;
            for m=1:8
                for j=1:8
                    for k=1:8
                        histogram_opa_dela_norm(m,j,k)=floor((histogram_opa_dela(m,j,k)*koef));
                    end
                end
            end
            
            hi_kvadrat(x,y)=sum((histogram_opa_dela_norm-histogram_znacilke_hi_norm).^2,'all');
            
        end
    end
    
    minimum=min(min(hi_kvadrat));
    [poz1, poz2]=find(hi_kvadrat==minimum);
    sred_x=poz2(1)-eps+sred_x(1)+floor(velikost_znacilke_hi(2)/2);
    sred_y=poz1(1)-eps+sred_y(1)+floor(velikost_znacilke_hi(1)/2);
    
    koncna_slika_hi(:,:,:,i)=insertShape(frames(:,:,:,i),"Circle",[sred_x(1) sred_y(1) 20],'LineWidth',3,"Color",'green');
    %imshow(koncna_slika_hi(:,:,:,i));  %samo za teste
end

writerObj=VideoWriter('2b_naloga.avi');
writerObj.FrameRate=25;
open(writerObj);
writeVideo(writerObj,cast(koncna_slika_hi,'uint8'));
close(writerObj);