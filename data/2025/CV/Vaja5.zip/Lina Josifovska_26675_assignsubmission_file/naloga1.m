holywood=VideoReader("Holywood.avi");
frames=read(holywood,[1 Inf]);
velikost_videa=size(frames);

for i=1:velikost_videa(4)
    holywood_neighbor_pol(:,:,:,i)=imresize(frames(:,:,:,i),1/2,'nearest');
    holywood_neighbor_cet(:,:,:,i)=imresize(frames(:,:,:,i),1/4,'nearest');
    holywood_neighbor_osm(:,:,:,i)=imresize(frames(:,:,:,i),1/8,'nearest');
    holywood_bi_pol(:,:,:,i)=imresize(frames(:,:,:,i),1/2,'bilinear','Antialiasing',false);
    holywood_bi_cet(:,:,:,i)=imresize(frames(:,:,:,i),1/4,'bilinear','Antialiasing',false);
    holywood_bi_osm(:,:,:,i)=imresize(frames(:,:,:,i),1/8,'bilinear','Antialiasing',false);
    holywood_predbi_pol(:,:,:,i)=imresize(frames(:,:,:,i),1/2,'bilinear','Antialiasing',true);
    holywood_predbi_cet(:,:,:,i)=imresize(frames(:,:,:,i),1/4,'bilinear','Antialiasing',true);
    holywood_predbi_osm(:,:,:,i)=imresize(frames(:,:,:,i),1/8,'bilinear','Antialiasing',true);
end

writerObj=VideoWriter('1_naloga_neighbor_pol.avi');
writerObj.FrameRate=25;
open(writerObj);
writeVideo(writerObj,cast(holywood_neighbor_pol,'uint8'));
close(writerObj);

writerObj=VideoWriter('1_naloga_neighbor_cet.avi');
writerObj.FrameRate=25;
open(writerObj);
writeVideo(writerObj,cast(holywood_neighbor_cet,'uint8'));
close(writerObj);

writerObj=VideoWriter('1_naloga_neighbor_osm.avi');
writerObj.FrameRate=25;
open(writerObj);
writeVideo(writerObj,cast(holywood_neighbor_osm,'uint8'));
close(writerObj);

writerObj=VideoWriter('1_naloga_bi_pol.avi');
writerObj.FrameRate=25;
open(writerObj);
writeVideo(writerObj,cast(holywood_bi_pol,'uint8'));
close(writerObj);

writerObj=VideoWriter('1_naloga_bi_cet.avi');
writerObj.FrameRate=25;
open(writerObj);
writeVideo(writerObj,cast(holywood_bi_cet,'uint8'));
close(writerObj);

writerObj=VideoWriter('1_naloga_bi_osm.avi');
writerObj.FrameRate=25;
open(writerObj);
writeVideo(writerObj,cast(holywood_bi_osm,'uint8'));
close(writerObj);

writerObj=VideoWriter('1_naloga_predbi_pol.avi');
writerObj.FrameRate=25;
open(writerObj);
writeVideo(writerObj,cast(holywood_predbi_pol,'uint8'));
close(writerObj);

writerObj=VideoWriter('1_naloga_predbi_cet.avi');
writerObj.FrameRate=25;
open(writerObj);
writeVideo(writerObj,cast(holywood_predbi_cet,'uint8'));
close(writerObj);

writerObj=VideoWriter('1_naloga_predbi_osm.avi');
writerObj.FrameRate=25;
open(writerObj);
writeVideo(writerObj,cast(holywood_predbi_osm,'uint8'));
close(writerObj);