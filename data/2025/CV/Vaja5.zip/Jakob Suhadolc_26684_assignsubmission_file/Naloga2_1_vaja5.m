clear; clc;

videoIn  = VideoReader('squash.avi');     
videoOut = VideoWriter('track2.avi');     
open(videoOut);                           

firstFrame = readFrame(videoIn);   %uzami prvi frame in ga prikazi
imshow(firstFrame);                    
selection = round(getrect);  %izberemo pravokotnik [x y w h]

%izrez predloge igralca iz prvega frema  
template = firstFrame( ...   
    selection(2):selection(2)+selection(4)-1, ...
    selection(1):selection(1)+selection(3)-1, :);

posX = selection(1); posY = selection(2); %zacetna pozicija pravokotnika
tplWidth = selection(3); tplHeight = selection(4); %velikost pravokotnika
searchRadius = 15;   % epsilon, lokalno iskanje, uzamemo 20 pikselov okol

while hasFrame(videoIn)   %cez vse naslednje frame-e
    currentFrame = readFrame(videoIn);
    
    %zacetne najbolse vrednosti
    minError = inf; 
    bestX = posX; 
    bestY = posY; 

    % meje iskalnega okna (da ne gremo izven slike)
    yMin = max(1, posY - searchRadius);
    yMax = min(size(currentFrame,1) - tplHeight + 1, posY + searchRadius);
    xMin = max(1, posX - searchRadius);
    xMax = min(size(currentFrame,2) - tplWidth + 1, posX + searchRadius);

    %preizkusimo vse kandidate v okolici
    for y = yMin:yMax
        for x = xMin:xMax
            candidate = currentFrame(y:y+tplHeight-1, x:x+tplWidth-1, :); %kandidatni patch
            diff = double(candidate) - double(template); %razlika do template
            error = sum(diff(:).^2);   % L2^2 (manj-bolj podobno)

            if error < minError %shrani najboljsi kandidat
                minError = error; bestX = x; bestY = y;
            end
        end
    end

    posX = bestX; posY = bestY;            % posodobi lokacijo objekta
    outputFrame = insertShape(currentFrame,'Rectangle',... % narisi bbox
        [posX posY tplWidth tplHeight],'Color','red');

    writeVideo(videoOut, outputFrame);     % shrani frame v izhodni video
end

close(videoOut);                           % zapri izhodni video
