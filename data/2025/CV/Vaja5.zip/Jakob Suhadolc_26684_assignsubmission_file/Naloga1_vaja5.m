%% Naloga 1 - Podvzorcenje slik
clear; clc;
v = VideoReader('Holywood.avi');

scale = [0.5, 0.25, 0.125];  
methods = {'nearest', 'bilinear', 'bilinear_prefilter'}; 

for i = 1:length(methods)           % izbira metode
    for j = 1:length(scale)         % izbira faktorja

        v.CurrentTime = 0;    
        outName = sprintf('out_%s_%dx.avi', methods{i}, round(1/scale(j)));
        w = VideoWriter(outName);   % pripravi zapisovanje
        open(w);

        while hasFrame(v)           % gre cez vse framee
            frame = readFrame(v);   % preberi en frame

            if i == 1
                resized = imresize(frame, scale(j), 'nearest'); % nearest neighbor
            elseif i == 2
                resized = imresize(frame, scale(j), 'bilinear', 'Antialiasing', false); % bilinear brez AA
            else
                resized = imresize(frame, scale(j), 'bilinear', 'Antialiasing', true);  % bilinear z AA
            end

            writeVideo(w, resized); % shrani frame v izhodni video
        end

        close(w);                   
    end
end
