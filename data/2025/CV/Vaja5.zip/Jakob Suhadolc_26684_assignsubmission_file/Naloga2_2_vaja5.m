clear; clc;

videoIn  = VideoReader('squash.avi');          
videoOut = VideoWriter('track2_chi2.avi');     
open(videoOut);

firstFrame = readFrame(videoIn);   %uzami prvi frame in ga prikazi
imshow(firstFrame);                    
selection = round(getrect);  %izberemo pravokotnik [x y w h]

%izrez predloge igralca iz prvega frema  
template = firstFrame( ...   
    selection(2):selection(2)+selection(4)-1, ...
    selection(1):selection(1)+selection(3)-1, :);

posX = selection(1); posY = selection(2); %zacetna pozicija pravokotnika
tplWidth = selection(3); tplHeight = selection(4); %velikost pravokotnika
searchRadius = 15;   % epsilon, lokalno iskanje, uzamemo 20 pikselov okol
numBins = 8;    % st. binov histograma

templateHist = rgb_hist_fast(template, numBins); %referencni histogram

while hasFrame(videoIn)                        
    currentFrame = readFrame(videoIn);

    %najboljsa (najmanjsa) chi2 razdalja
    minChi2 = inf;                             
    bestX = posX;
    bestY = posY;

    % meje iskalnega okna (da ne gres izven slike)
    yMin = max(1, posY-searchRadius);
    yMax = min(size(currentFrame,1)-tplHeight+1, posY+searchRadius);
    xMin = max(1, posX-searchRadius);
    xMax = min(size(currentFrame,2)-tplWidth+1, posX+searchRadius);

    for y = yMin:yMax                         
        for x = xMin:xMax

            candidate = currentFrame(y:y+tplHeight-1, x:x+tplWidth-1, :); %kandidatni patch
            candidateHist = rgb_hist_fast(candidate, numBins);            %histogram kandidata

            diff = templateHist - candidateHist;  %razlika histogramov
            chi2 = 0.5*sum(diff.^2 ./ (templateHist + candidateHist + eps));  %chi-square razdalja

            %izberi najbolj podoben
            if chi2 < minChi2      
                minChi2 = chi2;
                bestX = x;
                bestY = y;
            end
        end
    end
    
    %posodobi lokacijo
    posX = bestX;                                
    posY = bestY;

    outputFrame = insertShape(currentFrame, 'Rectangle', ... 
        [posX posY tplWidth tplHeight], 'Color', 'green');

    writeVideo(videoOut, outputFrame);           
end

close(videoOut);

%funkcija-RGB histogram,normalizira
function h = rgb_hist_fast(img, bins)

img = uint8(img);     %poskrbi da je 0..255

edges = linspace(0,256,bins+1);  %robovi binov (npr. 0-32-...-256)

hR = histcounts(img(:,:,1), edges); %histogram rdecega kanala
hG = histcounts(img(:,:,2), edges); %histogram zelenega kanala
hB = histcounts(img(:,:,3), edges); %histogram modrega kanala

h = double([hR hG hB]);       %zdruzi v en vektor RGB
h = h / sum(h);    %normalizacija
end
