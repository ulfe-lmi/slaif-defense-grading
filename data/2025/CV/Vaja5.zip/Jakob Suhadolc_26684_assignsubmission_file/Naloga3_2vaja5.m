clear; clc;

videoIn  = VideoReader('squash.avi');
videoOut = VideoWriter('track3_chi2_update.avi');
videoOut.FrameRate = videoIn.FrameRate;
open(videoOut);

firstFrame = readFrame(videoIn);
imshow(firstFrame);
selection = round(getrect);   % [x y w h]

templatePatch = firstFrame( ...
    selection(2):selection(2)+selection(4)-1, ...
    selection(1):selection(1)+selection(3)-1, :);

posX = selection(1); posY = selection(2);
tplWidth = selection(3); tplHeight = selection(4);

searchRadius = 15;
numBins = 8;

templateHist = rgb_hist_fast(templatePatch, numBins);

updateEvery = 1;    %posodobi vsak N-ti frame
frameIdx = 0;

while hasFrame(videoIn)
    frameIdx = frameIdx + 1;
    currentFrame = readFrame(videoIn);

    minChi2 = inf; bestX = posX; bestY = posY;

    yMin = max(1, posY - searchRadius);
    yMax = min(size(currentFrame,1) - tplHeight + 1, posY + searchRadius);
    xMin = max(1, posX - searchRadius);
    xMax = min(size(currentFrame,2) - tplWidth  + 1, posX + searchRadius);

    for y = yMin:yMax
        for x = xMin:xMax
            candidate = currentFrame(y:y+tplHeight-1, x:x+tplWidth-1, :);
            candHist = rgb_hist_fast(candidate, numBins);

            diff = templateHist - candHist;
            chi2 = 0.5*sum(diff.^2 ./ (templateHist + candHist + eps));

            if chi2 < minChi2
                minChi2 = chi2;
                bestX = x; bestY = y;
            end
        end
    end

    posX = bestX; posY = bestY;

    % sprotno ucenje (posodobi histogram)
  
    bestPatch = currentFrame(posY:posY+tplHeight-1, posX:posX+tplWidth-1, :);
    newHist = rgb_hist_fast(bestPatch, numBins);

    templateHist = newHist;
    templateHist = templateHist / sum(templateHist);   %ostani normiran
  

    outputFrame = insertShape(currentFrame,'Rectangle', ...
        [posX posY tplWidth tplHeight], 'Color','green','LineWidth',3);

    writeVideo(videoOut, outputFrame);
end

close(videoOut);

function h = rgb_hist_fast(img, bins)
img = uint8(img);
edges = linspace(0,256,bins+1);
hR = histcounts(img(:,:,1), edges);
hG = histcounts(img(:,:,2), edges);
hB = histcounts(img(:,:,3), edges);
h = double([hR hG hB]);
h = h / sum(h);
end
