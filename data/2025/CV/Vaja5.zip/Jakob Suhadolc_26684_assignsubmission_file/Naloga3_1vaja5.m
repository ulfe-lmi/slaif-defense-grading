clear; clc;

videoIn  = VideoReader('squash.avi');
videoOut = VideoWriter('track3_L2_update.avi');
videoOut.FrameRate = videoIn.FrameRate;
open(videoOut);

firstFrame = readFrame(videoIn);
imshow(firstFrame);
selection = round(getrect);                 % [x y w h]

template = firstFrame( ...
    selection(2):selection(2)+selection(4)-1, ...
    selection(1):selection(1)+selection(3)-1, :);

posX = selection(1); posY = selection(2);
tplWidth = selection(3); tplHeight = selection(4);

searchRadius = 15;
updateEvery = 1;    %posodobi vsak N-ti frame
frameIdx = 0;

while hasFrame(videoIn)
    frameIdx = frameIdx + 1;
    currentFrame = readFrame(videoIn);

    %uzamemo trenutne pozicije kot najboljse
    minError = inf; bestX = posX; bestY = posY;

     % meje iskalnega okna (da ne gres izven slike)
    yMin = max(1, posY - searchRadius);
    yMax = min(size(currentFrame,1) - tplHeight + 1, posY + searchRadius);
    xMin = max(1, posX - searchRadius);
    xMax = min(size(currentFrame,2) - tplWidth  + 1, posX + searchRadius);

    for y = yMin:yMax
        for x = xMin:xMax

            %trenuten kandidat
            candidate = currentFrame(y:y+tplHeight-1, x:x+tplWidth-1, :);

            diff = double(candidate) - double(template);
            error = sum(diff(:).^2);       

            %posodabljane najboljsih najdenih parametrov
            if error < minError
                minError = error;
                bestX = x; bestY = y;
            end
        end
    end

    posX = bestX; posY = bestY;

    %sprotno ucenje (posodobi template)
    newTpl = currentFrame(posY:posY+tplHeight-1, posX:posX+tplWidth-1, :);
    template = newTpl;

    outputFrame = insertShape(currentFrame,'Rectangle', ...
        [posX posY tplWidth tplHeight], 'Color','red','LineWidth',3);

    writeVideo(videoOut, outputFrame);
end

close(videoOut);
